<!DOCTYPE html>
<html>
<head>
    <title>图片显示测试</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .test-item { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; }
        img { max-width: 300px; border: 2px solid #ccc; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h1>拍卖图片显示测试</h1>
    
    <?php
    require_once 'db_connection.php';
    
    // 获取最近的5个拍卖及其图片
    $stmt = $pdo->query("
        SELECT auction_id, title, img_url, seller_id 
        FROM Auction 
        ORDER BY auction_id DESC 
        LIMIT 5
    ");
    $auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($auctions as $auction) {
        echo '<div class="test-item">';
        echo '<h3>拍卖 #' . $auction['auction_id'] . ': ' . htmlspecialchars($auction['title']) . '</h3>';
        echo '<p>卖家ID: ' . $auction['seller_id'] . '</p>';
        
        $img_url = $auction['img_url'];
        
        if (empty($img_url)) {
            echo '<p class="error">❌ 没有图片URL</p>';
            echo '<img src="img/placeholder.png" alt="占位符图片">';
        } else {
            echo '<p class="success">✓ 图片URL: ' . htmlspecialchars($img_url) . '</p>';
            
            // 检查文件是否存在
            $file_path = __DIR__ . '/' . $img_url;
            if (file_exists($file_path)) {
                echo '<p class="success">✓ 文件存在: ' . $file_path . '</p>';
                echo '<p>文件大小: ' . round(filesize($file_path) / 1024, 2) . ' KB</p>';
            } else {
                echo '<p class="error">❌ 文件不存在: ' . $file_path . '</p>';
            }
            
            // 显示图片
            echo '<div>';
            echo '<img src="' . htmlspecialchars($img_url) . '" alt="' . htmlspecialchars($auction['title']) . '" onerror="this.src=\'img/placeholder.png\'; this.onerror=null;">';
            echo '</div>';
        }
        
        echo '</div>';
    }
    ?>
    
    <hr>
    <h2>权限测试</h2>
    <ul>
        <li><strong>当前用户身份：</strong> 
            <?php 
            session_start();
            if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
                echo '已登录 - ' . htmlspecialchars($_SESSION['username']) . ' (';
                echo isset($_SESSION['is_seller']) && $_SESSION['is_seller'] ? 'Seller' : 'Buyer';
                echo ')';
            } else {
                echo '未登录（游客）';
            }
            ?>
        </li>
        <li><strong>browse.php 访问权限：</strong> ✓ 所有用户都可以访问（无需登录）</li>
        <li><strong>图片查看权限：</strong> ✓ 所有用户都可以查看（img/auctions/ 目录公开访问）</li>
    </ul>
    
    <hr>
    <p><a href="browse.php">返回浏览页面</a></p>
</body>
</html>
