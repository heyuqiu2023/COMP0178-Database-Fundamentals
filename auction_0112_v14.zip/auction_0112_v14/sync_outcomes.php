<?php
/**
 * 工具函数：确保已结束拍卖有 AuctionOutcome
 * 这个函数会在多个地方被调用以确保数据一致性
 */

require_once 'db_connection.php';

/**
 * 确保指定拍卖有 AuctionOutcome 记录
 * 如果拍卖状态是 ended 但没有 outcome，自动创建
 * 
 * @param PDO $pdo 数据库连接
 * @param int $auction_id 拍卖ID
 * @return bool 是否创建或已存在 outcome
 */
function ensureAuctionOutcome($pdo, $auction_id) {
    try {
        // 检查拍卖状态
        $stmt = $pdo->prepare("SELECT status FROM Auction WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        $status = $stmt->fetchColumn();
        
        if ($status !== 'ended') {
            // 拍卖未结束，不需要 outcome
            return false;
        }
        
        // 检查是否已有 outcome
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        if ($stmt->fetchColumn() > 0) {
            // 已有 outcome
            return true;
        }
        
        // 使用存储过程创建 outcome
        try {
            $pdo->exec("CALL ensure_auction_outcome($auction_id)");
            error_log("[ensureAuctionOutcome] Created outcome for auction #$auction_id using stored procedure");
            return true;
        } catch (Exception $e) {
            // 如果存储过程失败，使用 closeAuction 函数
            error_log("[ensureAuctionOutcome] Stored procedure failed, using closeAuction: " . $e->getMessage());
            
            require_once 'auction_functions.php';
            
            // 获取完整拍卖数据
            $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
            $stmt->execute([$auction_id]);
            $auction = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($auction) {
                $in_transaction = $pdo->inTransaction();
                
                if (!$in_transaction) {
                    $pdo->beginTransaction();
                }
                
                try {
                    closeAuction($pdo, $auction);
                    
                    if (!$in_transaction) {
                        $pdo->commit();
                    }
                    
                    return true;
                } catch (Exception $e2) {
                    if (!$in_transaction) {
                        $pdo->rollBack();
                    }
                    throw $e2;
                }
            }
        }
        
        return false;
        
    } catch (Exception $e) {
        error_log("[ensureAuctionOutcome] Failed for auction #$auction_id: " . $e->getMessage());
        return false;
    }
}

/**
 * 批量检查并修复所有已结束但缺少 outcome 的拍卖
 * 
 * @param PDO $pdo 数据库连接
 * @return array 返回修复的拍卖ID数组
 */
function syncAllMissingOutcomes($pdo) {
    $fixed = [];
    
    try {
        // 查找所有缺少 outcome 的已结束拍卖
        $stmt = $pdo->query("SELECT a.auction_id 
                            FROM Auction a 
                            LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                            WHERE a.status = 'ended' 
                            AND ao.outcome_id IS NULL");
        
        $auctions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($auctions as $auction_id) {
            if (ensureAuctionOutcome($pdo, $auction_id)) {
                $fixed[] = $auction_id;
                error_log("[syncAllMissingOutcomes] Fixed auction #$auction_id");
            }
        }
        
    } catch (Exception $e) {
        error_log("[syncAllMissingOutcomes] Error: " . $e->getMessage());
    }
    
    return $fixed;
}
?>
