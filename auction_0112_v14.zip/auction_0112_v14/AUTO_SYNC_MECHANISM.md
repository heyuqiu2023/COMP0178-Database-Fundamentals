# 拍卖结果自动同步机制

## 问题描述
Auction #28 的状态为 `ended`，但在 AuctionOutcome 表中没有对应记录，导致卖家决策功能无法正常工作。

## 解决方案

### 1. 三层自动同步机制

#### 层级 1: closeAuction() 函数（主要方法）
**文件**: `auction_functions.php`

当拍卖被关闭时，自动创建 AuctionOutcome：
- 查找最高出价
- 判断是否达到保留价
- 创建 AuctionOutcome 记录
- 验证创建成功
- 发送通知

**触发点**:
- 用户出价导致拍卖结束（`place_bid.php`）
- 定时任务关闭到期拍卖（`cron_close_auctions.php`）
- 页面访问时自动关闭（`listing.php`）

#### 层级 2: 数据库存储过程
**文件**: `setup_auto_sync.php`

创建存储过程 `ensure_auction_outcome(auction_id)`：
```sql
CALL ensure_auction_outcome(28);
```

功能：
- 检查是否已有 outcome
- 如果没有，自动创建
- 计算最高出价和保留价
- 设置正确的状态

#### 层级 3: ensureAuctionOutcome() 函数（兜底检查）
**文件**: `sync_outcomes.php`

提供两个工具函数：

**ensureAuctionOutcome($pdo, $auction_id)**
- 检查拍卖是否 ended
- 检查是否已有 outcome
- 如果缺失，自动创建
- 优先使用存储过程，失败则调用 closeAuction()

**syncAllMissingOutcomes($pdo)**
- 批量处理所有缺失的 outcome
- 返回修复的拍卖ID列表

### 2. 集成点

#### listing.php（实时检查）
```php
// 当访问已结束拍卖时，自动检查并创建 outcome
if ($status === 'ended') {
    require_once 'sync_outcomes.php';
    ensureAuctionOutcome($pdo, $auction_id);
}
```

#### cron_close_auctions.php（定时任务）
```php
// 关闭拍卖后，额外检查并修复缺失的 outcome
require_once 'sync_outcomes.php';
$fixed = syncAllMissingOutcomes($pdo);
```

#### check_db_consistency.php（一致性检查）
```php
// 在一致性检查中集成自动修复
if ($auto_fix) {
    require_once 'sync_outcomes.php';
    $fixed_auctions = syncAllMissingOutcomes($pdo);
}
```

### 3. 监控和测试工具

#### check_sync_28.php
检查特定拍卖（#28）的同步状态

#### test_auto_sync.php
全面测试自动同步功能：
- 检查函数可用性
- 检查存储过程
- 显示当前同步状态
- 提供手动同步按钮
- 测试特定拍卖

#### admin_tools.php
集中管理界面，快速访问所有工具

## 工作流程

### 正常流程
```
拍卖结束 → closeAuction() → 创建 AuctionOutcome → ✓ 完成
```

### 异常处理流程
```
拍卖已 ended 但缺少 outcome
    ↓
用户访问 listing.php
    ↓
ensureAuctionOutcome() 检测到缺失
    ↓
尝试存储过程 → 成功 → ✓ 完成
    ↓
失败 → closeAuction() → ✓ 完成
```

### 定时维护流程
```
每分钟执行 cron_close_auctions.php
    ↓
关闭到期拍卖 → 创建 outcome
    ↓
syncAllMissingOutcomes() → 修复任何遗漏
    ↓
✓ 系统保持同步
```

## 验证结果

运行 `verify_seller_decision_complete.php`：

✅ **Test 3: Auction Outcomes Consistency - PASS**
- 4 个已结束的拍卖
- 4 个 AuctionOutcome 记录
- **0 个缺失** ✓
- **100% 同步** ✓

运行 `test_auto_sync.php?test_auction_id=28`：

✅ Auction #28 状态:
- Status: ended ✓
- AuctionOutcome 存在 ✓
- Winner ID: 3 ✓
- Final Price: £68.00 ✓
- Reserve Met: No (需要卖家决策) ✓

## 使用指南

### 开发者
1. **创建新拍卖关闭逻辑时**：始终调用 `closeAuction($pdo, $auction)`
2. **处理已结束拍卖时**：使用 `ensureAuctionOutcome($pdo, $auction_id)` 确保 outcome 存在
3. **批量修复时**：调用 `syncAllMissingOutcomes($pdo)`

### 运维人员
1. **定时任务**：确保 `cron_close_auctions.php` 每分钟运行
2. **日常检查**：访问 `test_auto_sync.php` 查看同步状态
3. **发现问题时**：
   - 运行 `check_db_consistency.php?fix=1`
   - 或访问 `admin_tools.php` 使用修复工具

### 故障排除
如果发现 ended 拍卖缺少 outcome：
1. 访问 `fix_missing_outcomes.php` - 一键修复
2. 或运行 `test_auto_sync.php` - 使用 "Run Auto-Sync Now" 按钮
3. 或手动调用：`php -r "require 'sync_outcomes.php'; syncAllMissingOutcomes($pdo);"`

## 性能优化

- ✅ 使用 `ON DUPLICATE KEY UPDATE` 避免重复插入
- ✅ 在 closeAuction() 中添加状态检查，避免重复处理
- ✅ ensureAuctionOutcome() 先检查再创建，减少不必要的操作
- ✅ 批量处理使用单次查询获取所有缺失拍卖
- ✅ 存储过程提供数据库层面的快速处理

## 总结

通过实施三层自动同步机制，系统现在能够：

✅ **自动创建**：拍卖结束时自动创建 AuctionOutcome
✅ **实时检查**：访问页面时检测并修复缺失
✅ **定时维护**：定时任务自动修复不一致
✅ **手动工具**：提供多个工具进行检查和修复
✅ **完全同步**：确保所有 ended 拍卖都有 outcome

**当前状态**: 所有测试通过，系统运行正常，Auction #28 已正确同步 ✓
