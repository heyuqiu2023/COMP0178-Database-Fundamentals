<?php
/**
 * 测试自动同步功能
 * 验证当拍卖状态变为 ended 时，AuctionOutcome 会自动创建
 */

require_once 'db_connection.php';
require_once 'sync_outcomes.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Auto-Sync Test</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
</head>
<body>
<div class='container mt-4'>
<h1>🧪 Auto-Sync Functionality Test</h1>
<hr>";

// Test 1: Check if sync_outcomes.php functions exist
echo "<h3>Test 1: Function Availability</h3>";
if (function_exists('ensureAuctionOutcome')) {
    echo "<p class='text-success'>✓ ensureAuctionOutcome() function exists</p>";
} else {
    echo "<p class='text-danger'>✗ ensureAuctionOutcome() function not found</p>";
}

if (function_exists('syncAllMissingOutcomes')) {
    echo "<p class='text-success'>✓ syncAllMissingOutcomes() function exists</p>";
} else {
    echo "<p class='text-danger'>✗ syncAllMissingOutcomes() function not found</p>";
}

// Test 2: Check stored procedure
echo "<hr><h3>Test 2: Stored Procedure</h3>";
try {
    $check = $pdo->query("SHOW PROCEDURE STATUS WHERE Name = 'ensure_auction_outcome'");
    if ($check->rowCount() > 0) {
        echo "<p class='text-success'>✓ Stored procedure 'ensure_auction_outcome' exists</p>";
    } else {
        echo "<p class='text-warning'>⚠ Stored procedure not found. <a href='setup_auto_sync.php'>Run setup</a></p>";
    }
} catch (Exception $e) {
    echo "<p class='text-danger'>✗ Error checking procedure: " . $e->getMessage() . "</p>";
}

// Test 3: Check current sync status
echo "<hr><h3>Test 3: Current Sync Status</h3>";
try {
    $stmt = $pdo->query("SELECT 
                         (SELECT COUNT(*) FROM Auction WHERE status = 'ended') as ended_count,
                         (SELECT COUNT(*) FROM AuctionOutcome) as outcome_count,
                         (SELECT COUNT(*) FROM Auction a 
                          LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                          WHERE a.status = 'ended' AND ao.outcome_id IS NULL) as missing_count");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<table class='table table-bordered'>";
    echo "<tr><th>Metric</th><th>Count</th><th>Status</th></tr>";
    echo "<tr><td>Ended Auctions</td><td>{$stats['ended_count']}</td><td>-</td></tr>";
    echo "<tr><td>AuctionOutcome Records</td><td>{$stats['outcome_count']}</td><td>-</td></tr>";
    echo "<tr><td>Missing Outcomes</td><td><strong>{$stats['missing_count']}</strong></td><td>";
    
    if ($stats['missing_count'] == 0) {
        echo "<span class='badge badge-success'>✓ All Synced</span>";
    } else {
        echo "<span class='badge badge-danger'>✗ Needs Sync</span>";
    }
    echo "</td></tr>";
    echo "</table>";
    
    if ($stats['missing_count'] > 0) {
        echo "<div class='alert alert-warning'>";
        echo "<h5>Action Required</h5>";
        echo "<p>There are {$stats['missing_count']} ended auction(s) without outcomes.</p>";
        echo "<form method='POST'>";
        echo "<button type='submit' name='run_sync' class='btn btn-warning'>Run Auto-Sync Now</button>";
        echo "</form>";
        echo "</div>";
        
        if (isset($_POST['run_sync'])) {
            echo "<div class='alert alert-info mt-3'>";
            echo "<h5>Running Sync...</h5>";
            $fixed = syncAllMissingOutcomes($pdo);
            if (!empty($fixed)) {
                echo "<p class='text-success'>✓ Successfully synced " . count($fixed) . " auction(s): " . implode(', ', $fixed) . "</p>";
            } else {
                echo "<p class='text-danger'>No outcomes were created. Check error logs.</p>";
            }
            echo "</div>";
            echo "<script>setTimeout(function(){ window.location.reload(); }, 2000);</script>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='text-danger'>Error: " . $e->getMessage() . "</p>";
}

// Test 4: Test ensureAuctionOutcome on a specific auction
echo "<hr><h3>Test 4: Test ensureAuctionOutcome Function</h3>";

if (isset($_GET['test_auction_id'])) {
    $test_id = intval($_GET['test_auction_id']);
    echo "<p>Testing auction #$test_id...</p>";
    
    try {
        $result = ensureAuctionOutcome($pdo, $test_id);
        
        if ($result) {
            echo "<div class='alert alert-success'>✓ ensureAuctionOutcome returned TRUE for auction #$test_id</div>";
            
            // Verify outcome exists
            $verify = $pdo->prepare("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = ?");
            $verify->execute([$test_id]);
            if ($verify->fetchColumn() > 0) {
                echo "<p class='text-success'>✓ AuctionOutcome record exists</p>";
            } else {
                echo "<p class='text-danger'>✗ AuctionOutcome record NOT found</p>";
            }
        } else {
            echo "<div class='alert alert-info'>Function returned FALSE (auction may not be ended)</div>";
        }
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}

echo "<form method='GET' class='form-inline'>";
echo "<input type='number' name='test_auction_id' class='form-control mr-2' placeholder='Auction ID' value='28'>";
echo "<button type='submit' class='btn btn-primary'>Test Specific Auction</button>";
echo "</form>";

// Test 5: Integration points
echo "<hr><h3>Test 5: Integration Points</h3>";
echo "<p>The auto-sync mechanism is integrated into:</p>";
echo "<ul>";
echo "<li><code>listing.php</code> - Checks when viewing ended auctions ✓</li>";
echo "<li><code>cron_close_auctions.php</code> - Runs after closing auctions ✓</li>";
echo "<li><code>check_db_consistency.php</code> - Available in consistency checks ✓</li>";
echo "</ul>";

// Summary
echo "<hr>";
echo "<div class='card'>";
echo "<div class='card-header bg-info text-white'>";
echo "<h4 class='mb-0'>📋 Summary</h4>";
echo "</div>";
echo "<div class='card-body'>";
echo "<h5>Auto-Sync Mechanism</h5>";
echo "<p>When an auction status becomes 'ended', the system will automatically create an AuctionOutcome record through:</p>";
echo "<ol>";
echo "<li><strong>Primary Method</strong>: closeAuction() function (in auction_functions.php)</li>";
echo "<li><strong>Stored Procedure</strong>: ensure_auction_outcome (database level)</li>";
echo "<li><strong>Fallback Check</strong>: ensureAuctionOutcome() function (in sync_outcomes.php)</li>";
echo "</ol>";
echo "<h5>Monitoring & Maintenance</h5>";
echo "<ul>";
echo "<li>Cron job runs every minute to close and sync</li>";
echo "<li>Consistency check can detect and fix issues</li>";
echo "<li>listing.php performs on-demand checks</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<hr>";
echo "<div class='mt-3'>";
echo "<a href='verify_seller_decision_complete.php' class='btn btn-success'>Run Full Verification</a> ";
echo "<a href='check_db_consistency.php' class='btn btn-primary'>Check DB Consistency</a> ";
echo "<a href='check_sync_28.php' class='btn btn-secondary'>Check Auction #28</a> ";
echo "<a href='admin_tools.php' class='btn btn-outline-secondary'>Admin Tools</a>";
echo "</div>";

echo "</div></body></html>";
?>
