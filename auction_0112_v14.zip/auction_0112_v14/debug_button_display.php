<?php
session_start();
require_once 'db_connection.php';

$auction_id = isset($_GET['auction_id']) ? intval($_GET['auction_id']) : 20;

// Get auction details
$stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
$stmt->execute([$auction_id]);
$auction = $stmt->fetch(PDO::FETCH_ASSOC);

// Get outcome
$outcome_stmt = $pdo->prepare("SELECT ao.*, u.username AS winner_name 
                                FROM AuctionOutcome ao 
                                LEFT JOIN User u ON ao.winner_id = u.user_id 
                                WHERE ao.auction_id = ?");
$outcome_stmt->execute([$auction_id]);
$outcome = $outcome_stmt->fetch(PDO::FETCH_ASSOC);

$has_session = isset($_SESSION['user_id']);
$is_seller = ($has_session && isset($_SESSION['user_id']) && $_SESSION['user_id'] == $auction['seller_id']);
$is_winner = ($has_session && isset($_SESSION['user_id']) && $outcome['winner_id'] && $_SESSION['user_id'] == $outcome['winner_id']);

$deadline = new DateTime($outcome['acceptance_deadline']);
$deadline_passed = (new DateTime()) > $deadline;

echo "<h2>Debugging Button Display Logic</h2>";

echo "<h3>Session Variables:</h3>";
echo "<ul>";
echo "<li>has_session: " . ($has_session ? 'TRUE' : 'FALSE') . "</li>";
echo "<li>user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') . "</li>";
echo "<li>account_type: " . ($_SESSION['account_type'] ?? 'NOT SET') . "</li>";
echo "</ul>";

echo "<h3>Auction Data:</h3>";
echo "<ul>";
echo "<li>auction_id: " . $auction['auction_id'] . "</li>";
echo "<li>seller_id: " . $auction['seller_id'] . "</li>";
echo "<li>status: " . $auction['status'] . "</li>";
echo "</ul>";

echo "<h3>Outcome Data:</h3>";
if ($outcome) {
    echo "<ul>";
    echo "<li>winner_id: " . ($outcome['winner_id'] ?? 'NULL') . "</li>";
    echo "<li>winner_name: " . ($outcome['winner_name'] ?? 'NULL') . "</li>";
    echo "<li>final_price: £" . number_format($outcome['final_price'], 2) . "</li>";
    echo "<li>reserve_met: " . ($outcome['reserve_met'] ? 'TRUE (1)' : 'FALSE (0)') . "</li>";
    echo "<li>seller_accepted: " . ($outcome['seller_accepted'] ? 'TRUE (1)' : 'FALSE (0)') . "</li>";
    echo "<li>acceptance_deadline: " . $outcome['acceptance_deadline'] . "</li>";
    echo "</ul>";
} else {
    echo "<p>No outcome record found!</p>";
}

echo "<h3>Computed Variables:</h3>";
echo "<ul>";
echo "<li>is_seller: " . ($is_seller ? 'TRUE' : 'FALSE') . "</li>";
echo "<li>is_winner: " . ($is_winner ? 'TRUE' : 'FALSE') . "</li>";
echo "<li>deadline_passed: " . ($deadline_passed ? 'TRUE' : 'FALSE') . "</li>";
echo "</ul>";

echo "<h3>Condition Checks:</h3>";
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Condition</th><th>Result</th></tr>";

// Check each condition for button display
echo "<tr><td>!deadline_passed</td><td>" . (!$deadline_passed ? '✓ TRUE' : '✗ FALSE') . "</td></tr>";
echo "<tr><td>outcome['winner_id']</td><td>" . ($outcome['winner_id'] ? '✓ TRUE' : '✗ FALSE') . "</td></tr>";
echo "<tr><td>is_seller</td><td>" . ($is_seller ? '✓ TRUE' : '✗ FALSE') . "</td></tr>";

$should_show = (!$deadline_passed && $outcome['winner_id'] && $is_seller);
echo "<tr><th>ALL CONDITIONS MET?</th><th style='font-size:20px;'>" . ($should_show ? '✓ YES' : '✗ NO') . "</th></tr>";
echo "</table>";

if ($should_show) {
    echo "<h3 style='color:green;'>✓ Buttons SHOULD be displayed</h3>";
    echo "<p>If buttons are not showing on the listing page, check:</p>";
    echo "<ul>";
    echo "<li>Browser cache - try hard refresh (Ctrl+F5)</li>";
    echo "<li>PHP errors in error log</li>";
    echo "<li>JavaScript console errors</li>";
    echo "</ul>";
} else {
    echo "<h3 style='color:red;'>✗ Buttons should NOT be displayed because:</h3>";
    echo "<ul>";
    if ($deadline_passed) echo "<li>Deadline has passed</li>";
    if (!$outcome['winner_id']) echo "<li>No winner</li>";
    if (!$is_seller) echo "<li>Current user is not the seller</li>";
    echo "</ul>";
}

echo "<hr>";
echo "<h3>Test Button Display:</h3>";
if (!$deadline_passed && $outcome['winner_id'] && $is_seller) {
    echo '<div class="card border-warning mb-3" style="max-width: 600px;">';
    echo '<div class="card-header bg-warning text-dark">';
    echo '<strong><i class="fas fa-hand-pointer"></i> Action Required</strong>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<p class="mb-2"><strong>Winner:</strong> ' . htmlspecialchars($outcome['winner_name']) . '</p>';
    echo '<p class="mb-2"><strong>Final Bid:</strong> £' . number_format($outcome['final_price'], 2) . '</p>';
    echo '<div class="text-center mb-3">';
    echo '<a href="accept_bid.php?auction_id=' . $auction_id . '&action=accept" class="btn btn-success btn-lg" style="margin-right: 10px;">';
    echo '<i class="fas fa-check"></i> Accept Bid';
    echo '</a>';
    echo '<a href="accept_bid.php?auction_id=' . $auction_id . '&action=reject" class="btn btn-danger btn-lg">';
    echo '<i class="fas fa-times"></i> Reject Bid';
    echo '</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
} else {
    echo "<p>Buttons would not be displayed due to conditions not being met.</p>";
}
?>
