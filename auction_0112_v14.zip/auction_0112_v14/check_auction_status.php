<?php
require_once 'db_connection.php';

echo "<h2>Checking Auction Status</h2>";

// Check bike auction
$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.reserve_price, a.seller_id, a.end_time,
                     ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline 
                     FROM Auction a 
                     LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                     WHERE a.title LIKE '%bike%' 
                     ORDER BY a.auction_id DESC 
                     LIMIT 5");

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Title</th><th>Status</th><th>Reserve</th><th>End Time</th><th>Winner ID</th><th>Final Price</th><th>Reserve Met</th><th>Seller Accepted</th><th>Deadline</th></tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['auction_id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['title']) . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
    echo "<td>" . $row['end_time'] . "</td>";
    echo "<td>" . ($row['winner_id'] ?? 'NULL') . "</td>";
    echo "<td>£" . number_format($row['final_price'] ?? 0, 2) . "</td>";
    echo "<td>" . ($row['reserve_met'] ?? 'NULL') . "</td>";
    echo "<td>" . ($row['seller_accepted'] ?? 'NULL') . "</td>";
    echo "<td>" . ($row['acceptance_deadline'] ?? 'NULL') . "</td>";
    echo "</tr>";
}
echo "</table>";
?>
