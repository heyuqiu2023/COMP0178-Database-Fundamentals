# Auction Site Installation Guide

## Prerequisites

- XAMPP (or similar LAMP/MAMP stack)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser

## Installation Steps

### 1. Extract Files

Extract the auction site files to your web server directory:
- **XAMPP (macOS)**: `/Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/`
- **XAMPP (Windows)**: `C:\xampp\htdocs\auction_0112_v12\`
- **MAMP (macOS)**: `/Applications/MAMP/htdocs/auction_0112_v12/`

### 2. Set Directory Permissions (IMPORTANT)

The auction site needs write permissions to upload images. You must set the correct permissions for the upload directory.

#### macOS / Linux:

Open Terminal and navigate to your project directory, then run:

```bash
chmod 755 img/
chmod 777 img/auctions/
```

Or use the automated setup script:

```bash
chmod +x setup.sh
./setup.sh
```

#### Windows:

1. Right-click on the `img/auctions/` folder
2. Select **Properties** → **Security** tab
3. Click **Edit** → **Add**
4. Add `Everyone` or `IUSR` user
5. Grant **Full Control** permissions
6. Click **Apply** and **OK**

### 3. Create Database

1. Start XAMPP and ensure MySQL is running
2. Open phpMyAdmin: `http://localhost/phpmyadmin`
3. Create a new database named `auction_db`
4. Click on the `auction_db` database
5. Go to the **Import** tab
6. Click **Choose File** and select `CREATE TABLE User.sql`
7. Click **Go** to import the database schema

### 4. Configure Database Connection

Edit `db_connection.php` and verify the database credentials:

```php
$host = 'localhost';
$dbname = 'auction_db';
$username = 'root';
$password = '';  // Default XAMPP password is empty
```

If you're using a different MySQL setup, update these values accordingly.

### 5. Test the Installation

1. Open your web browser
2. Navigate to: `http://localhost/auction_0112_v12/`
3. You should see the auction site homepage

### 6. Register an Account

1. Click **Register** in the navigation
2. Create a new user account
3. Log in with your credentials

### 7. Test Image Upload

1. After logging in, click **+ Create auction**
2. Fill in the auction details
3. Try uploading an image
4. If you see an error about permissions, verify step 2 was completed correctly

## Supported Image Formats

The auction site supports the following image formats:
- JPEG/JPG
- PNG
- GIF
- WebP
- AVIF

Maximum file size: 2 MB per image
Maximum number of images: 5 per auction

## Troubleshooting

### Issue: "Failed to save file to server"

**Cause**: The `img/auctions/` directory doesn't have write permissions.

**Solution**:
- **macOS/Linux**: Run `chmod 777 img/auctions/` in Terminal
- **Windows**: Grant full control permissions to the folder (see Step 2 above)

### Issue: "File has disallowed mime type"

**Cause**: You're trying to upload an unsupported image format.

**Solution**: Only upload images in JPEG, PNG, GIF, WebP, or AVIF format.

### Issue: "Database connection failed"

**Cause**: MySQL is not running or database credentials are incorrect.

**Solution**:
1. Verify MySQL is running in XAMPP Control Panel
2. Check `db_connection.php` for correct credentials
3. Ensure `auction_db` database exists in phpMyAdmin

### Issue: Images not displaying after upload

**Cause**: File permissions or incorrect file paths.

**Solution**:
1. Verify uploaded files exist in `img/auctions/` directory
2. Check file permissions are readable (644 or higher)
3. Check browser console for 404 errors

## Security Notes

- The `img/auctions/` directory has 777 permissions for development purposes
- For production deployment, consider using more restrictive permissions (775) with proper user/group ownership
- Ensure your database password is set for production environments
- Consider implementing additional image validation and sanitization

## Additional Configuration

### Cron Jobs (Optional)

For automatic auction closing and notifications, set up these cron jobs:

```bash
# Close auctions every 5 minutes
*/5 * * * * php /path/to/auction_0112_v12/cron_close_auctions.php

# Send notifications every 10 minutes
*/10 * * * * php /path/to/auction_0112_v12/cron_send_notifications.php
```

## Support

If you encounter issues not covered in this guide, please check:
- PHP error logs (typically in `xampp/logs/` or shown in browser)
- MySQL error logs
- Browser console for JavaScript errors

---

**Installation Complete!** You should now have a fully functional auction site.