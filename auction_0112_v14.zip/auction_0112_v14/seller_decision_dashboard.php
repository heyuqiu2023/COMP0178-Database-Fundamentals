<?php
/**
 * 综合测试页面：卖家决策功能
 * 测试场景：
 * 1. 拍卖结束时自动创建 AuctionOutcome
 * 2. 卖家接受低于保留价的出价
 * 3. 卖家拒绝低于保留价的出价
 * 4. 决策超时自动拒绝
 */

session_start();
require_once 'db_connection.php';

// Check if user is logged in as seller
if (!isset($_SESSION['logged_in']) || $_SESSION['account_type'] !== 'seller') {
    die('<div style="padding: 20px;"><h2>Error</h2><p>Please log in as a seller to access this page.</p></div>');
}

$seller_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Seller Decision Testing Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .status-badge { font-size: 0.9em; }
        .test-section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
<div class="container mt-4">
    <h1><i class="fas fa-clipboard-check"></i> Seller Decision Testing Dashboard</h1>
    <p class="text-muted">Current User: <?php echo htmlspecialchars($_SESSION['username']); ?> (ID: <?php echo $seller_id; ?>)</p>
    <hr>
    
    <!-- Section 1: Auctions Needing Closure -->
    <div class="test-section">
        <h3><i class="fas fa-lock-open"></i> 1. Auctions Needing Closure</h3>
        <p>These auctions have ended but are still marked as <code>active</code>:</p>
        <?php
        $stmt = $pdo->prepare("SELECT auction_id, title, end_time, status 
                               FROM Auction 
                               WHERE seller_id = ? AND status = 'active' AND end_time <= NOW()
                               ORDER BY end_time DESC");
        $stmt->execute([$seller_id]);
        $unclosed = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($unclosed):
        ?>
            <table class="table table-sm table-bordered">
                <thead class="thead-light">
                    <tr><th>ID</th><th>Title</th><th>End Time</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($unclosed as $a): ?>
                        <tr>
                            <td><?php echo $a['auction_id']; ?></td>
                            <td><?php echo htmlspecialchars($a['title']); ?></td>
                            <td><?php echo $a['end_time']; ?></td>
                            <td>
                                <a href="close_expired_auctions.php?id=<?php echo $a['auction_id']; ?>" class="btn btn-sm btn-warning">Close Now</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-success"><i class="fas fa-check"></i> All auctions are properly closed!</div>
        <?php endif; ?>
    </div>
    
    <!-- Section 2: Pending Decisions -->
    <div class="test-section">
        <h3><i class="fas fa-exclamation-triangle"></i> 2. Pending Seller Decisions</h3>
        <p>Auctions where the highest bid is below reserve price and awaiting your decision:</p>
        <?php
        $stmt = $pdo->prepare("SELECT a.auction_id, a.title, a.reserve_price, a.end_time,
                               ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline,
                               ao.winner_id, u.username AS winner_name
                               FROM Auction a
                               JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                               LEFT JOIN User u ON ao.winner_id = u.user_id
                               WHERE a.seller_id = ?
                               AND a.status = 'ended'
                               AND ao.reserve_met = FALSE
                               AND ao.seller_accepted = FALSE
                               AND ao.winner_id IS NOT NULL
                               AND ao.acceptance_deadline > NOW()
                               ORDER BY ao.acceptance_deadline ASC");
        $stmt->execute([$seller_id]);
        $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($pending):
        ?>
            <table class="table table-sm table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Reserve</th>
                        <th>Highest Bid</th>
                        <th>Winner</th>
                        <th>Deadline</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending as $p): ?>
                        <tr>
                            <td><?php echo $p['auction_id']; ?></td>
                            <td><?php echo htmlspecialchars($p['title']); ?></td>
                            <td>£<?php echo number_format($p['reserve_price'], 2); ?></td>
                            <td><span class="text-danger">£<?php echo number_format($p['final_price'], 2); ?></span></td>
                            <td><?php echo htmlspecialchars($p['winner_name']); ?></td>
                            <td><?php echo $p['acceptance_deadline']; ?></td>
                            <td>
                                <a href="listing.php?auction_id=<?php echo $p['auction_id']; ?>" class="btn btn-sm btn-primary">View & Decide</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info"><i class="fas fa-info-circle"></i> No pending decisions.</div>
        <?php endif; ?>
    </div>
    
    <!-- Section 3: Completed Auctions -->
    <div class="test-section">
        <h3><i class="fas fa-check-circle"></i> 3. Recently Completed Auctions</h3>
        <p>Your last 10 completed auctions with outcomes:</p>
        <?php
        $stmt = $pdo->prepare("SELECT a.auction_id, a.title, a.reserve_price, a.status, a.end_time,
                               ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted,
                               u.username AS winner_name
                               FROM Auction a
                               LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                               LEFT JOIN User u ON ao.winner_id = u.user_id
                               WHERE a.seller_id = ?
                               AND a.status = 'ended'
                               ORDER BY a.end_time DESC
                               LIMIT 10");
        $stmt->execute([$seller_id]);
        $completed = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($completed):
        ?>
            <table class="table table-sm table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Reserve</th>
                        <th>Final Price</th>
                        <th>Winner</th>
                        <th>Outcome</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($completed as $c): ?>
                        <tr>
                            <td><?php echo $c['auction_id']; ?></td>
                            <td><?php echo htmlspecialchars($c['title']); ?></td>
                            <td>£<?php echo number_format($c['reserve_price'], 2); ?></td>
                            <td>
                                <?php if ($c['final_price']): ?>
                                    £<?php echo number_format($c['final_price'], 2); ?>
                                <?php else: ?>
                                    <span class="text-muted">No bids</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $c['winner_name'] ? htmlspecialchars($c['winner_name']) : '-'; ?></td>
                            <td>
                                <?php if (!$c['winner_id']): ?>
                                    <span class="badge badge-secondary status-badge">No Bids</span>
                                <?php elseif ($c['reserve_met']): ?>
                                    <span class="badge badge-success status-badge"><i class="fas fa-check"></i> Reserve Met</span>
                                <?php elseif ($c['seller_accepted']): ?>
                                    <span class="badge badge-success status-badge"><i class="fas fa-handshake"></i> Accepted</span>
                                <?php else: ?>
                                    <span class="badge badge-danger status-badge"><i class="fas fa-times"></i> Rejected/Expired</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="listing.php?auction_id=<?php echo $c['auction_id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info">No completed auctions yet.</div>
        <?php endif; ?>
    </div>
    
    <!-- Section 4: Bid Status Check -->
    <div class="test-section">
        <h3><i class="fas fa-gavel"></i> 4. Bid Status Verification</h3>
        <p>Verify that <code>is_active</code> flag is correctly updated when auctions are rejected:</p>
        <?php
        // Get rejected auctions and check their bids
        $stmt = $pdo->prepare("SELECT a.auction_id, a.title,
                               ao.seller_accepted, ao.winner_id,
                               COUNT(b.bid_id) AS total_bids,
                               SUM(CASE WHEN b.is_active = TRUE THEN 1 ELSE 0 END) AS active_bids
                               FROM Auction a
                               JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                               LEFT JOIN Bid b ON a.auction_id = b.auction_id
                               WHERE a.seller_id = ?
                               AND a.status = 'ended'
                               AND ao.reserve_met = FALSE
                               AND ao.seller_accepted = FALSE
                               AND ao.winner_id IS NULL
                               GROUP BY a.auction_id
                               ORDER BY a.auction_id DESC
                               LIMIT 5");
        $stmt->execute([$seller_id]);
        $rejected = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($rejected):
        ?>
            <table class="table table-sm table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>Auction ID</th>
                        <th>Title</th>
                        <th>Total Bids</th>
                        <th>Active Bids</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rejected as $r): ?>
                        <tr>
                            <td><?php echo $r['auction_id']; ?></td>
                            <td><?php echo htmlspecialchars($r['title']); ?></td>
                            <td><?php echo $r['total_bids']; ?></td>
                            <td><?php echo $r['active_bids']; ?></td>
                            <td>
                                <?php if ($r['active_bids'] == 0): ?>
                                    <span class="badge badge-success"><i class="fas fa-check"></i> Correct</span>
                                <?php else: ?>
                                    <span class="badge badge-danger"><i class="fas fa-exclamation"></i> Error: Should be 0</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info">No rejected auctions found to verify.</div>
        <?php endif; ?>
    </div>
    
    <hr>
    <div class="mb-3">
        <a href="mylistings.php" class="btn btn-primary"><i class="fas fa-list"></i> My Listings</a>
        <a href="index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Home</a>
    </div>
</div>
</body>
</html>
