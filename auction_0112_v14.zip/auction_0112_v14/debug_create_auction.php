<?php
session_start();
require_once 'db_connection.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Debug Create Auction Issue</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
</head>
<body>
<div class='container mt-4'>
<h2>🔍 Debugging Create Auction Foreign Key Issue</h2>
<hr>";

// Check session
echo "<h3>1. Session Information</h3>";
echo "<table class='table table-bordered'>";
echo "<tr><th>Key</th><th>Value</th></tr>";
echo "<tr><td>logged_in</td><td>" . (isset($_SESSION['logged_in']) ? ($_SESSION['logged_in'] ? 'TRUE' : 'FALSE') : 'NOT SET') . "</td></tr>";
echo "<tr><td>user_id</td><td>" . ($_SESSION['user_id'] ?? 'NOT SET') . "</td></tr>";
echo "<tr><td>username</td><td>" . ($_SESSION['username'] ?? 'NOT SET') . "</td></tr>";
echo "<tr><td>account_type</td><td>" . ($_SESSION['account_type'] ?? 'NOT SET') . "</td></tr>";
echo "<tr><td>is_seller</td><td>" . (isset($_SESSION['is_seller']) ? $_SESSION['is_seller'] : 'NOT SET') . "</td></tr>";
echo "</table>";

// Check if user exists in database
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    echo "<h3>2. User Database Check</h3>";
    
    try {
        $stmt = $pdo->prepare("SELECT user_id, username, email, account_type FROM User WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo "<div class='alert alert-success'>✓ User exists in database</div>";
            echo "<table class='table table-bordered'>";
            echo "<tr><th>Field</th><th>Value</th></tr>";
            foreach ($user as $key => $value) {
                echo "<tr><td>$key</td><td>" . htmlspecialchars($value) . "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "<div class='alert alert-danger'>✗ User ID $user_id NOT FOUND in User table!</div>";
            echo "<p>This is the problem! Session has user_id=$user_id but this user doesn't exist in the database.</p>";
        }
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
} else {
    echo "<div class='alert alert-warning'>No user_id in session</div>";
}

// Check foreign key constraints
echo "<h3>3. Foreign Key Constraints</h3>";
try {
    $stmt = $pdo->query("SELECT 
                         CONSTRAINT_NAME,
                         TABLE_NAME,
                         COLUMN_NAME,
                         REFERENCED_TABLE_NAME,
                         REFERENCED_COLUMN_NAME
                         FROM information_schema.KEY_COLUMN_USAGE
                         WHERE TABLE_SCHEMA = 'auction_system'
                         AND TABLE_NAME = 'Auction'
                         AND REFERENCED_TABLE_NAME IS NOT NULL");
    
    echo "<table class='table table-bordered table-sm'>";
    echo "<tr><th>Constraint</th><th>Column</th><th>References</th></tr>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>{$row['CONSTRAINT_NAME']}</td>";
        echo "<td>{$row['COLUMN_NAME']}</td>";
        echo "<td>{$row['REFERENCED_TABLE_NAME']}.{$row['REFERENCED_COLUMN_NAME']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}

// List all users
echo "<h3>4. All Users in Database</h3>";
try {
    $stmt = $pdo->query("SELECT user_id, username, email, account_type FROM User ORDER BY user_id");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($users)) {
        echo "<div class='alert alert-warning'>No users found in database!</div>";
    } else {
        echo "<table class='table table-bordered table-sm'>";
        echo "<tr><th>user_id</th><th>username</th><th>email</th><th>account_type</th></tr>";
        foreach ($users as $u) {
            $highlight = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $u['user_id']) ? 'table-success' : '';
            echo "<tr class='$highlight'>";
            echo "<td>{$u['user_id']}</td>";
            echo "<td>" . htmlspecialchars($u['username']) . "</td>";
            echo "<td>" . htmlspecialchars($u['email']) . "</td>";
            echo "<td>{$u['account_type']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}

// Check for ON DELETE CASCADE issue
echo "<h3>5. Foreign Key Constraint Details</h3>";
try {
    $stmt = $pdo->query("SELECT 
                         rc.CONSTRAINT_NAME,
                         rc.DELETE_RULE,
                         rc.UPDATE_RULE
                         FROM information_schema.REFERENTIAL_CONSTRAINTS rc
                         WHERE rc.CONSTRAINT_SCHEMA = 'auction_system'
                         AND rc.TABLE_NAME = 'Auction'");
    
    echo "<table class='table table-bordered table-sm'>";
    echo "<tr><th>Constraint</th><th>Delete Rule</th><th>Update Rule</th></tr>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>{$row['CONSTRAINT_NAME']}</td>";
        echo "<td>{$row['DELETE_RULE']}</td>";
        echo "<td>{$row['UPDATE_RULE']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<div class='alert alert-info'>";
    echo "<strong>Note:</strong> The error mentions 'ON DELETE CASCADE' which suggests the constraint doesn't allow the operation.";
    echo "</div>";
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}

// Recommendations
echo "<hr>";
echo "<h3>💡 Solutions</h3>";
echo "<div class='card'>";
echo "<div class='card-body'>";
echo "<h5>If user doesn't exist in database:</h5>";
echo "<ol>";
echo "<li>Log out and log in again</li>";
echo "<li>Or register a new account</li>";
echo "</ol>";

echo "<h5>If foreign key constraint is the issue:</h5>";
echo "<ol>";
echo "<li>Check if the constraint has 'ON DELETE CASCADE' that might be preventing inserts</li>";
echo "<li>Verify User table has the correct primary key</li>";
echo "<li>Check if there are any triggers preventing the operation</li>";
echo "</ol>";
echo "</div>";
echo "</div>";

echo "<hr>";
echo "<p><a href='logout.php' class='btn btn-warning'>Logout</a> ";
echo "<a href='register.php' class='btn btn-primary'>Register New Account</a> ";
echo "<a href='create_auction.php' class='btn btn-secondary'>Back to Create Auction</a></p>";

echo "</div></body></html>";
?>
