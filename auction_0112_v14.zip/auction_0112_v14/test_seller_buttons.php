<!DOCTYPE html>
<html>
<head>
    <title>Direct Test - Seller Decision Buttons</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<?php
session_start();
require_once 'db_connection.php';

echo "<div class='container mt-5'>";
echo "<h2>Direct Test - Seller Decision Interface</h2>";

$auction_id = 20;

// Get auction and outcome
$stmt = $pdo->prepare("SELECT a.*, ao.*, u.username AS winner_name 
                       FROM Auction a
                       LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                       LEFT JOIN User u ON ao.winner_id = u.user_id
                       WHERE a.auction_id = ?");
$stmt->execute([$auction_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    die("Auction not found");
}

$has_session = isset($_SESSION['user_id']);
$is_seller = ($has_session && $_SESSION['user_id'] == $data['seller_id']);

echo "<div class='alert alert-info'>";
echo "Session user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') . "<br>";
echo "Auction seller_id: " . $data['seller_id'] . "<br>";
echo "Is current user the seller? <strong>" . ($is_seller ? 'YES' : 'NO') . "</strong><br>";
echo "Reserve met: " . ($data['reserve_met'] ? 'YES' : 'NO') . "<br>";
echo "Seller accepted: " . ($data['seller_accepted'] ? 'YES' : 'NO') . "<br>";
echo "</div>";

// Show the decision interface
if ($is_seller && !$data['reserve_met'] && !$data['seller_accepted'] && $data['winner_id']) {
    $deadline = new DateTime($data['acceptance_deadline']);
    $now = new DateTime();
    
    if ($now <= $deadline) {
        echo "<div class='card border-warning mb-3'>";
        echo "<div class='card-header bg-warning text-dark'>";
        echo "<strong><i class='fas fa-hand-pointer'></i> Action Required</strong>";
        echo "</div>";
        echo "<div class='card-body'>";
        echo "<p class='mb-2'><strong>Winner:</strong> " . htmlspecialchars($data['winner_name']) . "</p>";
        echo "<p class='mb-2'><strong>Final Bid:</strong> £" . number_format($data['final_price'], 2) . "</p>";
        echo "<p class='mb-3'><strong>Your Reserve Price:</strong> £" . number_format($data['reserve_price'], 2) . "</p>";
        echo "<p class='text-muted small mb-3'>";
        echo "The highest bid is below your reserve price. You can choose to accept this bid or reject it.";
        echo "</p>";
        echo "<div class='text-center mb-3'>";
        echo "<a href='accept_bid.php?auction_id=" . $auction_id . "&action=accept' ";
        echo "class='btn btn-success btn-lg' style='margin-right: 10px;' ";
        echo "onclick=\"return confirm('Accept this bid of £" . number_format($data['final_price'], 2) . "?');\">";
        echo "<i class='fas fa-check'></i> Accept Bid";
        echo "</a>";
        echo "<a href='accept_bid.php?auction_id=" . $auction_id . "&action=reject' ";
        echo "class='btn btn-danger btn-lg' ";
        echo "onclick=\"return confirm('Reject this bid?');\">";
        echo "<i class='fas fa-times'></i> Reject Bid";
        echo "</a>";
        echo "</div>";
        echo "<p class='text-muted small mt-3 mb-0'>";
        echo "<i class='fas fa-clock'></i> Decision deadline: " . $deadline->format('j M Y H:i');
        echo "</p>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>Deadline has passed</div>";
    }
} else {
    echo "<div class='alert alert-warning'>";
    echo "Buttons not shown because:<br>";
    if (!$is_seller) echo "- You are not the seller<br>";
    if ($data['reserve_met']) echo "- Reserve price was met<br>";
    if ($data['seller_accepted']) echo "- Already accepted<br>";
    if (!$data['winner_id']) echo "- No winner<br>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='listing.php?auction_id=$auction_id' class='btn btn-primary'>Go to Real Listing Page</a></p>";
echo "</div>";
?>
</body>
</html>
