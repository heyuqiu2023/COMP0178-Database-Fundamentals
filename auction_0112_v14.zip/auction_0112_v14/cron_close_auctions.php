<?php
require_once 'db_connection.php';
require_once 'notify.php';
require_once 'auction_functions.php';

// Log start time
$log_message = "[" . date('Y-m-d H:i:s') . "] Cron: Starting auction closure check\n";

// Close any auctions past end_time but still active
try {
  $pdo->beginTransaction();
  
  // Select auctions to close and lock
  $stmt = $pdo->query("SELECT * FROM Auction WHERE status = 'active' AND end_time <= NOW() FOR UPDATE");
  $auctions = $stmt->fetchAll();
  
  $count = count($auctions);
  $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Found $count auction(s) to close\n";

  foreach ($auctions as $auction) {
    try {
      // Reuse the same closeAuction helper as in place_bid.php:
      closeAuction($pdo, $auction);
      $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Successfully closed auction #{$auction['auction_id']}\n";
    } catch (Exception $e) {
      $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Error closing auction #{$auction['auction_id']}: {$e->getMessage()}\n";
      throw $e; // Re-throw to rollback transaction
    }
  }

  $pdo->commit();
  $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Transaction committed successfully\n";
  
} catch (Exception $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: ERROR - {$e->getMessage()}\n";
  $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Stack trace:\n{$e->getTraceAsString()}\n";
}

// Additional check: Sync any ended auctions missing outcomes
try {
  require_once 'sync_outcomes.php';
  $fixed = syncAllMissingOutcomes($pdo);
  if (!empty($fixed)) {
    $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Synced missing outcomes for auctions: " . implode(', ', $fixed) . "\n";
  }
} catch (Exception $e) {
  $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Error syncing outcomes - {$e->getMessage()}\n";
}

// Write log to file
$log_file = __DIR__ . '/logs/cron_close_auctions.log';
$log_dir = dirname($log_file);
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0777, true);
}
file_put_contents($log_file, $log_message, FILE_APPEND);

// Also output to console for manual runs
echo $log_message;