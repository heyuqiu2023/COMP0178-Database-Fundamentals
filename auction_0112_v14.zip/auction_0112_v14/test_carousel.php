<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>图片轮播测试</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { padding: 20px; }
        .test-section { margin: 30px 0; padding: 20px; border: 2px solid #ddd; }
        .carousel { max-width: 600px; margin: 20px auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>图片轮播功能测试</h1>
        
        <?php
        require_once 'db_connection.php';
        
        // 测试拍卖 #23 (book - 2张图片)
        $auction_id = 23;
        $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        $auction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($auction):
            $title = $auction['title'];
            $picture = $auction['img_url'];
        ?>
        
        <div class="test-section">
            <h2>拍卖 #<?php echo $auction_id; ?>: <?php echo htmlspecialchars($title); ?></h2>
            <p><strong>图片URL:</strong> <code><?php echo htmlspecialchars($picture); ?></code></p>
            
            <?php 
            // 处理图片显示：支持单图和多图轮播
            if (!empty($picture)) {
                // 将图片URL按逗号分隔（支持多图）
                $image_urls = array_filter(array_map('trim', explode(',', $picture)));
                
                echo '<p><strong>图片数量:</strong> ' . count($image_urls) . '</p>';
                
                if (count($image_urls) > 1) {
                    // 多图：使用轮播
                    $carousel_id = 'test_carousel_' . $auction_id;
                    echo '<div id="' . $carousel_id . '" class="carousel slide" data-ride="carousel">';
                    echo '<div class="carousel-inner">';
                    
                    $first = true;
                    foreach ($image_urls as $idx => $img_url) {
                        $img_url = trim($img_url);
                        echo '<div class="carousel-item' . ($first ? ' active' : '') . '">';
                        echo '<img class="d-block w-100" src="' . htmlspecialchars($img_url) . '" ';
                        echo 'alt="' . htmlspecialchars($title) . ' - 图片 ' . ($idx + 1) . '" ';
                        echo 'onerror="this.src=\'img/placeholder.png\'; this.style.border=\'3px solid red\';">';
                        echo '<div class="carousel-caption d-none d-md-block">';
                        echo '<p>图片 ' . ($idx + 1) . ' / ' . count($image_urls) . '</p>';
                        echo '</div>';
                        echo '</div>';
                        $first = false;
                    }
                    
                    echo '</div>';
                    
                    // 轮播指示器
                    echo '<ol class="carousel-indicators">';
                    for ($i = 0; $i < count($image_urls); $i++) {
                        echo '<li data-target="#' . $carousel_id . '" data-slide-to="' . $i . '"';
                        if ($i === 0) echo ' class="active"';
                        echo '></li>';
                    }
                    echo '</ol>';
                    
                    // 轮播控制按钮
                    echo '<a class="carousel-control-prev" href="#' . $carousel_id . '" role="button" data-slide="prev">';
                    echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
                    echo '<span class="sr-only">Previous</span>';
                    echo '</a>';
                    echo '<a class="carousel-control-next" href="#' . $carousel_id . '" role="button" data-slide="next">';
                    echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
                    echo '<span class="sr-only">Next</span>';
                    echo '</a>';
                    
                    echo '</div>';
                    
                    echo '<p class="text-center mt-3"><small>使用左右箭头切换图片</small></p>';
                } else {
                    // 单图：直接显示
                    $img_url = trim($image_urls[0]);
                    echo '<img class="img-fluid" src="' . htmlspecialchars($img_url) . '" ';
                    echo 'alt="' . htmlspecialchars($title) . '" ';
                    echo 'onerror="this.src=\'img/placeholder.png\';">';
                }
            } else {
                // 没有图片：显示占位符
                echo '<img class="img-fluid" src="img/placeholder.png" ';
                echo 'alt="' . htmlspecialchars($title) . '">';
            }
            ?>
            
            <div class="mt-3">
                <a href="listing.php?auction_id=<?php echo $auction_id; ?>" class="btn btn-primary" target="_blank">
                    查看实际拍卖页面
                </a>
            </div>
        </div>
        
        <?php endif; ?>
        
        <!-- 测试其他拍卖 -->
        <div class="test-section">
            <h2>其他拍卖测试</h2>
            <ul>
                <li><a href="listing.php?auction_id=23" target="_blank">拍卖 #23 (book - 2张图片)</a></li>
                <li><a href="listing.php?auction_id=26" target="_blank">拍卖 #26 (bike00 - 1张图片)</a></li>
                <li><a href="listing.php?auction_id=25" target="_blank">拍卖 #25 (bike - 无图片，应显示占位符)</a></li>
            </ul>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        console.log('=== 图片轮播测试 ===');
        
        // 监听所有图片加载
        document.querySelectorAll('img').forEach((img, index) => {
            img.addEventListener('load', function() {
                console.log(`✓ 图片 ${index + 1} 加载成功:`, this.src);
            });
            img.addEventListener('error', function() {
                console.error(`✗ 图片 ${index + 1} 加载失败:`, this.src);
            });
        });
    </script>
</body>
</html>
