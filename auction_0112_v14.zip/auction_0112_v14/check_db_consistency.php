<?php
/**
 * 数据库一致性检查和自动修复工具
 * 定期运行此脚本以确保数据完整性
 */

require_once 'db_connection.php';
require_once 'auction_functions.php';

$is_cron = (php_sapi_name() === 'cli');
$auto_fix = isset($_GET['fix']) || ($is_cron && in_array('--fix', $argv));

if (!$is_cron) {
    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Database Consistency Check</title>
        <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    </head>
    <body>
    <div class='container mt-4'>
    <h1>🔍 Database Consistency Check</h1>
    <hr>";
}

$issues_found = [];
$fixes_applied = [];

try {
    // Check 1: Ended auctions without AuctionOutcome
    $stmt = $pdo->query("SELECT COUNT(*) as count, 
                         GROUP_CONCAT(a.auction_id SEPARATOR ', ') as auction_ids
                         FROM Auction a 
                         LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                         WHERE a.status = 'ended' AND ao.outcome_id IS NULL");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] > 0) {
        $issue = "Found {$result['count']} ended auction(s) without AuctionOutcome: [{$result['auction_ids']}]";
        $issues_found[] = $issue;
        
        if ($auto_fix) {
            // Use the new sync function
            require_once 'sync_outcomes.php';
            $fixed_auctions = syncAllMissingOutcomes($pdo);
            
            if (!empty($fixed_auctions)) {
                foreach ($fixed_auctions as $aid) {
                    $fixes_applied[] = "Synced outcome for auction #$aid";
                }
            } else {
                $fixes_applied[] = "Attempted to sync outcomes but none were created (check logs)";
            }
        }
    }
    
    // Check 2: Active auctions that have passed end_time
    $stmt = $pdo->query("SELECT COUNT(*) as count, 
                         GROUP_CONCAT(a.auction_id SEPARATOR ', ') as auction_ids
                         FROM Auction a 
                         WHERE a.status = 'active' AND a.end_time <= NOW()");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] > 0) {
        $issue = "Found {$result['count']} active auction(s) past end time: [{$result['auction_ids']}]";
        $issues_found[] = $issue;
        
        if ($auto_fix) {
            $stmt = $pdo->query("SELECT * FROM Auction WHERE status = 'active' AND end_time <= NOW()");
            $auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($auctions as $auction) {
                try {
                    $pdo->beginTransaction();
                    closeAuction($pdo, $auction);
                    $pdo->commit();
                    $fixes_applied[] = "Closed expired auction #{$auction['auction_id']}";
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $fixes_applied[] = "Failed to close auction #{$auction['auction_id']}: " . $e->getMessage();
                }
            }
        }
    }
    
    // Check 3: Rejected auctions with active bids
    $stmt = $pdo->query("SELECT a.auction_id, COUNT(b.bid_id) as active_bids
                         FROM Auction a
                         JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                         JOIN Bid b ON a.auction_id = b.auction_id
                         WHERE a.status = 'ended'
                         AND ao.reserve_met = FALSE
                         AND ao.seller_accepted = FALSE
                         AND ao.winner_id IS NULL
                         AND b.is_active = TRUE
                         GROUP BY a.auction_id");
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($results)) {
        foreach ($results as $result) {
            $issue = "Auction #{$result['auction_id']} is rejected but has {$result['active_bids']} active bid(s)";
            $issues_found[] = $issue;
            
            if ($auto_fix) {
                try {
                    $stmt = $pdo->prepare("UPDATE Bid SET is_active = FALSE WHERE auction_id = ?");
                    $stmt->execute([$result['auction_id']]);
                    $fixes_applied[] = "Deactivated bids for rejected auction #{$result['auction_id']}";
                } catch (Exception $e) {
                    $fixes_applied[] = "Failed to fix bids for auction #{$result['auction_id']}: " . $e->getMessage();
                }
            }
        }
    }
    
    // Check 4: Expired decisions not processed
    $stmt = $pdo->query("SELECT COUNT(*) as count
                         FROM AuctionOutcome ao
                         WHERE ao.reserve_met = FALSE
                         AND ao.seller_accepted = FALSE
                         AND ao.winner_id IS NOT NULL
                         AND ao.acceptance_deadline <= NOW()
                         AND ao.seller_notified = FALSE");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] > 0) {
        $issue = "Found {$result['count']} expired decision(s) not yet processed";
        $issues_found[] = $issue;
        
        if ($auto_fix) {
            $fixes_applied[] = "Run cron_expire_decisions.php to process expired decisions";
        }
    }
    
    // Generate report
    if (!$is_cron) {
        if (empty($issues_found)) {
            echo "<div class='alert alert-success'>";
            echo "<h4>✓ All Checks Passed!</h4>";
            echo "<p>Database is consistent. No issues found.</p>";
            echo "</div>";
        } else {
            echo "<div class='alert alert-warning'>";
            echo "<h4>⚠ Issues Found: " . count($issues_found) . "</h4>";
            echo "<ul>";
            foreach ($issues_found as $issue) {
                echo "<li>$issue</li>";
            }
            echo "</ul>";
            echo "</div>";
            
            if (!$auto_fix) {
                echo "<div class='alert alert-info'>";
                echo "<p><strong>To automatically fix these issues, run:</strong></p>";
                echo "<p><a href='?fix=1' class='btn btn-primary'>Auto-Fix Issues</a></p>";
                echo "</div>";
            }
        }
        
        if (!empty($fixes_applied)) {
            echo "<div class='alert alert-info'>";
            echo "<h4>🔧 Fixes Applied: " . count($fixes_applied) . "</h4>";
            echo "<ul>";
            foreach ($fixes_applied as $fix) {
                echo "<li>$fix</li>";
            }
            echo "</ul>";
            echo "</div>";
        }
        
        echo "<hr>";
        echo "<h3>Recommended Actions:</h3>";
        echo "<ol>";
        echo "<li>Run this check regularly (add to cron): <code>php " . basename(__FILE__) . " --fix</code></li>";
        echo "<li>Ensure <code>cron_close_auctions.php</code> runs every minute</li>";
        echo "<li>Ensure <code>cron_expire_decisions.php</code> runs every hour</li>";
        echo "</ol>";
        
        echo "<hr>";
        echo "<p><a href='verify_seller_decision_complete.php' class='btn btn-primary'>Run Full Verification</a></p>";
        echo "<p><a href='seller_decision_dashboard.php' class='btn btn-secondary'>Seller Dashboard</a></p>";
        
        echo "</div></body></html>";
    } else {
        // CLI output
        echo "=== Database Consistency Check ===\n";
        echo "Issues Found: " . count($issues_found) . "\n";
        foreach ($issues_found as $issue) {
            echo "  - $issue\n";
        }
        
        if (!empty($fixes_applied)) {
            echo "\nFixes Applied: " . count($fixes_applied) . "\n";
            foreach ($fixes_applied as $fix) {
                echo "  - $fix\n";
            }
        }
        
        echo "\nCheck completed at " . date('Y-m-d H:i:s') . "\n";
    }
    
} catch (Exception $e) {
    if (!$is_cron) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
        echo "</div></body></html>";
    } else {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
    exit(1);
}
?>
