<?php
/**
 * 测试完整的拍卖结束和状态同步流程
 */
require_once 'db_connection.php';

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>测试拍卖状态同步</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .warning { color: orange; font-weight: bold; }
        table { border-collapse: collapse; width: 100%; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
        th { background-color: #f2f2f2; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
        .scenario { background: #e3f2fd; padding: 10px; margin: 10px 0; border-left: 4px solid #2196F3; }
    </style>
</head>
<body>
    <h1>拍卖状态同步完整测试</h1>
    
    <div class="scenario">
        <h3>测试场景说明</h3>
        <ol>
            <li><strong>场景1：</strong>最高出价高于保留价 → 拍卖结束后自动完成，status='ended'，seller_accepted=TRUE</li>
            <li><strong>场景2：</strong>最高出价低于保留价 → 拍卖结束后status='ended'，等待卖家决策，seller_accepted=FALSE</li>
            <li><strong>场景3：</strong>卖家接受低于保留价的出价 → status保持'ended'，seller_accepted=TRUE</li>
            <li><strong>场景4：</strong>卖家拒绝低于保留价的出价 → status保持'ended'，winner_id=NULL</li>
            <li><strong>场景5：</strong>卖家超时未决策 → status保持'ended'，winner_id=NULL，自动拒绝</li>
        </ol>
    </div>
    
    <?php
    // Test 1: Check for auctions that ended but status is still active
    echo "<div class='test-section'>";
    echo "<h2>测试1: 检查需要同步的拍卖</h2>";
    
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.end_time, a.reserve_price,
               (SELECT MAX(bid_amount) FROM Bid WHERE auction_id = a.auction_id AND is_active = TRUE) as highest_bid,
               (SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = a.auction_id) as has_outcome
        FROM Auction a
        WHERE a.status = 'active' AND a.end_time <= NOW()
        ORDER BY a.auction_id
    ");
    $needs_sync = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($needs_sync) > 0) {
        echo "<p class='warning'>⚠ 发现 " . count($needs_sync) . " 个拍卖需要同步!</p>";
        echo "<table><tr><th>ID</th><th>标题</th><th>状态</th><th>结束时间</th><th>保留价</th><th>最高出价</th><th>有Outcome</th></tr>";
        foreach ($needs_sync as $row) {
            $reserve_met = ($row['highest_bid'] && $row['highest_bid'] >= $row['reserve_price']) ? '是' : '否';
            echo "<tr>";
            echo "<td>{$row['auction_id']}</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>{$row['status']}</td>";
            echo "<td>{$row['end_time']}</td>";
            echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
            echo "<td>" . ($row['highest_bid'] ? "£" . number_format($row['highest_bid'], 2) . " (达标: $reserve_met)" : "无出价") . "</td>";
            echo "<td>" . ($row['has_outcome'] ? '是' : '否') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<p><a href='sync_auction_outcomes.php' style='padding: 10px 15px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px;'>立即同步这些拍卖 &raquo;</a></p>";
    } else {
        echo "<p class='success'>✓ 没有需要同步的拍卖，所有已结束的拍卖状态都是 'ended'</p>";
    }
    echo "</div>";
    
    // Test 2: Verify ended auctions have correct AuctionOutcome
    echo "<div class='test-section'>";
    echo "<h2>测试2: 验证已结束拍卖的状态同步</h2>";
    
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.end_time, a.reserve_price,
               ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, 
               ao.acceptance_deadline, ao.seller_notified,
               u.username as winner_name,
               (SELECT COUNT(*) FROM Bid WHERE auction_id = a.auction_id AND is_active = TRUE) as active_bids
        FROM Auction a
        LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
        LEFT JOIN User u ON ao.winner_id = u.user_id
        WHERE a.end_time <= NOW()
        ORDER BY a.auction_id DESC
        LIMIT 10
    ");
    $ended_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($ended_auctions) > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>标题</th><th>Auction<br>Status</th><th>保留价</th><th>最终价格</th><th>达标</th><th>卖家接受</th><th>中标者</th><th>活跃出价数</th><th>状态</th></tr>";
        
        foreach ($ended_auctions as $row) {
            // Determine status
            $status_desc = '';
            if ($row['status'] !== 'ended') {
                $status_class = 'error';
                $status_desc = '❌ 需要同步';
            } elseif (!$row['winner_id']) {
                $status_class = 'warning';
                $status_desc = '无出价/已拒绝';
            } elseif ($row['reserve_met']) {
                $status_class = 'success';
                $status_desc = '✓ 已完成';
            } elseif ($row['seller_accepted']) {
                $status_class = 'success';
                $status_desc = '✓ 卖家已接受';
            } else {
                // Check if deadline passed
                if ($row['acceptance_deadline'] && strtotime($row['acceptance_deadline']) < time()) {
                    $status_class = 'error';
                    $status_desc = '⏱ 决策超时';
                } else {
                    $status_class = 'warning';
                    $status_desc = '⏳ 等待决策';
                }
            }
            
            echo "<tr>";
            echo "<td>{$row['auction_id']}</td>";
            echo "<td>" . htmlspecialchars(substr($row['title'], 0, 20)) . "</td>";
            echo "<td><strong>" . $row['status'] . "</strong></td>";
            echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
            echo "<td>" . ($row['final_price'] ? "£" . number_format($row['final_price'], 2) : '-') . "</td>";
            echo "<td>" . ($row['reserve_met'] ? '✓' : ($row['final_price'] ? '✗' : '-')) . "</td>";
            echo "<td>" . ($row['seller_accepted'] ? '✓' : ($row['winner_id'] ? '✗' : '-')) . "</td>";
            echo "<td>" . ($row['winner_name'] ? htmlspecialchars($row['winner_name']) : '-') . "</td>";
            echo "<td>{$row['active_bids']}</td>";
            echo "<td class='$status_class'>$status_desc</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='warning'>没有找到已结束的拍卖</p>";
    }
    echo "</div>";
    
    // Test 3: Check for pending seller decisions
    echo "<div class='test-section'>";
    echo "<h2>测试3: 等待卖家决策的拍卖</h2>";
    
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.seller_id, a.reserve_price,
               ao.final_price, ao.acceptance_deadline,
               TIMESTAMPDIFF(HOUR, NOW(), ao.acceptance_deadline) as hours_remaining,
               u.username as winner_name
        FROM Auction a
        JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
        LEFT JOIN User u ON ao.winner_id = u.user_id
        WHERE ao.reserve_met = FALSE
          AND ao.seller_accepted = FALSE
          AND ao.winner_id IS NOT NULL
        ORDER BY ao.acceptance_deadline ASC
    ");
    $pending = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($pending) > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>标题</th><th>Auction<br>Status</th><th>保留价</th><th>最高出价</th><th>中标者</th><th>剩余时间</th><th>决策截止</th><th>状态</th></tr>";
        
        foreach ($pending as $row) {
            $expired = $row['hours_remaining'] < 0;
            $row_class = $expired ? 'style="background-color: #ffebee;"' : 'style="background-color: #fff3cd;"';
            $status = $expired ? "❌ 已超时" : "⏳ {$row['hours_remaining']}小时";
            $auction_status_ok = ($row['status'] === 'ended') ? '✓' : '❌';
            
            echo "<tr $row_class>";
            echo "<td>{$row['auction_id']}</td>";
            echo "<td>" . htmlspecialchars(substr($row['title'], 0, 20)) . "</td>";
            echo "<td>{$auction_status_ok} {$row['status']}</td>";
            echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
            echo "<td>£" . number_format($row['final_price'], 2) . "</td>";
            echo "<td>" . htmlspecialchars($row['winner_name']) . "</td>";
            echo "<td>$status</td>";
            echo "<td>{$row['acceptance_deadline']}</td>";
            echo "<td>" . ($expired ? 
                "<a href='cron_expire_decisions.php'>处理超时</a>" : 
                "<a href='accept_bid.php?auction_id={$row['auction_id']}&action=accept'>接受</a> | 
                 <a href='accept_bid.php?auction_id={$row['auction_id']}&action=reject'>拒绝</a>") . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='success'>✓ 没有等待卖家决策的拍卖</p>";
    }
    echo "</div>";
    
    // Test 4: Check for expired decisions that need processing
    echo "<div class='test-section'>";
    echo "<h2>测试4: 需要处理的超时决策</h2>";
    
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.seller_id,
               ao.acceptance_deadline, ao.seller_notified,
               TIMESTAMPDIFF(HOUR, ao.acceptance_deadline, NOW()) as hours_overdue
        FROM Auction a
        JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
        WHERE ao.reserve_met = FALSE
          AND ao.seller_accepted = FALSE
          AND ao.winner_id IS NOT NULL
          AND ao.acceptance_deadline <= NOW()
          AND ao.seller_notified = FALSE
        ORDER BY ao.acceptance_deadline ASC
    ");
    $expired = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($expired) > 0) {
        echo "<p class='error'>⚠ 发现 " . count($expired) . " 个超时决策需要处理!</p>";
        echo "<table>";
        echo "<tr><th>ID</th><th>标题</th><th>Auction<br>Status</th><th>截止时间</th><th>超时</th><th>操作</th></tr>";
        
        foreach ($expired as $row) {
            $auction_status_ok = ($row['status'] === 'ended') ? '✓' : '❌';
            echo "<tr style='background-color: #ffebee;'>";
            echo "<td>{$row['auction_id']}</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>{$auction_status_ok} {$row['status']}</td>";
            echo "<td>{$row['acceptance_deadline']}</td>";
            echo "<td>{$row['hours_overdue']} 小时前</td>";
            echo "<td><a href='cron_expire_decisions.php' style='color: red; font-weight: bold;'>立即处理</a></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='success'>✓ 没有需要处理的超时决策</p>";
    }
    echo "</div>";
    
    // Summary
    echo "<div class='test-section'>";
    echo "<h2>总结</h2>";
    $total_issues = count($needs_sync) + count($expired);
    if ($total_issues > 0) {
        echo "<p class='error'>发现 $total_issues 个需要处理的问题</p>";
        echo "<ul>";
        if (count($needs_sync) > 0) {
            echo "<li><a href='sync_auction_outcomes.php'>同步 " . count($needs_sync) . " 个拍卖状态</a></li>";
        }
        if (count($expired) > 0) {
            echo "<li><a href='cron_expire_decisions.php'>处理 " . count($expired) . " 个超时决策</a></li>";
        }
        echo "</ul>";
    } else {
        echo "<p class='success'>✓ 所有拍卖状态同步正常!</p>";
        echo "<ul>";
        echo "<li>所有已结束的拍卖状态都是 'ended'</li>";
        echo "<li>所有拍卖都有对应的 AuctionOutcome 记录</li>";
        echo "<li>没有超时的卖家决策需要处理</li>";
        echo "</ul>";
    }
    echo "</div>";
    ?>
    
    <hr>
    <p>
        <a href="check_auction_status_sync.php">查看详细状态</a> | 
        <a href="seller_decision_dashboard.php">卖家决策面板</a> | 
        <a href="mylistings.php">我的拍卖</a>
    </p>
</body>
</html>
