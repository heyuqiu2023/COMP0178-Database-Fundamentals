<?php
/**
 * 测试协同过滤推荐算法
 */

require_once 'db_connection.php';

echo "=== 协同过滤推荐算法测试 ===\n\n";

// 获取所有买家
$stmt = $pdo->query("SELECT user_id, username FROM User WHERE role = 'buyer'");
$buyers = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "系统中的买家：\n";
foreach ($buyers as $buyer) {
    echo "  - User ID {$buyer['user_id']}: {$buyer['username']}\n";
}
echo "\n";

// 对每个买家测试推荐算法
foreach ($buyers as $buyer) {
    $user_id = $buyer['user_id'];
    $username = $buyer['username'];
    
    echo "========================================\n";
    echo "买家: {$username} (ID: {$user_id})\n";
    echo "========================================\n\n";
    
    // 1. 查看该用户的出价历史
    $stmt = $pdo->prepare("
        SELECT DISTINCT a.auction_id, a.title, COUNT(b.bid_id) as bid_count
        FROM Bid b
        JOIN Auction a ON a.auction_id = b.auction_id
        WHERE b.bidder_id = ?
        GROUP BY a.auction_id, a.title
        ORDER BY MAX(b.bid_time) DESC
    ");
    $stmt->execute([$user_id]);
    $user_bids = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "1. 该用户的出价历史 (" . count($user_bids) . " 个拍卖):\n";
    if (empty($user_bids)) {
        echo "   (无出价记录)\n";
    } else {
        foreach ($user_bids as $bid) {
            echo "   - 拍卖 #{$bid['auction_id']}: {$bid['title']} ({$bid['bid_count']} 次出价)\n";
        }
    }
    echo "\n";
    
    // 2. 找到相似用户
    $stmt = $pdo->prepare("
        SELECT DISTINCT b1.bidder_id AS similar_user_id, u.username,
               COUNT(DISTINCT b1.auction_id) as common_auctions
        FROM Bid b1
        JOIN User u ON u.user_id = b1.bidder_id
        WHERE b1.auction_id IN (
            SELECT DISTINCT b2.auction_id
            FROM Bid b2
            WHERE b2.bidder_id = ?
        )
        AND b1.bidder_id != ?
        GROUP BY b1.bidder_id, u.username
        HAVING COUNT(DISTINCT b1.auction_id) >= 1
        ORDER BY common_auctions DESC
    ");
    $stmt->execute([$user_id, $user_id]);
    $similar_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "2. 找到的相似用户 (" . count($similar_users) . " 个):\n";
    if (empty($similar_users)) {
        echo "   (无相似用户)\n";
    } else {
        foreach ($similar_users as $similar) {
            echo "   - User ID {$similar['similar_user_id']}: {$similar['username']} ";
            echo "(共同出价 {$similar['common_auctions']} 个拍卖)\n";
        }
    }
    echo "\n";
    
    // 3. 执行推荐算法
    $stmt = $pdo->prepare("
        SELECT 
            a.auction_id,
            a.title,
            a.status,
            COUNT(DISTINCT similar_bids.bidder_id) AS similarity_score
        FROM Auction a
        INNER JOIN Bid similar_bids ON similar_bids.auction_id = a.auction_id
        INNER JOIN (
            SELECT DISTINCT b1.bidder_id AS similar_user_id
            FROM Bid b1
            WHERE b1.auction_id IN (
                SELECT DISTINCT b2.auction_id
                FROM Bid b2
                WHERE b2.bidder_id = ?
            )
            AND b1.bidder_id != ?
            GROUP BY b1.bidder_id
            HAVING COUNT(DISTINCT b1.auction_id) >= 1
        ) similar_users ON similar_bids.bidder_id = similar_users.similar_user_id
        WHERE 
            a.status = 'active'
            AND a.end_time > NOW()
            AND a.auction_id NOT IN (
                SELECT DISTINCT b3.auction_id
                FROM Bid b3
                WHERE b3.bidder_id = ?
            )
        GROUP BY a.auction_id, a.title, a.status
        ORDER BY similarity_score DESC, a.end_time ASC
        LIMIT 5
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "3. 推荐结果 (" . count($recommendations) . " 个):\n";
    if (empty($recommendations)) {
        echo "   (无推荐)\n";
    } else {
        foreach ($recommendations as $rec) {
            echo "   - 拍卖 #{$rec['auction_id']}: {$rec['title']} ";
            echo "(相似度分数: {$rec['similarity_score']})\n";
        }
    }
    echo "\n";
    
    // 4. 如果没有推荐，显示原因
    if (empty($recommendations)) {
        if (empty($user_bids)) {
            echo "   原因: 用户没有出价历史\n";
        } elseif (empty($similar_users)) {
            echo "   原因: 没有找到相似用户\n";
        } else {
            // 检查是否有活跃拍卖
            $stmt = $pdo->query("SELECT COUNT(*) FROM Auction WHERE status = 'active' AND end_time > NOW()");
            $active_count = $stmt->fetchColumn();
            echo "   原因: 没有相似用户正在出价的活跃拍卖（系统中有 {$active_count} 个活跃拍卖）\n";
        }
    }
    echo "\n\n";
}

echo "=== 测试完成 ===\n";
?>
