<?php
/**
 * 修复缺少 AuctionOutcome 的已结束拍卖
 */

require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Fix Missing Outcomes</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
</head>
<body>
<div class='container mt-4'>
<h2>🔧 Fixing Missing AuctionOutcome Records</h2>
<hr>";

try {
    // Find ended auctions without outcomes
    $stmt = $pdo->query("SELECT a.* 
                         FROM Auction a 
                         LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                         WHERE a.status = 'ended' AND ao.outcome_id IS NULL
                         ORDER BY a.auction_id");
    
    $missing_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($missing_auctions)) {
        echo "<div class='alert alert-success'>✓ No missing outcomes found! All ended auctions have outcome records.</div>";
    } else {
        echo "<div class='alert alert-warning'>";
        echo "<strong>Found " . count($missing_auctions) . " ended auction(s) without outcomes:</strong>";
        echo "</div>";
        
        echo "<table class='table table-bordered mb-4'>";
        echo "<thead class='thead-light'>";
        echo "<tr><th>Auction ID</th><th>Title</th><th>Seller ID</th><th>End Time</th><th>Status</th></tr>";
        echo "</thead><tbody>";
        
        foreach ($missing_auctions as $auction) {
            echo "<tr>";
            echo "<td>" . $auction['auction_id'] . "</td>";
            echo "<td>" . htmlspecialchars($auction['title']) . "</td>";
            echo "<td>" . $auction['seller_id'] . "</td>";
            echo "<td>" . $auction['end_time'] . "</td>";
            echo "<td><span class='badge badge-secondary'>ended</span></td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        
        // Fix each auction
        echo "<h3>Creating Missing Outcomes:</h3>";
        
        $fixed_count = 0;
        foreach ($missing_auctions as $auction) {
            $auction_id = $auction['auction_id'];
            $title = htmlspecialchars($auction['title']);
            
            try {
                $pdo->beginTransaction();
                
                // Get auction details with bids
                $stmt = $pdo->prepare("SELECT a.*, 
                                       (SELECT MAX(b.bid_amount) FROM Bid b WHERE b.auction_id = a.auction_id) as max_bid,
                                       (SELECT b.bidder_id FROM Bid b WHERE b.auction_id = a.auction_id ORDER BY b.bid_amount DESC, b.bid_time ASC LIMIT 1) as winner_id,
                                       (SELECT COUNT(*) FROM Bid b WHERE b.auction_id = a.auction_id) as bid_count
                                       FROM Auction a
                                       WHERE a.auction_id = ?");
                $stmt->execute([$auction_id]);
                $full_auction = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$full_auction) {
                    throw new Exception("Auction not found");
                }
                
                $reserve_price = (float)$full_auction['reserve_price'];
                $winner_id = $full_auction['winner_id'];
                $final_price = $full_auction['max_bid'] ? (float)$full_auction['max_bid'] : null;
                $bid_count = (int)$full_auction['bid_count'];
                
                // Determine if reserve was met
                $reserve_met = false;
                if ($winner_id && $final_price !== null) {
                    if ($reserve_price > 0) {
                        $reserve_met = ($final_price >= $reserve_price);
                    } else {
                        // No reserve price set, any bid meets the requirement
                        $reserve_met = true;
                    }
                }
                
                // Set seller_accepted based on reserve_met
                $seller_accepted = $reserve_met;
                
                // Calculate acceptance deadline (24 hours from now for pending, or past for auto-accepted)
                if ($reserve_met) {
                    $accept_deadline = (new DateTime('now'))->modify('-1 day')->format('Y-m-d H:i:s');
                } else {
                    $accept_deadline = (new DateTime('now'))->modify('+24 hours')->format('Y-m-d H:i:s');
                }
                
                // Create AuctionOutcome
                $stmt = $pdo->prepare("INSERT INTO AuctionOutcome 
                                       (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at, seller_notified, winner_notified)
                                       VALUES (?, ?, ?, ?, ?, ?, NOW(), FALSE, FALSE)");
                $stmt->execute([$auction_id, $winner_id, $final_price, $reserve_met, $seller_accepted, $accept_deadline]);
                
                $pdo->commit();
                
                echo "<div class='alert alert-success mb-2'>";
                echo "✓ <strong>Auction #$auction_id</strong>: $title<br>";
                echo "<small>";
                if ($bid_count == 0) {
                    echo "No bids received. Outcome: Unsuccessful";
                } elseif ($reserve_met) {
                    echo "Winner ID: $winner_id, Final Price: £" . number_format($final_price, 2) . ", Reserve Met: YES - Auto-accepted";
                } else {
                    echo "Winner ID: $winner_id, Final Price: £" . number_format($final_price, 2) . ", Reserve Met: NO - Needs seller decision";
                }
                echo "</small>";
                echo "</div>";
                
                $fixed_count++;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                echo "<div class='alert alert-danger mb-2'>";
                echo "✗ <strong>Auction #$auction_id</strong>: Failed - " . $e->getMessage();
                echo "</div>";
            }
        }
        
        echo "<hr>";
        echo "<div class='alert alert-info'>";
        echo "<strong>Summary:</strong> Fixed $fixed_count out of " . count($missing_auctions) . " auction(s)";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
}

echo "<hr>";
echo "<p><a href='verify_seller_decision_complete.php' class='btn btn-primary'>Re-run Verification Tests</a></p>";
echo "<p><a href='seller_decision_dashboard.php' class='btn btn-secondary'>Seller Decision Dashboard</a></p>";

echo "</div></body></html>";
?>
