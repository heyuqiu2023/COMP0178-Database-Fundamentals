<?php
require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "<h2>Checking Auction #28</h2>";

// Get auction details
$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.reserve_price, a.seller_id, a.end_time,
                     ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline,
                     u.username AS winner_name
                     FROM Auction a 
                     LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                     LEFT JOIN User u ON ao.winner_id = u.user_id
                     WHERE a.auction_id = 28");

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Title</th><th>Status</th><th>Reserve</th><th>End Time</th><th>Winner</th><th>Final Price</th><th>Reserve Met</th><th>Seller Accepted</th><th>Deadline</th></tr>";

$auction = null;
if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $auction = $row;
    echo "<tr>";
    echo "<td>" . $row['auction_id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['title']) . "</td>";
    echo "<td><strong>" . $row['status'] . "</strong></td>";
    echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
    echo "<td>" . $row['end_time'] . "</td>";
    echo "<td>" . ($row['winner_name'] ?? 'NULL') . "</td>";
    echo "<td>£" . number_format($row['final_price'] ?? 0, 2) . "</td>";
    echo "<td>" . ($row['reserve_met'] ? 'YES' : 'NO') . "</td>";
    echo "<td>" . ($row['seller_accepted'] ? 'YES' : 'NO') . "</td>";
    echo "<td>" . ($row['acceptance_deadline'] ?? 'NULL') . "</td>";
    echo "</tr>";
}
echo "</table>";

if (!$auction) {
    echo "<p>Auction #28 not found!</p>";
    exit;
}

// Check if auction needs to be closed
$end_time = new DateTime($auction['end_time']);
$now = new DateTime();

echo "<hr>";
echo "<h3>Status Analysis:</h3>";
echo "<ul>";
echo "<li>Current time: " . $now->format('Y-m-d H:i:s') . "</li>";
echo "<li>Auction end time: " . $end_time->format('Y-m-d H:i:s') . "</li>";
echo "<li>Has ended: " . ($now >= $end_time ? '<span style="color:green;">YES</span>' : '<span style="color:red;">NO</span>') . "</li>";
echo "<li>Current status: <strong>" . $auction['status'] . "</strong></li>";
echo "<li>Has AuctionOutcome: " . ($auction['winner_id'] !== null || $auction['acceptance_deadline'] ? 'YES' : 'NO') . "</li>";
echo "</ul>";

// Auto-close if needed
if ($auction['status'] === 'active' && $now >= $end_time) {
    echo "<div style='background-color: #fff3cd; padding: 15px; border: 1px solid #ffc107;'>";
    echo "<h4>⚠️ This auction should be closed!</h4>";
    echo "<form method='POST'>";
    echo "<button type='submit' name='close_auction' class='btn btn-warning'>Close Auction Now</button>";
    echo "</form>";
    echo "</div>";
    
    if (isset($_POST['close_auction'])) {
        try {
            $pdo->beginTransaction();
            
            // Get full auction data
            $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
            $stmt->execute([28]);
            $auction_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            closeAuction($pdo, $auction_data);
            $pdo->commit();
            
            echo "<div style='color: green; margin-top: 10px;'>✓ Auction closed successfully!</div>";
            echo "<script>setTimeout(function(){ window.location.reload(); }, 1500);</script>";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "<div style='color: red; margin-top: 10px;'>✗ Error: " . $e->getMessage() . "</div>";
        }
    }
}

// Check bids
echo "<hr>";
echo "<h3>Bid Information:</h3>";
$bid_stmt = $pdo->prepare("SELECT b.*, u.username 
                           FROM Bid b 
                           JOIN User u ON b.bidder_id = u.user_id 
                           WHERE b.auction_id = 28 
                           ORDER BY b.bid_amount DESC, b.bid_time ASC");
$bid_stmt->execute();

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Bid ID</th><th>Bidder</th><th>Amount</th><th>Time</th><th>Is Active</th></tr>";
while ($bid = $bid_stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $bid['bid_id'] . "</td>";
    echo "<td>" . htmlspecialchars($bid['username']) . "</td>";
    echo "<td>£" . number_format($bid['bid_amount'], 2) . "</td>";
    echo "<td>" . $bid['bid_time'] . "</td>";
    echo "<td>" . ($bid['is_active'] ? 'YES' : 'NO') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<hr>";
echo "<p><a href='listing.php?auction_id=28'>View Auction #28 Listing Page</a></p>";
echo "<p><a href='mylistings.php'>View My Listings</a></p>";
?>
