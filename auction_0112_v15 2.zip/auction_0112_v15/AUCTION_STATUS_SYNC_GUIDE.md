# 拍卖状态同步系统 - 实现文档

## 概述

本文档描述了拍卖系统中拍卖结束后的状态同步机制，确保`Auction`表的状态和`AuctionOutcome`表保持一致。

## 核心功能

### 1. 拍卖结束状态同步

**问题：** 拍卖时间到期后，`Auction`表的`status`字段可能仍然是`active`，而没有同步更新为`ended`，也没有创建`AuctionOutcome`记录。

**解决方案：** 实现自动同步机制，确保所有已到期的拍卖都正确更新状态并创建结果记录。

### 2. 卖家决策机制

根据最高出价与保留价的关系，系统有三种处理方式：

#### 场景A：最高出价 ≥ 保留价
- **自动处理**：拍卖结束时自动完成交易
- `Auction.status` → `ended`
- `AuctionOutcome.reserve_met` → `TRUE`
- `AuctionOutcome.seller_accepted` → `TRUE`
- 通知中标者和卖家

#### 场景B：最高出价 < 保留价（等待卖家决策）
- **手动处理**：卖家有24小时决策时间
- `Auction.status` → `ended`
- `AuctionOutcome.reserve_met` → `FALSE`
- `AuctionOutcome.seller_accepted` → `FALSE`（初始状态）
- `AuctionOutcome.acceptance_deadline` → 结束时间 + 24小时
- 通知卖家需要决策

##### 场景B1：卖家接受出价
- `AuctionOutcome.seller_accepted` → `TRUE`
- `Auction.status` 保持 `ended`
- 通知中标者交易成功

##### 场景B2：卖家拒绝出价
- `AuctionOutcome.seller_accepted` → `FALSE`
- `AuctionOutcome.winner_id` → `NULL`
- `AuctionOutcome.final_price` → `NULL`
- `Bid.is_active` → `FALSE`（所有出价）
- `Auction.status` 保持 `ended`
- 通知出价者被拒绝

##### 场景B3：卖家超时未决策
- 自动执行拒绝逻辑（同场景B2）
- `AuctionOutcome.seller_notified` → `TRUE`（标记已处理）
- `Auction.status` 保持 `ended`
- 通知卖家和出价者超时

## 实现文件

### 1. `auction_functions.php` - 拍卖关闭核心函数

```php
function closeAuction($pdo, $auctionRow)
```

**功能：**
- 将`Auction.status`更新为`ended`
- 创建`AuctionOutcome`记录
- 根据是否达到保留价设置初始状态
- 发送相关通知

**逻辑：**
```
IF 最高出价 >= 保留价 THEN
    seller_accepted = TRUE  // 自动接受
ELSE
    seller_accepted = FALSE // 等待决策
END IF

acceptance_deadline = NOW() + 24小时
```

### 2. `sync_auction_outcomes.php` - 状态同步脚本

**功能：**
- 查找所有`status='active'`但`end_time <= NOW()`的拍卖
- 对每个拍卖调用`closeAuction()`
- 验证同步结果
- 提供详细的同步报告

**使用：**
```
浏览器访问：http://localhost/auction_0112_v14/sync_auction_outcomes.php
```

### 3. `cron_expire_decisions.php` - 超时决策处理

**功能：**
- 查找超过`acceptance_deadline`但`seller_notified=FALSE`的记录
- 自动拒绝超时的出价
- 确保`Auction.status`保持`ended`
- 发送超时通知

**条件：**
```sql
WHERE reserve_met = FALSE
  AND seller_accepted = FALSE
  AND winner_id IS NOT NULL
  AND acceptance_deadline <= NOW()
  AND seller_notified = FALSE
```

**运行：**
```bash
# 定时任务（建议每小时）
0 * * * * /usr/bin/php /path/to/cron_expire_decisions.php

# 手动运行
php cron_expire_decisions.php
# 或浏览器访问
http://localhost/auction_0112_v14/cron_expire_decisions.php
```

### 4. `accept_bid.php` - 卖家决策处理

**功能：**
- 验证卖家权限和决策有效性
- 处理接受/拒绝操作
- **确保`Auction.status`保持`ended`**
- 更新`AuctionOutcome`状态
- 发送通知

**关键点：**
- 决策前验证：`Auction.status === 'ended'`
- 决策后保持：显式确保状态为`ended`
- 无论接受还是拒绝，拍卖状态都保持`ended`

### 5. `check_auction_status_sync.php` - 状态检查工具

**功能：**
- 显示需要同步的拍卖
- 显示所有已结束拍卖的状态
- 显示等待决策的拍卖
- 提供快速链接到同步和处理页面

### 6. `test_auction_sync.php` - 综合测试工具

**功能：**
- 测试1：检查需要同步的拍卖
- 测试2：验证已结束拍卖的状态同步
- 测试3：列出等待卖家决策的拍卖
- 测试4：识别需要处理的超时决策
- 提供总结和快速操作链接

## 数据库状态流转

```
拍卖创建
  ↓
Auction.status = 'active'
  ↓
时间到期 (end_time <= NOW)
  ↓
调用 closeAuction()
  ↓
Auction.status = 'ended'
AuctionOutcome 创建
  ↓
┌─────────────────────────────┬────────────────────────────┐
│ 最高出价 >= 保留价          │ 最高出价 < 保留价          │
├─────────────────────────────┼────────────────────────────┤
│ reserve_met = TRUE          │ reserve_met = FALSE        │
│ seller_accepted = TRUE      │ seller_accepted = FALSE    │
│ 自动完成 ✓                  │ 等待卖家决策 ⏳            │
└─────────────────────────────┴────────────────────────────┘
                                      ↓
                   ┌──────────────────┼──────────────────┐
                   ↓                  ↓                  ↓
              卖家接受          卖家拒绝          超时未决策
                   ↓                  ↓                  ↓
         seller_accepted    winner_id = NULL    自动执行拒绝
              = TRUE         seller_notified        逻辑
                                 = TRUE
                   ↓                  ↓                  ↓
         Auction.status    Auction.status    Auction.status
         保持 'ended'      保持 'ended'      保持 'ended'
```

## 使用指南

### 首次部署/修复现有数据

1. **检查当前状态：**
   ```
   访问：http://localhost/auction_0112_v14/check_auction_status_sync.php
   ```

2. **同步已过期的拍卖：**
   ```
   访问：http://localhost/auction_0112_v14/sync_auction_outcomes.php
   ```

3. **处理超时决策：**
   ```
   访问：http://localhost/auction_0112_v14/cron_expire_decisions.php
   ```

4. **验证结果：**
   ```
   访问：http://localhost/auction_0112_v14/test_auction_sync.php
   ```

### 日常运行

1. **设置定时任务关闭拍卖：**
   ```bash
   # 每5分钟检查并关闭过期拍卖
   */5 * * * * /usr/bin/php /path/to/close_expired_auctions.php
   ```

2. **设置定时任务处理超时决策：**
   ```bash
   # 每小时处理超时决策
   0 * * * * /usr/bin/php /path/to/cron_expire_decisions.php
   ```

### 卖家操作

1. 登录为卖家账户
2. 访问"我的拍卖"或"卖家决策面板"
3. 查看需要决策的拍卖
4. 在24小时内做出接受/拒绝决策

## 关键保证

### ✓ 状态一致性
- 所有过期拍卖都会更新为`ended`
- 每个`ended`拍卖都有对应的`AuctionOutcome`记录
- 状态更新在事务中完成，确保原子性

### ✓ 决策流程完整性
- 高于保留价自动完成
- 低于保留价有24小时决策期
- 超时自动拒绝并通知各方
- 所有决策后状态都保持`ended`

### ✓ 通知机制
- 拍卖结束通知卖家和中标者
- 低于保留价通知卖家需决策
- 高于保留价通知中标者确认
- 决策后通知相关方结果
- 超时自动通知双方

## 验证检查点

使用`test_auction_sync.php`可以验证以下检查点：

- [ ] 没有`active`状态但时间已过期的拍卖
- [ ] 所有`ended`拍卖都有`AuctionOutcome`记录
- [ ] 低于保留价的拍卖有正确的决策截止时间
- [ ] 超时决策被正确处理并标记
- [ ] 所有状态转换后`Auction.status`都是`ended`

## 故障排查

### 问题：拍卖已结束但状态仍是active

**解决：**
```
访问 sync_auction_outcomes.php 手动同步
或运行 close_expired_auctions.php
```

### 问题：卖家决策超时但未自动处理

**解决：**
```
访问 cron_expire_decisions.php 手动处理
检查定时任务是否正确设置
```

### 问题：AuctionOutcome缺失

**解决：**
```
访问 sync_auction_outcomes.php
系统会为缺失的记录重新创建
```

## 总结

该系统确保：
1. ✅ 拍卖结束时自动更新状态为`ended`并同步到`AuctionOutcome`
2. ✅ 最高出价高于保留价时自动完成交易
3. ✅ 最高出价低于保留价时给予卖家24小时决策时间
4. ✅ 卖家接受或拒绝后，拍卖状态保持`ended`
5. ✅ 卖家超时未决策时自动拒绝并保持状态`ended`
6. ✅ 所有状态转换都在事务中完成，确保数据一致性
