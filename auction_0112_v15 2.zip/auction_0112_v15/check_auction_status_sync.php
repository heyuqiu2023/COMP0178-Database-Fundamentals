<?php
/**
 * 检查拍卖状态同步情况
 * 查找已结束但状态仍为active的拍卖
 */
require_once 'db_connection.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>检查拍卖状态同步</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        .warning { background-color: #fff3cd; }
        .success { background-color: #d4edda; }
        .error { background-color: #f8d7da; }
    </style>
</head>
<body>
    <h1>拍卖状态同步检查</h1>
    
    <h2>1. 已结束但状态仍为active的拍卖</h2>
    <?php
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.end_time, a.reserve_price, a.seller_id,
               (SELECT MAX(bid_amount) FROM Bid WHERE auction_id = a.auction_id AND is_active = TRUE) as highest_bid,
               (SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = a.auction_id) as has_outcome
        FROM Auction a
        WHERE a.status = 'active' AND a.end_time <= NOW()
        ORDER BY a.end_time DESC
    ");
    $expired_active = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($expired_active) > 0) {
        echo "<p class='warning'>发现 " . count($expired_active) . " 个拍卖需要同步!</p>";
        echo "<table>";
        echo "<tr><th>拍卖ID</th><th>标题</th><th>状态</th><th>结束时间</th><th>保留价</th><th>最高出价</th><th>有Outcome</th></tr>";
        foreach ($expired_active as $row) {
            echo "<tr class='warning'>";
            echo "<td>" . $row['auction_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td>" . $row['end_time'] . "</td>";
            echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
            echo "<td>" . ($row['highest_bid'] ? "£" . number_format($row['highest_bid'], 2) : "无出价") . "</td>";
            echo "<td>" . ($row['has_outcome'] ? "是" : "否") . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='success'>✓ 所有拍卖状态正常!</p>";
    }
    ?>
    
    <h2>2. 已结束的拍卖及其Outcome状态</h2>
    <?php
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.status, a.end_time, a.reserve_price,
               ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline,
               (CASE 
                   WHEN ao.reserve_met = TRUE THEN '已达保留价'
                   WHEN ao.reserve_met = FALSE AND ao.seller_accepted = TRUE THEN '卖家已接受'
                   WHEN ao.reserve_met = FALSE AND ao.seller_accepted = FALSE AND ao.winner_id IS NULL THEN '已拒绝/超时'
                   WHEN ao.reserve_met = FALSE AND ao.seller_accepted = FALSE AND ao.winner_id IS NOT NULL THEN '等待卖家决策'
                   ELSE '未知'
               END) as outcome_status
        FROM Auction a
        LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
        WHERE a.end_time <= NOW()
        ORDER BY a.auction_id DESC
        LIMIT 20
    ");
    $ended_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table>";
    echo "<tr><th>拍卖ID</th><th>标题</th><th>Auction状态</th><th>结束时间</th><th>保留价</th><th>最终价格</th><th>Outcome状态</th><th>决策截止</th></tr>";
    foreach ($ended_auctions as $row) {
        $class = ($row['status'] === 'active') ? 'warning' : 'success';
        echo "<tr class='$class'>";
        echo "<td>" . $row['auction_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "<td><strong>" . $row['status'] . "</strong></td>";
        echo "<td>" . $row['end_time'] . "</td>";
        echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
        echo "<td>" . ($row['final_price'] ? "£" . number_format($row['final_price'], 2) : "N/A") . "</td>";
        echo "<td>" . ($row['outcome_status'] ?? 'N/A') . "</td>";
        echo "<td>" . ($row['acceptance_deadline'] ?? 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    ?>
    
    <h2>3. 等待卖家决策的拍卖</h2>
    <?php
    $stmt = $pdo->query("
        SELECT a.auction_id, a.title, a.seller_id, a.reserve_price,
               ao.final_price, ao.acceptance_deadline,
               TIMESTAMPDIFF(HOUR, NOW(), ao.acceptance_deadline) as hours_remaining
        FROM Auction a
        JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
        WHERE a.status = 'ended'
          AND ao.reserve_met = FALSE
          AND ao.seller_accepted = FALSE
          AND ao.winner_id IS NOT NULL
        ORDER BY ao.acceptance_deadline ASC
    ");
    $pending_decisions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($pending_decisions) > 0) {
        echo "<table>";
        echo "<tr><th>拍卖ID</th><th>标题</th><th>保留价</th><th>最高出价</th><th>剩余时间</th><th>决策截止</th></tr>";
        foreach ($pending_decisions as $row) {
            $class = $row['hours_remaining'] < 0 ? 'error' : 'warning';
            echo "<tr class='$class'>";
            echo "<td>" . $row['auction_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
            echo "<td>£" . number_format($row['final_price'], 2) . "</td>";
            echo "<td>" . $row['hours_remaining'] . " 小时</td>";
            echo "<td>" . $row['acceptance_deadline'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='success'>✓ 没有等待卖家决策的拍卖</p>";
    }
    ?>
    
    <hr>
    <p><a href="sync_auction_outcomes.php">执行同步 &raquo;</a></p>
</body>
</html>
