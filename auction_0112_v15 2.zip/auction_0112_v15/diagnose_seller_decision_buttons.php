<?php
/**
 * 诊断特定拍卖为什么不显示决策按钮
 */
require_once 'db_connection.php';

$auction_id = isset($_GET['auction_id']) ? intval($_GET['auction_id']) : 0;
if (!$auction_id) {
    die("请提供拍卖ID: ?auction_id=X");
}

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>诊断拍卖 #<?php echo $auction_id; ?></title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .success { background: #d4edda; border-color: #c3e6cb; }
        .error { background: #f8d7da; border-color: #f5c6cb; }
        .warning { background: #fff3cd; border-color: #ffeaa7; }
        .info { background: #d1ecf1; border-color: #bee5eb; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
        .fix-btn { padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
        .fix-btn:hover { background: #218838; }
    </style>
</head>
<body>
    <h1>诊断拍卖 #<?php echo $auction_id; ?> - 决策按钮显示问题</h1>
    
    <?php
    // 查询拍卖信息
    $stmt = $pdo->prepare("
        SELECT a.*, 
               (SELECT MAX(bid_amount) FROM Bid WHERE auction_id = a.auction_id AND is_active = TRUE) as highest_bid,
               (SELECT COUNT(*) FROM Bid WHERE auction_id = a.auction_id AND is_active = TRUE) as bid_count
        FROM Auction a
        WHERE a.auction_id = ?
    ");
    $stmt->execute([$auction_id]);
    $auction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auction) {
        echo "<div class='section error'><h2>错误</h2><p>未找到拍卖ID $auction_id</p></div>";
        exit;
    }
    
    // 查询 AuctionOutcome
    $outcome_stmt = $pdo->prepare("SELECT * FROM AuctionOutcome WHERE auction_id = ?");
    $outcome_stmt->execute([$auction_id]);
    $outcome = $outcome_stmt->fetch(PDO::FETCH_ASSOC);
    
    // 分析状态
    $issues = [];
    $suggestions = [];
    
    $end_time = new DateTime($auction['end_time']);
    $now = new DateTime();
    $is_expired = $now >= $end_time;
    
    echo "<div class='section info'>";
    echo "<h2>1. 拍卖基本信息</h2>";
    echo "<table>";
    echo "<tr><th>字段</th><th>值</th></tr>";
    echo "<tr><td>拍卖ID</td><td>{$auction['auction_id']}</td></tr>";
    echo "<tr><td>标题</td><td>" . htmlspecialchars($auction['title']) . "</td></tr>";
    echo "<tr><td>卖家ID</td><td>{$auction['seller_id']}</td></tr>";
    echo "<tr><td><strong>状态 (status)</strong></td><td><strong>{$auction['status']}</strong></td></tr>";
    echo "<tr><td>结束时间</td><td>{$auction['end_time']}</td></tr>";
    echo "<tr><td>当前时间</td><td>" . $now->format('Y-m-d H:i:s') . "</td></tr>";
    echo "<tr><td>是否已过期</td><td>" . ($is_expired ? '<span style="color:red;">是</span>' : '否') . "</td></tr>";
    echo "<tr><td>保留价</td><td>£" . number_format($auction['reserve_price'], 2) . "</td></tr>";
    echo "<tr><td>最高出价</td><td>" . ($auction['highest_bid'] ? "£" . number_format($auction['highest_bid'], 2) : '无') . "</td></tr>";
    echo "<tr><td>出价数量</td><td>{$auction['bid_count']}</td></tr>";
    echo "</table>";
    echo "</div>";
    
    // 检查问题1: 状态是否为ended
    if ($auction['status'] !== 'ended' && $is_expired) {
        $issues[] = "拍卖已过期但状态仍是 '{$auction['status']}'，应该是 'ended'";
        $suggestions[] = "需要运行同步脚本更新状态";
    }
    
    // 检查问题2: 是否有AuctionOutcome
    echo "<div class='section " . ($outcome ? 'success' : 'error') . "'>";
    echo "<h2>2. AuctionOutcome 记录</h2>";
    if ($outcome) {
        echo "<p>✓ 找到 AuctionOutcome 记录</p>";
        echo "<table>";
        echo "<tr><th>字段</th><th>值</th></tr>";
        echo "<tr><td>outcome_id</td><td>{$outcome['outcome_id']}</td></tr>";
        echo "<tr><td>winner_id</td><td>" . ($outcome['winner_id'] ?? 'NULL') . "</td></tr>";
        echo "<tr><td>final_price</td><td>" . ($outcome['final_price'] ? "£" . number_format($outcome['final_price'], 2) : 'NULL') . "</td></tr>";
        echo "<tr><td><strong>reserve_met</strong></td><td><strong>" . ($outcome['reserve_met'] ? '是 (TRUE)' : '否 (FALSE)') . "</strong></td></tr>";
        echo "<tr><td><strong>seller_accepted</strong></td><td><strong>" . ($outcome['seller_accepted'] ? '是 (TRUE)' : '否 (FALSE)') . "</strong></td></tr>";
        echo "<tr><td>acceptance_deadline</td><td>{$outcome['acceptance_deadline']}</td></tr>";
        echo "<tr><td>concluded_at</td><td>{$outcome['concluded_at']}</td></tr>";
        echo "<tr><td>seller_notified</td><td>" . ($outcome['seller_notified'] ? '是' : '否') . "</td></tr>";
        echo "</table>";
    } else {
        $issues[] = "缺少 AuctionOutcome 记录";
        $suggestions[] = "需要运行同步脚本创建 AuctionOutcome";
        echo "<p>✗ 未找到 AuctionOutcome 记录</p>";
    }
    echo "</div>";
    
    // 检查问题3: 决策按钮显示条件
    echo "<div class='section info'>";
    echo "<h2>3. 决策按钮显示条件检查</h2>";
    echo "<p>要显示卖家决策按钮，需要满足以下<strong>所有</strong>条件：</p>";
    echo "<ol>";
    
    $condition1 = ($auction['status'] === 'ended');
    echo "<li>拍卖状态必须是 'ended': " . 
         ($condition1 ? "<span style='color:green;'>✓ 满足</span>" : "<span style='color:red;'>✗ 不满足 (当前: {$auction['status']})</span>") . "</li>";
    
    $condition2 = ($outcome !== false);
    echo "<li>必须有 AuctionOutcome 记录: " . 
         ($condition2 ? "<span style='color:green;'>✓ 满足</span>" : "<span style='color:red;'>✗ 不满足</span>") . "</li>";
    
    $condition3 = ($outcome && $outcome['winner_id']);
    echo "<li>必须有中标者 (winner_id IS NOT NULL): " . 
         ($condition3 ? "<span style='color:green;'>✓ 满足</span>" : "<span style='color:red;'>✗ 不满足</span>") . "</li>";
    
    $condition4 = ($outcome && !$outcome['reserve_met']);
    echo "<li>最高出价低于保留价 (reserve_met = FALSE): " . 
         ($condition4 ? "<span style='color:green;'>✓ 满足</span>" : "<span style='color:red;'>✗ 不满足</span>") . "</li>";
    
    $condition5 = ($outcome && !$outcome['seller_accepted']);
    echo "<li>卖家尚未接受 (seller_accepted = FALSE): " . 
         ($condition5 ? "<span style='color:green;'>✓ 满足</span>" : "<span style='color:red;'>✗ 不满足</span>") . "</li>";
    
    $deadline = $outcome ? new DateTime($outcome['acceptance_deadline']) : null;
    $condition6 = ($deadline && $now < $deadline);
    echo "<li>决策截止时间未到: " . 
         ($condition6 ? "<span style='color:green;'>✓ 满足</span>" : 
          "<span style='color:red;'>✗ 不满足 " . 
          ($deadline ? "(截止: {$outcome['acceptance_deadline']}, 当前: " . $now->format('Y-m-d H:i:s') . ")" : "(无截止时间)") . 
          "</span>") . "</li>";
    
    echo "</ol>";
    
    $all_conditions = $condition1 && $condition2 && $condition3 && $condition4 && $condition5 && $condition6;
    
    if ($all_conditions) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin-top: 15px;'>";
        echo "<strong style='color: green;'>✓ 所有条件都满足！决策按钮应该显示。</strong>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin-top: 15px;'>";
        echo "<strong style='color: red;'>✗ 不满足显示决策按钮的条件。</strong>";
        echo "</div>";
    }
    echo "</div>";
    
    // 问题汇总
    if (count($issues) > 0) {
        echo "<div class='section warning'>";
        echo "<h2>4. 发现的问题</h2>";
        echo "<ul>";
        foreach ($issues as $issue) {
            echo "<li>$issue</li>";
        }
        echo "</ul>";
        echo "</div>";
        
        echo "<div class='section info'>";
        echo "<h2>5. 修复建议</h2>";
        echo "<ul>";
        foreach ($suggestions as $suggestion) {
            echo "<li>$suggestion</li>";
        }
        echo "</ul>";
        
        echo "<h3>修复操作</h3>";
        echo "<a href='sync_auction_outcomes.php' class='fix-btn'>运行状态同步</a>";
        echo "<a href='test_auction_sync.php' class='fix-btn' style='background:#007bff;'>运行完整测试</a>";
        echo "</div>";
    } else {
        echo "<div class='section success'>";
        echo "<h2>4. 诊断结果</h2>";
        echo "<p><strong>✓ 未发现技术问题</strong></p>";
        if ($all_conditions) {
            echo "<p>所有条件都满足，决策按钮应该在 <a href='listing.php?auction_id=$auction_id'>listing.php?auction_id=$auction_id</a> 页面显示。</p>";
            echo "<p>如果您以卖家身份登录，应该能看到 <strong>Accept Bid</strong> 和 <strong>Reject Bid</strong> 按钮。</p>";
        } else {
            echo "<p>当前不满足显示决策按钮的条件，这是正常的。</p>";
        }
        echo "</div>";
    }
    
    // 生成修复SQL（如果需要）
    if ($auction['status'] !== 'ended' && $is_expired) {
        echo "<div class='section info'>";
        echo "<h2>6. 手动修复SQL（如果自动同步失败）</h2>";
        echo "<pre>";
        echo "-- 更新拍卖状态为 ended\n";
        echo "UPDATE Auction SET status = 'ended' WHERE auction_id = $auction_id;\n\n";
        
        if (!$outcome && $auction['highest_bid']) {
            $reserve_met = ($auction['highest_bid'] >= $auction['reserve_price']) ? 'TRUE' : 'FALSE';
            $seller_accepted = ($auction['highest_bid'] >= $auction['reserve_price']) ? 'TRUE' : 'FALSE';
            $deadline = (new DateTime())->modify('+24 hours')->format('Y-m-d H:i:s');
            
            echo "-- 创建 AuctionOutcome 记录\n";
            echo "INSERT INTO AuctionOutcome \n";
            echo "  (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at)\n";
            echo "SELECT \n";
            echo "  $auction_id,\n";
            echo "  bidder_id,\n";
            echo "  bid_amount,\n";
            echo "  $reserve_met,\n";
            echo "  $seller_accepted,\n";
            echo "  '$deadline',\n";
            echo "  NOW()\n";
            echo "FROM Bid\n";
            echo "WHERE auction_id = $auction_id AND is_active = TRUE\n";
            echo "ORDER BY bid_amount DESC, bid_time ASC\n";
            echo "LIMIT 1;\n";
        }
        echo "</pre>";
        echo "</div>";
    }
    ?>
    
    <hr>
    <p>
        <a href="listing.php?auction_id=<?php echo $auction_id; ?>">查看拍卖详情页</a> | 
        <a href="check_auction_status_sync.php">状态检查页面</a> | 
        <a href="auction_sync_dashboard.php">同步控制面板</a>
    </p>
</body>
</html>
