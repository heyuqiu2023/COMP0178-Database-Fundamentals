<?php
/**
 * 测试脚本：验证 Bid 表中 is_active 字段的更新逻辑
 */

require_once 'db_connection.php';

echo "=== Bid is_active 字段更新验证 ===\n\n";

// 1. 检查 Bid 表结构
echo "1. 检查 Bid 表结构...\n";
$stmt = $pdo->query("DESCRIBE Bid");
$columns = $stmt->fetchAll(PDO::FETCH_ASSOC);

$has_is_active = false;
foreach ($columns as $col) {
    if ($col['Field'] === 'is_active') {
        $has_is_active = true;
        echo "  ✓ is_active 字段存在 (类型: {$col['Type']}, 默认: {$col['Default']})\n";
        break;
    }
}

if (!$has_is_active) {
    echo "  ✗ is_active 字段不存在！\n";
    exit(1);
}

// 2. 查看所有拍卖的出价状态
echo "\n2. 检查拍卖的出价状态...\n";
$stmt = $pdo->query("
    SELECT a.auction_id, a.title, a.status,
           COUNT(b.bid_id) as total_bids,
           SUM(CASE WHEN b.is_active = TRUE THEN 1 ELSE 0 END) as active_bids,
           MAX(b.bid_amount) as highest_bid
    FROM Auction a
    LEFT JOIN Bid b ON a.auction_id = b.auction_id
    GROUP BY a.auction_id, a.title, a.status
    HAVING total_bids > 0
    ORDER BY a.auction_id DESC
    LIMIT 10
");

$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($auctions) > 0) {
    echo "最近有出价的拍卖：\n";
    foreach ($auctions as $auction) {
        $status_icon = $auction['status'] === 'active' ? '🟢' : '🔴';
        echo "\n  $status_icon 拍卖 #{$auction['auction_id']}: {$auction['title']}\n";
        echo "    状态: {$auction['status']}\n";
        echo "    总出价数: {$auction['total_bids']}\n";
        echo "    活跃出价数: {$auction['active_bids']}\n";
        echo "    最高出价: £{$auction['highest_bid']}\n";
        
        // 检查逻辑正确性
        if ($auction['status'] === 'active') {
            // 活跃拍卖应该只有1个活跃出价（最高的那个）
            if ($auction['active_bids'] != 1 && $auction['total_bids'] > 1) {
                echo "    ⚠️ 警告: 活跃拍卖应该只有1个活跃出价，但现在有 {$auction['active_bids']} 个\n";
            } elseif ($auction['active_bids'] == 1) {
                echo "    ✓ 正确: 只有最高出价是活跃的\n";
            }
        } elseif ($auction['status'] === 'ended') {
            // 已结束的拍卖可能有1个活跃出价（赢家）或0个（被拒绝）
            if ($auction['active_bids'] > 1) {
                echo "    ⚠️ 警告: 已结束的拍卖有 {$auction['active_bids']} 个活跃出价\n";
            } elseif ($auction['active_bids'] == 1) {
                echo "    ✓ 有1个获胜出价\n";
            } else {
                echo "    ℹ️ 所有出价都已失效（可能被卖家拒绝）\n";
            }
        }
    }
} else {
    echo "  没有找到有出价的拍卖\n";
}

// 3. 检查具体的出价详情
echo "\n3. 检查最近的出价详情...\n";
$stmt = $pdo->query("
    SELECT b.bid_id, b.auction_id, a.title, b.bidder_id, u.username,
           b.bid_amount, b.is_active, b.bid_time,
           a.status as auction_status
    FROM Bid b
    JOIN Auction a ON b.auction_id = a.auction_id
    JOIN User u ON b.bidder_id = u.user_id
    ORDER BY b.bid_time DESC
    LIMIT 20
");

$bids = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($bids) > 0) {
    $current_auction = null;
    foreach ($bids as $bid) {
        if ($current_auction !== $bid['auction_id']) {
            $current_auction = $bid['auction_id'];
            echo "\n  拍卖 #{$bid['auction_id']}: {$bid['title']} ({$bid['auction_status']})\n";
        }
        
        $active_icon = $bid['is_active'] ? '✓' : '✗';
        $active_text = $bid['is_active'] ? 'ACTIVE' : 'inactive';
        
        echo "    $active_icon Bid #{$bid['bid_id']}: £{$bid['bid_amount']} by {$bid['username']} [$active_text] ({$bid['bid_time']})\n";
    }
} else {
    echo "  没有找到出价记录\n";
}

// 4. 检查被"outbid"的出价状态
echo "\n4. 检查被超过的出价...\n";
$stmt = $pdo->query("
    SELECT b1.bid_id, b1.auction_id, a.title, b1.bid_amount, 
           b1.is_active, b1.bid_time,
           MAX(b2.bid_amount) as higher_bid
    FROM Bid b1
    JOIN Auction a ON b1.auction_id = a.auction_id
    LEFT JOIN Bid b2 ON b1.auction_id = b2.auction_id 
                     AND b2.bid_amount > b1.bid_amount
    WHERE a.status = 'active'
    GROUP BY b1.bid_id, b1.auction_id, a.title, b1.bid_amount, b1.is_active, b1.bid_time
    HAVING higher_bid IS NOT NULL
    ORDER BY b1.bid_time DESC
    LIMIT 10
");

$outbid = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($outbid) > 0) {
    echo "找到 " . count($outbid) . " 个被超过的出价：\n";
    foreach ($outbid as $bid) {
        $status_icon = !$bid['is_active'] ? '✓' : '✗';
        $status_text = !$bid['is_active'] ? '正确（已标记为失效）' : '错误（仍然活跃）';
        
        echo "\n  $status_icon 拍卖 #{$bid['auction_id']}: {$bid['title']}\n";
        echo "    出价: £{$bid['bid_amount']} (被超过为 £{$bid['higher_bid']})\n";
        echo "    状态: $status_text\n";
    }
} else {
    echo "  ✓ 没有发现被超过的出价（或所有出价都已正确标记）\n";
}

// 5. 总结和建议
echo "\n" . str_repeat("=", 60) . "\n";
echo "功能实现总结\n";
echo str_repeat("=", 60) . "\n";

echo "\n✅ 已实现的功能：\n";
echo "1. place_bid.php: 新出价时自动将之前的出价标记为 is_active = FALSE\n";
echo "2. accept_bid.php: 卖家拒绝时将所有出价标记为 is_active = FALSE\n";
echo "3. cron_expire_decisions.php: 超时未决策时将所有出价标记为 is_active = FALSE\n";

echo "\n📋 is_active 状态说明：\n";
echo "- TRUE:  当前活跃的出价（最高出价或获胜出价）\n";
echo "- FALSE: 已被超过、拒绝或拍卖失败的出价\n";

echo "\n🔍 用途：\n";
echo "- 快速找到当前最高出价: WHERE is_active = TRUE\n";
echo "- 显示用户的活跃出价: WHERE bidder_id = ? AND is_active = TRUE\n";
echo "- 统计有效竞价: COUNT(*) WHERE is_active = TRUE\n";

echo "\n" . str_repeat("=", 60) . "\n";
?>
