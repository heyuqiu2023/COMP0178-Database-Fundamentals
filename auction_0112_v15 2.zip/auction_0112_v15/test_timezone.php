<?php
session_start();
require_once 'db_connection.php';

// 允许用户设置时区
if (isset($_POST['set_timezone'])) {
    $_SESSION['timezone'] = $_POST['timezone'];
    header('Location: test_timezone.php');
    exit;
}

$user_timezone = $_SESSION['timezone'] ?? date_default_timezone_get();
$user_tz = new DateTimeZone($user_timezone);

// 获取一些常用时区
$common_timezones = [
    'UTC' => 'UTC',
    'America/New_York' => 'New York (EST/EDT)',
    'America/Los_Angeles' => 'Los Angeles (PST/PDT)',
    'America/Chicago' => 'Chicago (CST/CDT)',
    'Europe/London' => 'London (GMT/BST)',
    'Europe/Paris' => 'Paris (CET/CEST)',
    'Asia/Shanghai' => 'Shanghai (CST)',
    'Asia/Tokyo' => 'Tokyo (JST)',
    'Asia/Hong_Kong' => 'Hong Kong (HKT)',
    'Australia/Sydney' => 'Sydney (AEST/AEDT)',
];

include_once('header.php');
?>

<div class="container mt-4">
    <h2>时区测试页面</h2>
    
    <div class="card mb-4">
        <div class="card-header">
            <h4>当前时区设置</h4>
        </div>
        <div class="card-body">
            <p><strong>Session 时区:</strong> <?php echo htmlspecialchars($user_timezone); ?></p>
            <p><strong>服务器默认时区:</strong> <?php echo htmlspecialchars(date_default_timezone_get()); ?></p>
            <p><strong>当前时间 (用户时区):</strong> <?php echo (new DateTime('now', $user_tz))->format('Y-m-d H:i:s'); ?></p>
            <p><strong>当前时间 (UTC):</strong> <?php echo (new DateTime('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s'); ?></p>
            <p><strong>浏览器时区:</strong> <span id="browserTz"></span></p>
            <p><strong>浏览器时间:</strong> <span id="browserTime"></span></p>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-header">
            <h4>更改时区</h4>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label for="timezone">选择时区:</label>
                    <select class="form-control" id="timezone" name="timezone" required>
                        <?php foreach ($common_timezones as $tz => $label): ?>
                            <option value="<?php echo htmlspecialchars($tz); ?>" 
                                    <?php echo ($tz === $user_timezone) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" name="set_timezone" class="btn btn-primary">设置时区</button>
            </form>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-header">
            <h4>最近的拍卖（测试时区显示）</h4>
        </div>
        <div class="card-body">
            <?php
            $stmt = $pdo->query("
                SELECT auction_id, title, end_time, status
                FROM Auction
                ORDER BY created_at DESC
                LIMIT 5
            ");
            $auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($auctions) > 0) {
                echo '<table class="table table-bordered">';
                echo '<thead><tr><th>ID</th><th>标题</th><th>结束时间 (数据库)</th><th>结束时间 (用户时区)</th><th>状态</th></tr></thead>';
                echo '<tbody>';
                foreach ($auctions as $auction) {
                    $end_time_db = $auction['end_time'];
                    $end_time_obj = new DateTime($end_time_db, $user_tz);
                    $end_time_display = $end_time_obj->format('Y-m-d H:i:s');
                    
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($auction['auction_id']) . '</td>';
                    echo '<td>' . htmlspecialchars($auction['title']) . '</td>';
                    echo '<td>' . htmlspecialchars($end_time_db) . '</td>';
                    echo '<td>' . htmlspecialchars($end_time_display) . ' <small>(' . htmlspecialchars($user_timezone) . ')</small></td>';
                    echo '<td>' . htmlspecialchars($auction['status']) . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<p>没有找到拍卖</p>';
            }
            ?>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-header">
            <h4>时区转换示例</h4>
        </div>
        <div class="card-body">
            <?php
            $now = new DateTime('now');
            echo '<p><strong>示例时间点:</strong> 2025-12-25 12:00:00</p>';
            echo '<table class="table table-sm">';
            echo '<thead><tr><th>时区</th><th>本地时间</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($common_timezones as $tz => $label) {
                try {
                    $dt = new DateTime('2025-12-25 12:00:00', new DateTimeZone('UTC'));
                    $dt->setTimezone(new DateTimeZone($tz));
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($label) . '</td>';
                    echo '<td>' . $dt->format('Y-m-d H:i:s') . '</td>';
                    echo '</tr>';
                } catch (Exception $e) {
                    echo '<tr><td colspan="2">Error: ' . htmlspecialchars($e->getMessage()) . '</td></tr>';
                }
            }
            
            echo '</tbody></table>';
            ?>
        </div>
    </div>
</div>

<script>
// 显示浏览器时区信息
document.addEventListener('DOMContentLoaded', function() {
    var browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    document.getElementById('browserTz').textContent = browserTz || 'Unknown';
    
    function updateBrowserTime() {
        var now = new Date();
        document.getElementById('browserTime').textContent = now.toLocaleString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
    }
    
    updateBrowserTime();
    setInterval(updateBrowserTime, 1000);
});
</script>

<?php include_once('footer.php'); ?>
