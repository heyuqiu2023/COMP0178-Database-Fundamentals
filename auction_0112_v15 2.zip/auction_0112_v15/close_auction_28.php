<?php
require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "<h2>Closing Auction #28</h2>";

try {
    $pdo->beginTransaction();
    
    // Get auction data
    $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = 28");
    $stmt->execute();
    $auction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auction) {
        throw new Exception("Auction #28 not found");
    }
    
    echo "<p>Found auction: " . htmlspecialchars($auction['title']) . "</p>";
    echo "<p>Current status: <strong>" . $auction['status'] . "</strong></p>";
    echo "<p>End time: " . $auction['end_time'] . "</p>";
    
    if ($auction['status'] !== 'active') {
        echo "<p style='color: orange;'>Auction is already closed.</p>";
    } else {
        echo "<p>Closing auction...</p>";
        closeAuction($pdo, $auction);
        echo "<p style='color: green;'><strong>✓ Auction closed successfully!</strong></p>";
    }
    
    $pdo->commit();
    
    // Show updated status
    $stmt = $pdo->prepare("SELECT a.*, ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline,
                           u.username AS winner_name
                           FROM Auction a
                           LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                           LEFT JOIN User u ON ao.winner_id = u.user_id
                           WHERE a.auction_id = 28");
    $stmt->execute();
    $updated = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<hr>";
    echo "<h3>Updated Status:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Value</th></tr>";
    echo "<tr><td>Status</td><td><strong>" . $updated['status'] . "</strong></td></tr>";
    echo "<tr><td>Winner ID</td><td>" . ($updated['winner_id'] ?? 'NULL') . "</td></tr>";
    echo "<tr><td>Winner Name</td><td>" . ($updated['winner_name'] ?? 'N/A') . "</td></tr>";
    echo "<tr><td>Final Price</td><td>£" . number_format($updated['final_price'] ?? 0, 2) . "</td></tr>";
    echo "<tr><td>Reserve Met</td><td>" . ($updated['reserve_met'] ? 'YES' : 'NO') . "</td></tr>";
    echo "<tr><td>Seller Accepted</td><td>" . ($updated['seller_accepted'] ? 'YES' : 'NO') . "</td></tr>";
    echo "<tr><td>Acceptance Deadline</td><td>" . ($updated['acceptance_deadline'] ?? 'N/A') . "</td></tr>";
    echo "</table>";
    
    echo "<hr>";
    echo "<p><strong><a href='listing.php?auction_id=28'>→ View Auction #28 Listing Page</a></strong></p>";
    echo "<p><a href='seller_decision_dashboard.php'>→ Seller Decision Dashboard</a></p>";
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo "<p style='color: red;'><strong>Error:</strong> " . $e->getMessage() . "</p>";
}
?>
