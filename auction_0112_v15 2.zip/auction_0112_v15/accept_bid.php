<?php
session_start();
require_once 'db_connection.php';
require_once 'utilities.php';

// Check if user is logged in and is a seller
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['account_type'] !== 'seller') {
    header('Location: index.php');
    exit();
}

$seller_id = $_SESSION['user_id'];
$auction_id = isset($_GET['auction_id']) ? intval($_GET['auction_id']) : 0;
$action = isset($_GET['action']) ? $_GET['action'] : ''; // 'accept' or 'reject'

if (!$auction_id || !in_array($action, ['accept', 'reject'])) {
    $_SESSION['error_message'] = 'Invalid request.';
    header('Location: mylistings.php');
    exit();
}

try {
    $pdo->beginTransaction();
    
    // Verify that this auction belongs to the current seller
    $stmt = $pdo->prepare("SELECT a.auction_id, a.title, a.seller_id, a.status, a.reserve_price 
                           FROM Auction a 
                           WHERE a.auction_id = ? AND a.seller_id = ? FOR UPDATE");
    $stmt->execute([$auction_id, $seller_id]);
    $auction = $stmt->fetch();
    
    if (!$auction) {
        throw new Exception('Auction not found or you do not have permission to modify it.');
    }
    
    if ($auction['status'] !== 'ended') {
        throw new Exception('This auction has not ended yet.');
    }
    
    // Get the AuctionOutcome record
    $stmt = $pdo->prepare("SELECT * FROM AuctionOutcome WHERE auction_id = ? FOR UPDATE");
    $stmt->execute([$auction_id]);
    $outcome = $stmt->fetch();
    
    if (!$outcome) {
        throw new Exception('Auction outcome record not found.');
    }
    
    // Check if reserve price was already met (shouldn't need manual acceptance)
    if ($outcome['reserve_met']) {
        throw new Exception('This auction already met the reserve price and was automatically accepted.');
    }
    
    // Check if already accepted/rejected
    if ($outcome['seller_accepted']) {
        throw new Exception('You have already accepted this bid.');
    }
    
    // Check if deadline has passed
    $now = new DateTime();
    $deadline = new DateTime($outcome['acceptance_deadline']);
    if ($now > $deadline) {
        throw new Exception('The acceptance deadline has passed.');
    }
    
    // Ensure Auction status remains 'ended'
    $ensure_ended_stmt = $pdo->prepare("UPDATE Auction SET status = 'ended' WHERE auction_id = ?");
    $ensure_ended_stmt->execute([$auction_id]);
    
    // Update AuctionOutcome based on seller's decision
    if ($action === 'accept') {
        // Seller accepts the bid even though it's below reserve price
        $stmt = $pdo->prepare("UPDATE AuctionOutcome 
                               SET seller_accepted = TRUE, seller_notified = TRUE 
                               WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        
        // Notify winner that their bid was accepted
        if ($outcome['winner_id']) {
            require_once 'notify.php';
            queue_notification($outcome['winner_id'], $auction_id, null, 'winner_confirmed', 
                "Congratulations! The seller has accepted your bid of £{$outcome['final_price']} for '{$auction['title']}'.");
            queue_notification($seller_id, $auction_id, null, 'auction_ended', 
                "You have accepted the bid of £{$outcome['final_price']} for '{$auction['title']}'.");
        }
        
        $_SESSION['success_message'] = 'You have accepted the bid for "' . htmlspecialchars($auction['title']) . '". The buyer will be notified.';
        
    } else { // reject
        // Seller rejects the bid - set winner_id to NULL and mark as rejected
        $stmt = $pdo->prepare("UPDATE AuctionOutcome 
                               SET seller_accepted = FALSE, winner_id = NULL, final_price = NULL, seller_notified = TRUE 
                               WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        
        // Update all bids for this auction to is_active = FALSE (auction failed due to seller rejection)
        $stmt = $pdo->prepare("UPDATE Bid SET is_active = FALSE WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        
        // Notify the bidder that their bid was rejected
        if ($outcome['winner_id']) {
            require_once 'notify.php';
            $notification_msg = "The seller has rejected your bid of £{$outcome['final_price']} for '{$auction['title']}'. The auction has been marked as unsuccessful.";
            queue_notification($outcome['winner_id'], $auction_id, null, 'auction_ended', $notification_msg);
        }
        
        $_SESSION['success_message'] = 'You have rejected the bid for "' . htmlspecialchars($auction['title']) . '". The auction has been marked as unsuccessful and the bidder will be notified.';
    }
    
    $pdo->commit();
    header('Location: mylistings.php');
    exit();
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['error_message'] = $e->getMessage();
    header('Location: mylistings.php');
    exit();
}
?>
