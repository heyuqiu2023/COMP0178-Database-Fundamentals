<?php
require_once 'db_connection.php';

echo "=== Checking Specific Auction (cloth) ===\n\n";

// Find the auction by title
$stmt = $pdo->prepare("SELECT * FROM Auction WHERE title LIKE '%cloth%' ORDER BY auction_id DESC LIMIT 1");
$stmt->execute();
$auction = $stmt->fetch(PDO::FETCH_ASSOC);

if ($auction) {
    echo "Found Auction:\n";
    echo "  ID: {$auction['auction_id']}\n";
    echo "  Title: {$auction['title']}\n";
    echo "  Status: {$auction['status']}\n";
    echo "  Starting Price: {$auction['starting_price']}\n";
    echo "  Reserve Price: " . ($auction['reserve_price'] ?? 'NULL') . "\n";
    echo "  End Time: {$auction['end_time']}\n";
    echo "  Current Time: " . date('Y-m-d H:i:s') . "\n";
    echo "  Has Ended: " . (strtotime($auction['end_time']) < time() ? 'Yes' : 'No') . "\n";
    echo "\n";
    
    // Check bids
    $bid_stmt = $pdo->prepare("SELECT * FROM Bid WHERE auction_id = ? ORDER BY bid_amount DESC");
    $bid_stmt->execute([$auction['auction_id']]);
    $bids = $bid_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Bids for this auction: " . count($bids) . "\n";
    foreach ($bids as $bid) {
        echo "  Bid #{$bid['bid_id']}: £{$bid['bid_amount']} by user #{$bid['bidder_id']} at {$bid['bid_time']} (active: " . ($bid['is_active'] ? 'Yes' : 'No') . ")\n";
    }
    echo "\n";
    
    // Check if outcome exists
    $outcome_stmt = $pdo->prepare("SELECT * FROM AuctionOutcome WHERE auction_id = ?");
    $outcome_stmt->execute([$auction['auction_id']]);
    $outcome = $outcome_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($outcome) {
        echo "AuctionOutcome exists:\n";
        echo "  Outcome ID: {$outcome['outcome_id']}\n";
        echo "  Winner ID: " . ($outcome['winner_id'] ?? 'NULL') . "\n";
        echo "  Final Price: " . ($outcome['final_price'] ?? 'NULL') . "\n";
        echo "  Reserve Met: " . ($outcome['reserve_met'] ? 'Yes' : 'No') . "\n";
        echo "  Seller Accepted: " . ($outcome['seller_accepted'] ? 'Yes' : 'No') . "\n";
    } else {
        echo "No AuctionOutcome found for this auction!\n";
        
        // If auction has ended, create the outcome now
        if ($auction['status'] === 'ended' || strtotime($auction['end_time']) < time()) {
            echo "\nCreating AuctionOutcome now...\n";
            
            try {
                require_once 'notify.php';
                $pdo->beginTransaction();
                
                // If status is still active but time has passed, update it first
                if ($auction['status'] === 'active') {
                    $pdo->prepare("UPDATE Auction SET status = 'ended' WHERE auction_id = ?")->execute([$auction['auction_id']]);
                    echo "Updated auction status to 'ended'\n";
                }
                
                // Get highest bid
                $highest_bid = null;
                if (count($bids) > 0) {
                    foreach ($bids as $bid) {
                        if ($bid['is_active']) {
                            $highest_bid = $bid;
                            break;
                        }
                    }
                }
                
                $winner_id = $highest_bid ? $highest_bid['bidder_id'] : null;
                $final_price = $highest_bid ? $highest_bid['bid_amount'] : null;
                $reserve_price = $auction['reserve_price'];
                
                // Determine if reserve is met
                $reserve_met = false;
                if ($highest_bid && $reserve_price !== null) {
                    $reserve_met = ($final_price >= $reserve_price);
                } elseif ($highest_bid && $reserve_price === null) {
                    $reserve_met = true;
                }
                
                $seller_accepted = $reserve_met ? 1 : 0;
                $accept_deadline = date('Y-m-d H:i:s', strtotime('+24 hours'));
                
                // Insert outcome
                $insert_stmt = $pdo->prepare(
                    "INSERT INTO AuctionOutcome 
                    (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at, seller_notified, winner_notified)
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), 0, 0)"
                );
                $insert_stmt->execute([
                    $auction['auction_id'],
                    $winner_id,
                    $final_price,
                    $reserve_met,
                    $seller_accepted,
                    $accept_deadline
                ]);
                
                $pdo->commit();
                echo "Successfully created AuctionOutcome!\n";
                echo "  Winner ID: " . ($winner_id ?? 'NULL') . "\n";
                echo "  Final Price: " . ($final_price ?? 'NULL') . "\n";
                echo "  Reserve Met: " . ($reserve_met ? 'Yes' : 'No') . "\n";
                
            } catch (Exception $e) {
                $pdo->rollBack();
                echo "ERROR: " . $e->getMessage() . "\n";
                echo $e->getTraceAsString() . "\n";
            }
        }
    }
} else {
    echo "No auction found with 'cloth' in the title\n";
}

echo "\n=== Done ===\n";
?>
