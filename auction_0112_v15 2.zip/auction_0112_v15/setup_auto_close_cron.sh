#!/bin/bash
# 自动拍卖关闭系统 - 设置脚本
# 用于配置定时任务自动关闭到期拍卖

echo "=========================================="
echo "拍卖自动关闭系统 - 设置向导"
echo "=========================================="
echo ""

# 获取当前脚本目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PHP_BIN=$(which php)

if [ -z "$PHP_BIN" ]; then
    echo "❌ 错误: 未找到 PHP 可执行文件"
    echo "请先安装 PHP 或设置 PATH 环境变量"
    exit 1
fi

echo "✓ 找到 PHP: $PHP_BIN"
echo "✓ 项目目录: $SCRIPT_DIR"
echo ""

# 检查必要文件
echo "检查必要文件..."
REQUIRED_FILES=(
    "cron_close_auctions.php"
    "cron_expire_decisions.php"
    "auction_functions.php"
    "db_connection.php"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$SCRIPT_DIR/$file" ]; then
        echo "  ✓ $file"
    else
        echo "  ✗ $file (缺失)"
        exit 1
    fi
done
echo ""

# 创建日志目录
LOG_DIR="$SCRIPT_DIR/logs"
if [ ! -d "$LOG_DIR" ]; then
    mkdir -p "$LOG_DIR"
    echo "✓ 创建日志目录: $LOG_DIR"
fi

# 设置日志文件权限
touch "$LOG_DIR/cron_close_auctions.log"
touch "$LOG_DIR/cron_expire_decisions.log"
chmod 666 "$LOG_DIR"/*.log 2>/dev/null
echo "✓ 日志目录准备完成"
echo ""

# 生成 crontab 配置
echo "=========================================="
echo "推荐的 Crontab 配置"
echo "=========================================="
echo ""
echo "1. 自动关闭到期拍卖 (每5分钟)"
echo "   */5 * * * * $PHP_BIN $SCRIPT_DIR/cron_close_auctions.php >> $LOG_DIR/cron_close_auctions.log 2>&1"
echo ""
echo "2. 处理超时卖家决策 (每小时)"
echo "   0 * * * * $PHP_BIN $SCRIPT_DIR/cron_expire_decisions.php >> $LOG_DIR/cron_expire_decisions.log 2>&1"
echo ""

# 询问是否自动添加到 crontab
read -p "是否自动添加这些定时任务到 crontab? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    # 备份现有 crontab
    crontab -l > "$SCRIPT_DIR/crontab_backup_$(date +%Y%m%d_%H%M%S).txt" 2>/dev/null
    
    # 检查是否已存在相同的任务
    EXISTING=$(crontab -l 2>/dev/null | grep -c "cron_close_auctions.php")
    
    if [ "$EXISTING" -gt 0 ]; then
        echo "⚠ 警告: 检测到已存在的定时任务"
        read -p "是否替换现有配置? (y/n): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # 删除旧的相关任务
            crontab -l 2>/dev/null | grep -v "cron_close_auctions.php" | grep -v "cron_expire_decisions.php" | crontab -
            echo "✓ 已删除旧的定时任务"
        else
            echo "保持现有配置"
            exit 0
        fi
    fi
    
    # 添加新的定时任务
    (crontab -l 2>/dev/null; echo "# 拍卖自动关闭系统 - 自动添加于 $(date)") | crontab -
    (crontab -l 2>/dev/null; echo "*/5 * * * * $PHP_BIN $SCRIPT_DIR/cron_close_auctions.php >> $LOG_DIR/cron_close_auctions.log 2>&1") | crontab -
    (crontab -l 2>/dev/null; echo "0 * * * * $PHP_BIN $SCRIPT_DIR/cron_expire_decisions.php >> $LOG_DIR/cron_expire_decisions.log 2>&1") | crontab -
    
    echo "✓ 定时任务已添加到 crontab"
    echo ""
    echo "当前 crontab 配置:"
    crontab -l | grep -E "cron_close_auctions|cron_expire_decisions"
else
    echo "跳过自动配置"
    echo ""
    echo "请手动添加以下内容到 crontab (运行: crontab -e):"
    echo ""
    echo "*/5 * * * * $PHP_BIN $SCRIPT_DIR/cron_close_auctions.php >> $LOG_DIR/cron_close_auctions.log 2>&1"
    echo "0 * * * * $PHP_BIN $SCRIPT_DIR/cron_expire_decisions.php >> $LOG_DIR/cron_expire_decisions.log 2>&1"
fi

echo ""
echo "=========================================="
echo "测试运行"
echo "=========================================="
read -p "是否立即测试运行一次? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "运行 cron_close_auctions.php..."
    $PHP_BIN "$SCRIPT_DIR/cron_close_auctions.php"
    echo ""
    echo "运行 cron_expire_decisions.php..."
    $PHP_BIN "$SCRIPT_DIR/cron_expire_decisions.php"
fi

echo ""
echo "=========================================="
echo "设置完成！"
echo "=========================================="
echo ""
echo "监控命令:"
echo "  查看关闭日志: tail -f $LOG_DIR/cron_close_auctions.log"
echo "  查看决策日志: tail -f $LOG_DIR/cron_expire_decisions.log"
echo ""
echo "管理命令:"
echo "  查看定时任务: crontab -l"
echo "  编辑定时任务: crontab -e"
echo "  删除定时任务: crontab -r"
echo ""
echo "Web界面:"
echo "  控制面板: http://localhost/auction_0112_v14/auction_sync_dashboard.php"
echo "  状态监控: http://localhost/auction_0112_v14/monitor_auto_close.php"
echo ""
