<?php
/**
 * 同步拍卖状态到AuctionOutcome
 * 将已结束但状态仍为active的拍卖更新为ended，并创建AuctionOutcome记录
 */
require_once 'db_connection.php';
require_once 'auction_functions.php';

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>同步拍卖状态</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: green; }
        .error { color: red; }
        .info { color: blue; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>同步拍卖状态到AuctionOutcome</h1>
    
    <?php
    try {
        // 查找所有已结束但状态仍为active的拍卖
        $stmt = $pdo->query("
            SELECT * FROM Auction 
            WHERE status = 'active' 
            AND end_time <= NOW()
            ORDER BY auction_id
        ");
        $expired_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($expired_auctions) === 0) {
            echo "<p class='success'>✓ 没有需要同步的拍卖，所有拍卖状态都是最新的!</p>";
        } else {
            echo "<p class='info'>找到 " . count($expired_auctions) . " 个需要同步的拍卖...</p>";
            
            $success_count = 0;
            $error_count = 0;
            
            foreach ($expired_auctions as $auction) {
                echo "<hr>";
                echo "<h3>处理拍卖 #" . $auction['auction_id'] . " - " . htmlspecialchars($auction['title']) . "</h3>";
                echo "<pre>";
                echo "拍卖ID: " . $auction['auction_id'] . "\n";
                echo "标题: " . htmlspecialchars($auction['title']) . "\n";
                echo "卖家ID: " . $auction['seller_id'] . "\n";
                echo "结束时间: " . $auction['end_time'] . "\n";
                echo "当前状态: " . $auction['status'] . "\n";
                echo "保留价: £" . number_format($auction['reserve_price'], 2) . "\n";
                echo "</pre>";
                
                try {
                    $pdo->beginTransaction();
                    
                    // 使用closeAuction函数关闭拍卖
                    closeAuction($pdo, $auction);
                    
                    $pdo->commit();
                    
                    // 验证结果
                    $verify_stmt = $pdo->prepare("
                        SELECT a.status, ao.outcome_id, ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted
                        FROM Auction a
                        LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                        WHERE a.auction_id = ?
                    ");
                    $verify_stmt->execute([$auction['auction_id']]);
                    $result = $verify_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($result['status'] === 'ended' && $result['outcome_id']) {
                        echo "<p class='success'>✓ 成功同步!</p>";
                        echo "<pre>";
                        echo "Auction状态: " . $result['status'] . "\n";
                        echo "中标者ID: " . ($result['winner_id'] ?? '无') . "\n";
                        echo "最终价格: " . ($result['final_price'] ? "£" . number_format($result['final_price'], 2) : '无') . "\n";
                        echo "达到保留价: " . ($result['reserve_met'] ? '是' : '否') . "\n";
                        echo "卖家接受: " . ($result['seller_accepted'] ? '是' : '否/待定') . "\n";
                        echo "</pre>";
                        $success_count++;
                    } else {
                        echo "<p class='error'>✗ 同步失败: 状态未正确更新</p>";
                        $error_count++;
                    }
                    
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    echo "<p class='error'>✗ 错误: " . htmlspecialchars($e->getMessage()) . "</p>";
                    $error_count++;
                }
            }
            
            echo "<hr>";
            echo "<h2>同步总结</h2>";
            echo "<p>成功: <span class='success'>" . $success_count . "</span></p>";
            echo "<p>失败: <span class='error'>" . $error_count . "</span></p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>系统错误: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    ?>
    
    <hr>
    <p><a href="check_auction_status_sync.php">&laquo; 返回检查页面</a></p>
</body>
</html>
