<?php
/**
 * 测试 bid_received 通知功能
 * 验证卖家在收到出价时会收到通知
 */

require_once 'db_connection.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test Bid Received Notification</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
</head>
<body>
<div class='container mt-4'>
<h1>🔔 Test Bid Received Notification</h1>
<hr>";

// 查找最近的一些出价和对应的通知
$stmt = $pdo->query("
    SELECT 
        b.bid_id,
        b.auction_id,
        b.bidder_id,
        b.bid_amount,
        b.bid_time,
        a.title as auction_title,
        a.seller_id,
        u_bidder.username as bidder_name,
        u_seller.username as seller_name,
        (SELECT COUNT(*) FROM Notification 
         WHERE auction_id = b.auction_id 
         AND bid_id = b.bid_id 
         AND type = 'bid_received') as bid_received_notifications
    FROM Bid b
    JOIN Auction a ON b.auction_id = a.auction_id
    LEFT JOIN User u_bidder ON b.bidder_id = u_bidder.user_id
    LEFT JOIN User u_seller ON a.seller_id = u_seller.user_id
    ORDER BY b.bid_time DESC
    LIMIT 10
");

$bids = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h3>Recent Bids and Their Notifications</h3>";

if (empty($bids)) {
    echo "<div class='alert alert-info'>No bids found in the system.</div>";
} else {
    echo "<table class='table table-bordered table-hover'>";
    echo "<thead class='thead-light'>";
    echo "<tr>";
    echo "<th>Bid ID</th>";
    echo "<th>Auction</th>";
    echo "<th>Bidder</th>";
    echo "<th>Seller</th>";
    echo "<th>Amount</th>";
    echo "<th>Time</th>";
    echo "<th>Seller Notified</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($bids as $bid) {
        $has_notification = $bid['bid_received_notifications'] > 0;
        $row_class = $has_notification ? '' : 'table-warning';
        
        echo "<tr class='$row_class'>";
        echo "<td>{$bid['bid_id']}</td>";
        echo "<td><a href='listing.php?auction_id={$bid['auction_id']}' target='_blank'>" . 
             htmlspecialchars($bid['auction_title']) . "</a> (#{$bid['auction_id']})</td>";
        echo "<td>" . htmlspecialchars($bid['bidder_name']) . " (ID: {$bid['bidder_id']})</td>";
        echo "<td>" . htmlspecialchars($bid['seller_name']) . " (ID: {$bid['seller_id']})</td>";
        echo "<td>£" . number_format($bid['bid_amount'], 2) . "</td>";
        echo "<td>" . date('Y-m-d H:i:s', strtotime($bid['bid_time'])) . "</td>";
        echo "<td>";
        if ($has_notification) {
            echo "<span class='badge badge-success'>✓ Yes ({$bid['bid_received_notifications']})</span>";
        } else {
            echo "<span class='badge badge-danger'>✗ No</span>";
        }
        echo "</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    echo "</table>";
}

// 统计信息
echo "<hr>";
echo "<h3>Statistics</h3>";

$stats_stmt = $pdo->query("
    SELECT 
        COUNT(DISTINCT b.bid_id) as total_bids,
        COUNT(DISTINCT CASE WHEN n.notification_id IS NOT NULL THEN b.bid_id END) as bids_with_seller_notification,
        COUNT(DISTINCT n.notification_id) as total_bid_received_notifications
    FROM Bid b
    LEFT JOIN Notification n ON b.auction_id = n.auction_id 
                             AND b.bid_id = n.bid_id 
                             AND n.type = 'bid_received'
");

$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

echo "<div class='row'>";
echo "<div class='col-md-4'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h5 class='card-title'>Total Bids</h5>";
echo "<h2 class='text-primary'>{$stats['total_bids']}</h2>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<div class='col-md-4'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h5 class='card-title'>Bids with Seller Notification</h5>";
echo "<h2 class='text-success'>{$stats['bids_with_seller_notification']}</h2>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "<div class='col-md-4'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h5 class='card-title'>Total bid_received Notifications</h5>";
echo "<h2 class='text-info'>{$stats['total_bid_received_notifications']}</h2>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";

// 显示最近的 bid_received 通知详情
echo "<hr>";
echo "<h3>Recent bid_received Notifications</h3>";

$notif_stmt = $pdo->query("
    SELECT 
        n.notification_id,
        n.user_id,
        n.auction_id,
        n.bid_id,
        n.created_at,
        n.is_read,
        u.username as recipient_name,
        a.title as auction_title,
        b.bid_amount
    FROM Notification n
    JOIN User u ON n.user_id = u.user_id
    LEFT JOIN Auction a ON n.auction_id = a.auction_id
    LEFT JOIN Bid b ON n.bid_id = b.bid_id
    WHERE n.type = 'bid_received'
    ORDER BY n.created_at DESC
    LIMIT 20
");

$notifications = $notif_stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($notifications)) {
    echo "<div class='alert alert-warning'>No bid_received notifications found yet.</div>";
    echo "<p>Try placing a new bid to trigger a notification.</p>";
} else {
    echo "<table class='table table-sm table-bordered'>";
    echo "<thead class='thead-dark'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Recipient (Seller)</th>";
    echo "<th>Auction</th>";
    echo "<th>Bid Amount</th>";
    echo "<th>Created</th>";
    echo "<th>Read</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($notifications as $notif) {
        $read_class = $notif['is_read'] ? '' : 'font-weight-bold';
        
        echo "<tr class='$read_class'>";
        echo "<td>{$notif['notification_id']}</td>";
        echo "<td>" . htmlspecialchars($notif['recipient_name']) . " (ID: {$notif['user_id']})</td>";
        echo "<td><a href='listing.php?auction_id={$notif['auction_id']}' target='_blank'>" . 
             htmlspecialchars($notif['auction_title']) . "</a></td>";
        echo "<td>£" . number_format($notif['bid_amount'], 2) . "</td>";
        echo "<td>" . $notif['created_at'] . "</td>";
        echo "<td>" . ($notif['is_read'] ? '✓ Read' : '✗ Unread') . "</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    echo "</table>";
}

// 测试说明
echo "<hr>";
echo "<div class='card'>";
echo "<div class='card-header bg-info text-white'>";
echo "<h4 class='mb-0'>📋 How It Works</h4>";
echo "</div>";
echo "<div class='card-body'>";
echo "<h5>When a Bid is Placed:</h5>";
echo "<ol>";
echo "<li>Bidder places a bid on an auction</li>";
echo "<li>System creates notifications for:";
echo "<ul>";
echo "<li><strong>Bidder</strong>: 'new_bid' - Confirmation of bid placement</li>";
echo "<li><strong>Seller</strong>: <span class='badge badge-success'>bid_received</span> - Alert that someone bid on their auction</li>";
echo "<li><strong>Previous highest bidder</strong>: 'outbid' - Alert that they were outbid</li>";
echo "<li><strong>Watchers</strong>: 'new_bid' - Alert for users watching the auction</li>";
echo "</ul>";
echo "</li>";
echo "<li>Notifications are stored in the Notification table</li>";
echo "<li>Sellers can view their notifications at <a href='notifications.php'>notifications.php</a></li>";
echo "</ol>";

echo "<h5 class='mt-3'>Implementation Details:</h5>";
echo "<ul>";
echo "<li><strong>File Modified</strong>: <code>place_bid.php</code> - Added seller notification after bid insertion</li>";
echo "<li><strong>File Modified</strong>: <code>notify.php</code> - Added 'bid_received' case in email processing</li>";
echo "<li><strong>Notification Type</strong>: <code>bid_received</code></li>";
echo "<li><strong>Recipient</strong>: Auction seller (from Auction.seller_id)</li>";
echo "<li><strong>Trigger</strong>: Every time a valid bid is placed</li>";
echo "</ul>";
echo "</div>";
echo "</div>";

echo "<hr>";
echo "<div class='mt-3'>";
echo "<a href='browse.php' class='btn btn-primary'>Browse Auctions</a> ";
echo "<a href='notifications.php' class='btn btn-secondary'>View My Notifications</a> ";
echo "<a href='admin_tools.php' class='btn btn-outline-secondary'>Admin Tools</a>";
echo "</div>";

echo "</div></body></html>";
?>
