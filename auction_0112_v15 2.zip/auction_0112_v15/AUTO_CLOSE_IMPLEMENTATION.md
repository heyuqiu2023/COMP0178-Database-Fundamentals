# 拍卖自动关闭系统 - 实现文档

## 概述

本系统实现了拍卖到达结束时间后**自动同步更新状态为ended并同步到AuctionOutcome**的完整机制。

## 核心功能

### 1. 自动拍卖关闭

**触发条件：**
- `Auction.status = 'active'`
- `Auction.end_time <= NOW()`

**自动执行：**
1. 更新 `Auction.status = 'ended'`
2. 创建 `AuctionOutcome` 记录
3. 根据最高出价与保留价关系设置初始状态
4. 发送相关通知给卖家和中标者

### 2. 三种处理场景

#### 场景A：最高出价 ≥ 保留价
```
自动完成交易
├─ reserve_met = TRUE
├─ seller_accepted = TRUE
└─ 通知双方交易成功
```

#### 场景B：最高出价 < 保留价
```
等待卖家决策（24小时）
├─ reserve_met = FALSE
├─ seller_accepted = FALSE
├─ acceptance_deadline = 结束时间 + 24小时
└─ 通知卖家需要决策
```

#### 场景C：无出价
```
拍卖结束
├─ winner_id = NULL
├─ final_price = NULL
└─ 通知卖家拍卖结束但无人出价
```

## 实现机制

### 方式1：定时任务（Cron）- 推荐

定时任务会定期检查并自动关闭到期的拍卖。

#### 配置步骤

**快速配置（推荐）：**
```bash
cd /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14
chmod +x setup_auto_close_cron.sh
./setup_auto_close_cron.sh
```

设置脚本会自动：
- ✅ 检查必要文件
- ✅ 创建日志目录
- ✅ 生成 crontab 配置
- ✅ 添加定时任务
- ✅ 运行测试

**手动配置：**
```bash
# 编辑 crontab
crontab -e

# 添加以下内容
# 每5分钟检查并关闭到期拍卖
*/5 * * * * /usr/bin/php /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14/cron_close_auctions.php >> /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14/logs/cron_close_auctions.log 2>&1

# 每小时处理超时的卖家决策
0 * * * * /usr/bin/php /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14/cron_expire_decisions.php >> /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14/logs/cron_expire_decisions.log 2>&1
```

#### 验证定时任务

```bash
# 查看已配置的定时任务
crontab -l

# 手动运行测试
php cron_close_auctions.php

# 查看日志
tail -f logs/cron_close_auctions.log
```

### 方式2：页面访问时自动检查

当用户访问 `listing.php` 时，会自动检查该拍卖是否到期并执行关闭。

**代码位置：** `listing.php` 第60-90行

```php
// 自动关闭已过期但状态还是 active 的拍卖
if ($status === 'active' && $now >= $end_time) {
    require_once 'auction_functions.php';
    try {
        $pdo->beginTransaction();
        closeAuction($pdo, $auction);
        $pdo->commit();
        // 重新获取更新后的状态
    } catch (Exception $e) {
        $pdo->rollBack();
    }
}
```

**优点：**
- 无需配置服务器定时任务
- 即时响应

**缺点：**
- 需要有人访问页面才会触发
- 不适合无人访问的拍卖

### 方式3：手动同步

使用Web界面手动执行同步。

**访问地址：**
```
http://localhost/auction_0112_v14/sync_auction_outcomes.php
```

**用途：**
- 首次部署时同步历史数据
- 修复数据不一致问题
- 定时任务失败时的备用方案

## 核心文件

### 1. `cron_close_auctions.php` - 定时任务脚本

**功能：**
- 查找所有到期的活跃拍卖
- 调用 `closeAuction()` 函数处理
- 记录详细日志
- 验证同步结果

**执行逻辑：**
```
开始 → 查询过期拍卖 → 遍历每个拍卖 → 调用closeAuction() 
     → 更新状态 → 创建Outcome → 发送通知 → 验证结果 → 记录日志 → 结束
```

**日志位置：** `logs/cron_close_auctions.log`

### 2. `auction_functions.php` - 核心处理函数

**`closeAuction($pdo, $auctionRow)` 函数：**

```php
function closeAuction($pdo, $auctionRow) {
    // 1. 更新 Auction.status = 'ended'
    // 2. 获取最高出价
    // 3. 判断是否达到保留价
    // 4. 创建 AuctionOutcome 记录
    //    - reserve_met: 是否达标
    //    - seller_accepted: 自动或等待决策
    //    - acceptance_deadline: 决策截止时间
    // 5. 发送通知
    // 6. 返回成功
}
```

### 3. `cron_expire_decisions.php` - 超时决策处理

**功能：**
- 处理超过24小时未决策的拍卖
- 自动拒绝超时的出价
- 确保状态保持 `ended`

### 4. `monitor_auto_close.php` - 实时监控面板

**功能：**
- 显示待关闭的拍卖数量
- 显示活跃拍卖数量
- 显示待决策和超时决策数量
- 实时查看日志（最后20行）
- 最近24小时关闭的拍卖列表
- 系统健康检查
- 自动30秒刷新

**访问地址：**
```
http://localhost/auction_0112_v14/monitor_auto_close.php
```

### 5. `setup_auto_close_cron.sh` - 自动化设置脚本

**功能：**
- 检查PHP环境
- 验证必要文件
- 创建日志目录
- 生成crontab配置
- 自动添加定时任务
- 运行测试

## 工作流程图

```
┌─────────────────────────────────────────────────────────────┐
│                      拍卖创建                                │
│                    status = 'active'                         │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ↓
              拍卖进行中（等待出价）
                         │
                         ↓
                  end_time <= NOW()
                         │
         ┌───────────────┴───────────────┐
         │                               │
         ↓                               ↓
    定时任务触发              用户访问listing.php触发
  (cron_close_auctions)           (页面自动检查)
         │                               │
         └───────────────┬───────────────┘
                         ↓
                  closeAuction()
                         │
         ┌───────────────┼───────────────┐
         ↓               ↓               ↓
   更新status='ended'  获取最高出价  判断是否达标
         │               │               │
         └───────────────┴───────────────┘
                         ↓
               创建 AuctionOutcome
                         │
         ┌───────────────┼───────────────┐
         ↓               ↓               ↓
     出价≥保留价      出价<保留价        无出价
         │               │               │
    reserve_met=T    reserve_met=F    winner_id=NULL
    seller_accepted=T seller_accepted=F    │
         │               │               │
         │           24小时决策期          │
         │               │               │
         └───────────────┴───────────────┘
                         ↓
                   发送通知
                         ↓
                    完成同步
```

## 监控和管理

### Web控制面板

**主控制面板：**
```
http://localhost/auction_0112_v14/auction_sync_dashboard.php
```

功能：
- 检查和诊断
- 状态同步
- 卖家决策管理
- 访问监控面板
- 查看文档

**实时监控面板：**
```
http://localhost/auction_0112_v14/monitor_auto_close.php
```

功能：
- 实时数据统计
- 最近关闭的拍卖
- 日志查看器
- 系统健康检查
- 自动刷新（30秒）

### 命令行监控

```bash
# 查看定时任务配置
crontab -l

# 实时查看关闭日志
tail -f logs/cron_close_auctions.log

# 实时查看决策日志
tail -f logs/cron_expire_decisions.log

# 手动执行一次
php cron_close_auctions.php

# 查看最近的日志条目
tail -20 logs/cron_close_auctions.log
```

### 日志格式

```
[2025-12-02 14:30:01] Cron: Starting automatic auction closure
[2025-12-02 14:30:01] Cron: Found 2 auction(s) to close
[2025-12-02 14:30:01] Cron: ✓ Closed auction #2 (book) - 等待卖家决策
[2025-12-02 14:30:01] Cron: ✓ Closed auction #3 (bike) - 已达保留价-自动完成
[2025-12-02 14:30:01] Cron: Transaction committed successfully
```

## 故障排查

### 问题1：定时任务不执行

**检查步骤：**
1. 确认crontab已配置：`crontab -l`
2. 检查PHP路径：`which php`
3. 手动运行测试：`php cron_close_auctions.php`
4. 查看系统日志：`tail -f /var/log/syslog` (Linux)

**常见原因：**
- PHP路径不正确
- 文件权限问题
- 数据库连接失败

### 问题2：拍卖未自动关闭

**检查步骤：**
1. 访问监控面板查看待关闭数量
2. 手动运行：`php cron_close_auctions.php`
3. 查看日志中的错误信息
4. 检查数据库连接

**解决方案：**
```bash
# 手动同步
php cron_close_auctions.php

# 或使用Web界面
http://localhost/auction_0112_v14/sync_auction_outcomes.php
```

### 问题3：日志文件不存在

**解决方案：**
```bash
# 创建日志目录
mkdir -p logs
chmod 777 logs

# 创建日志文件
touch logs/cron_close_auctions.log
touch logs/cron_expire_decisions.log
chmod 666 logs/*.log
```

### 问题4：页面自动关闭不工作

**检查 listing.php：**
- 确认第60-90行的自动关闭代码存在
- 检查 `auction_functions.php` 是否被正确引入
- 查看PHP错误日志

## 性能优化

### 1. 定时任务频率

**推荐配置：**
- 关闭拍卖：每5分钟 (`*/5 * * * *`)
- 处理超时：每小时 (`0 * * * *`)

**调整建议：**
- 拍卖量少：可以降到每15分钟
- 拍卖量大：可以提升到每分钟
- 根据实际需求调整

### 2. 数据库索引

确保以下字段有索引：
```sql
-- Auction 表
CREATE INDEX idx_status_endtime ON Auction(status, end_time);

-- AuctionOutcome 表
CREATE INDEX idx_reserve_deadline ON AuctionOutcome(reserve_met, acceptance_deadline, seller_notified);
```

### 3. 批量处理

`cron_close_auctions.php` 使用事务批量处理所有到期拍卖，确保原子性和性能。

## 安全考虑

### 1. 文件权限

```bash
# 脚本文件
chmod 755 cron_close_auctions.php
chmod 755 setup_auto_close_cron.sh

# 日志目录
chmod 777 logs/
chmod 666 logs/*.log
```

### 2. 日志轮转

防止日志文件过大：
```bash
# 创建 logrotate 配置
sudo nano /etc/logrotate.d/auction_system

# 添加内容：
/path/to/logs/*.log {
    weekly
    rotate 4
    compress
    missingok
    notifempty
}
```

## 测试验证

### 1. 功能测试

```bash
# 1. 创建一个即将到期的测试拍卖
# 2. 手动运行定时任务
php cron_close_auctions.php

# 3. 验证结果
php test_auction_sync.php

# 4. 查看日志
tail logs/cron_close_auctions.log
```

### 2. 监控测试

访问监控面板，确认：
- ✓ 待关闭拍卖数量正确
- ✓ 日志正常显示
- ✓ 最近关闭的拍卖列表正确
- ✓ 系统健康检查通过

## 总结

### ✅ 已实现功能

1. **自动拍卖关闭**
   - 定时任务每5分钟自动检查
   - 页面访问时即时检查
   - 手动同步备用方案

2. **完整状态同步**
   - 自动更新 `status = 'ended'`
   - 自动创建 `AuctionOutcome`
   - 根据出价自动设置初始状态

3. **监控和管理**
   - 实时监控面板
   - 日志查看
   - 系统健康检查
   - Web控制面板

4. **自动化部署**
   - 一键设置脚本
   - 自动配置crontab
   - 测试和验证

### 📊 系统优势

- ✅ 全自动：无需人工干预
- ✅ 多重保障：定时任务 + 页面触发 + 手动同步
- ✅ 实时监控：Web界面实时查看状态
- ✅ 易于部署：一键设置脚本
- ✅ 完整日志：详细记录每次操作
- ✅ 故障恢复：异常时自动回滚

### 🚀 快速开始

1. 运行设置脚本：
   ```bash
   cd /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14
   chmod +x setup_auto_close_cron.sh
   ./setup_auto_close_cron.sh
   ```

2. 访问监控面板：
   ```
   http://localhost/auction_0112_v14/monitor_auto_close.php
   ```

3. 验证系统正常运行！

现在您的拍卖系统已经具备完整的自动化能力，拍卖到达结束时间后会自动同步更新状态并同步到AuctionOutcome！
