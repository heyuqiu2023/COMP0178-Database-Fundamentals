<?php
require_once 'db_connection.php';
require_once 'notify.php';

echo "=== Checking Auction Status ===\n\n";

// Find all ended auctions
$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.end_time, 
                      (SELECT COUNT(*) FROM AuctionOutcome ao WHERE ao.auction_id = a.auction_id) as has_outcome
                      FROM Auction a 
                      WHERE a.end_time < NOW() 
                      ORDER BY a.auction_id DESC 
                      LIMIT 10");
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Found " . count($auctions) . " auctions that have ended:\n\n";

foreach ($auctions as $auction) {
    echo "Auction #{$auction['auction_id']}: {$auction['title']}\n";
    echo "  Status: {$auction['status']}\n";
    echo "  End Time: {$auction['end_time']}\n";
    echo "  Has Outcome: " . ($auction['has_outcome'] ? 'Yes' : 'No') . "\n";
    
    // If auction is ended but has no outcome, create it now
    if ($auction['status'] === 'ended' && $auction['has_outcome'] == 0) {
        echo "  >>> Creating missing AuctionOutcome...\n";
        
        try {
            $pdo->beginTransaction();
            
            // Reload full auction data
            $full_stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
            $full_stmt->execute([$auction['auction_id']]);
            $full_auction = $full_stmt->fetch(PDO::FETCH_ASSOC);
            
            // Call closeAuction to create outcome
            require_once __DIR__ . '/place_bid.php';
            closeAuction($pdo, $full_auction);
            
            $pdo->commit();
            echo "  >>> Successfully created AuctionOutcome!\n";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "  >>> ERROR: " . $e->getMessage() . "\n";
        }
    }
    
    echo "\n";
}

echo "\n=== Checking AuctionOutcome Table ===\n\n";
$outcome_stmt = $pdo->query("SELECT * FROM AuctionOutcome ORDER BY outcome_id DESC LIMIT 10");
$outcomes = $outcome_stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Found " . count($outcomes) . " outcomes in database:\n\n";
foreach ($outcomes as $outcome) {
    echo "Outcome #{$outcome['outcome_id']} for Auction #{$outcome['auction_id']}\n";
    echo "  Winner ID: " . ($outcome['winner_id'] ?? 'NULL') . "\n";
    echo "  Final Price: " . ($outcome['final_price'] ?? 'NULL') . "\n";
    echo "  Reserve Met: " . ($outcome['reserve_met'] ? 'Yes' : 'No') . "\n";
    echo "  Seller Accepted: " . ($outcome['seller_accepted'] ? 'Yes' : 'No') . "\n";
    echo "\n";
}

echo "=== Done ===\n";
?>
