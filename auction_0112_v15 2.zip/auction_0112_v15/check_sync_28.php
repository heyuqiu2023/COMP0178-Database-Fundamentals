<?php
require_once 'db_connection.php';

echo "<h2>Checking Auction #28 Current Status</h2>";

$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.end_time, a.reserve_price,
                     ao.outcome_id, ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted,
                     u.username as winner_name
                     FROM Auction a 
                     LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                     LEFT JOIN User u ON ao.winner_id = u.user_id
                     WHERE a.auction_id = 28");

$data = $stmt->fetch(PDO::FETCH_ASSOC);

if ($data) {
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>Field</th><th>Value</th></tr>";
    echo "<tr><td>Auction ID</td><td>{$data['auction_id']}</td></tr>";
    echo "<tr><td>Title</td><td>" . htmlspecialchars($data['title']) . "</td></tr>";
    echo "<tr><td>Status</td><td><strong>{$data['status']}</strong></td></tr>";
    echo "<tr><td>End Time</td><td>{$data['end_time']}</td></tr>";
    echo "<tr><td>Reserve Price</td><td>£" . number_format($data['reserve_price'], 2) . "</td></tr>";
    echo "<tr><td colspan='2' style='background:#f0f0f0;'><strong>AuctionOutcome</strong></td></tr>";
    echo "<tr><td>Outcome ID</td><td>" . ($data['outcome_id'] ?? '<span style="color:red;">NULL - NOT SYNCED!</span>') . "</td></tr>";
    echo "<tr><td>Winner</td><td>" . ($data['winner_name'] ?? 'N/A') . " (ID: " . ($data['winner_id'] ?? 'N/A') . ")</td></tr>";
    echo "<tr><td>Final Price</td><td>£" . number_format($data['final_price'] ?? 0, 2) . "</td></tr>";
    echo "<tr><td>Reserve Met</td><td>" . ($data['reserve_met'] ? 'Yes' : 'No') . "</td></tr>";
    echo "<tr><td>Seller Accepted</td><td>" . ($data['seller_accepted'] ? 'Yes' : 'No') . "</td></tr>";
    echo "</table>";
    
    if (!$data['outcome_id']) {
        echo "<div style='background:#fff3cd; padding:15px; margin-top:20px; border:1px solid #ffc107;'>";
        echo "<h3 style='color:#856404;'>⚠️ Sync Issue Detected!</h3>";
        echo "<p>This auction is marked as 'ended' but has no AuctionOutcome record.</p>";
        echo "<p><a href='fix_missing_outcomes.php' style='padding:10px 20px; background:#ffc107; color:#000; text-decoration:none; border-radius:5px;'>Run Fix Tool</a></p>";
        echo "</div>";
    } else {
        echo "<div style='background:#d4edda; padding:15px; margin-top:20px; border:1px solid #28a745;'>";
        echo "<h3 style='color:#155724;'>✓ Sync Status: OK</h3>";
        echo "<p>Auction outcome is properly recorded.</p>";
        echo "</div>";
    }
} else {
    echo "<p style='color:red;'>Auction #28 not found!</p>";
}

echo "<hr>";
echo "<p><a href='check_db_consistency.php'>Check All Auctions</a></p>";
echo "<p><a href='listing.php?auction_id=28'>View Auction #28</a></p>";
?>
