<!DOCTYPE html>
<html>
<head>
    <title>拍卖状态同步 - 快速操作</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { padding: 30px; background: #f5f5f5; }
        .card { margin-bottom: 20px; }
        .action-btn { 
            width: 100%; 
            margin: 10px 0; 
            padding: 15px;
            font-size: 16px;
        }
        .scenario { 
            background: #e3f2fd; 
            padding: 15px; 
            border-left: 4px solid #2196F3;
            margin: 20px 0;
        }
        .feature-list { 
            list-style: none; 
            padding-left: 0; 
        }
        .feature-list li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .feature-list li:before {
            content: "✓ ";
            color: green;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">
            <i class="fas fa-sync-alt"></i> 拍卖状态同步系统
        </h1>
        
        <div class="scenario">
            <h4><i class="fas fa-info-circle"></i> 系统功能</h4>
            <ul class="feature-list">
                <li>自动将已结束的拍卖状态从 <code>active</code> 更新为 <code>ended</code></li>
                <li>为所有结束的拍卖创建 <code>AuctionOutcome</code> 记录</li>
                <li>最高出价 ≥ 保留价：自动完成交易</li>
                <li>最高出价 < 保留价：给予卖家24小时决策时间</li>
                <li>卖家接受/拒绝后，状态保持 <code>ended</code></li>
                <li>超时未决策自动拒绝并保持状态 <code>ended</code></li>
            </ul>
        </div>
        
        <div class="row">
            <!-- 检查和诊断 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5><i class="fas fa-search"></i> 检查和诊断</h5>
                    </div>
                    <div class="card-body">
                        <p>查看系统当前状态和需要处理的问题</p>
                        
                        <a href="check_auction_status_sync.php" class="btn btn-info action-btn">
                            <i class="fas fa-clipboard-list"></i> 查看状态详情
                        </a>
                        
                        <a href="test_auction_sync.php" class="btn btn-primary action-btn">
                            <i class="fas fa-vial"></i> 运行完整测试
                        </a>
                        
                        <hr>
                        <small class="text-muted">
                            <strong>功能：</strong>
                            <ul>
                                <li>显示需要同步的拍卖</li>
                                <li>显示等待决策的拍卖</li>
                                <li>显示超时的决策</li>
                                <li>验证数据一致性</li>
                            </ul>
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- 同步和修复 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5><i class="fas fa-sync"></i> 同步和修复</h5>
                    </div>
                    <div class="card-body">
                        <p>执行状态同步和数据修复操作</p>
                        
                        <a href="sync_auction_outcomes.php" class="btn btn-success action-btn">
                            <i class="fas fa-sync-alt"></i> 同步拍卖状态
                        </a>
                        
                        <a href="close_expired_auctions.php" class="btn btn-warning action-btn">
                            <i class="fas fa-lock"></i> 关闭过期拍卖
                        </a>
                        
                        <hr>
                        <small class="text-muted">
                            <strong>功能：</strong>
                            <ul>
                                <li>更新状态为 <code>ended</code></li>
                                <li>创建 <code>AuctionOutcome</code> 记录</li>
                                <li>发送相关通知</li>
                                <li>验证同步结果</li>
                            </ul>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- 卖家决策 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5><i class="fas fa-gavel"></i> 卖家决策管理</h5>
                    </div>
                    <div class="card-body">
                        <p>查看和处理需要卖家决策的拍卖</p>
                        
                        <a href="seller_decision_dashboard.php" class="btn btn-warning action-btn">
                            <i class="fas fa-clipboard-check"></i> 卖家决策面板
                        </a>
                        
                        <a href="cron_expire_decisions.php" class="btn btn-danger action-btn">
                            <i class="fas fa-clock"></i> 处理超时决策
                        </a>
                        
                        <hr>
                        <small class="text-muted">
                            <strong>功能：</strong>
                            <ul>
                                <li>显示待决策的拍卖</li>
                                <li>提供接受/拒绝操作</li>
                                <li>自动处理超时决策</li>
                                <li>发送通知</li>
                            </ul>
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- 自动化监控 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header" style="background: #6f42c1; color: white;">
                        <h5><i class="fas fa-robot"></i> 自动化监控</h5>
                    </div>
                    <div class="card-body">
                        <p>实时监控自动拍卖关闭系统</p>
                        
                        <a href="monitor_auto_close.php" class="btn btn-info action-btn">
                            <i class="fas fa-chart-line"></i> 实时监控面板
                        </a>
                        
                        <a href="cron_close_auctions.php" class="btn btn-success action-btn">
                            <i class="fas fa-play"></i> 手动执行关闭
                        </a>
                        
                        <hr>
                        <small class="text-muted">
                            <strong>功能：</strong>
                            <ul>
                                <li>查看待关闭的拍卖数量</li>
                                <li>实时日志查看</li>
                                <li>系统状态检查</li>
                                <li>手动触发执行</li>
                            </ul>
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- 常规管理 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5><i class="fas fa-tools"></i> 常规管理</h5>
                    </div>
                    <div class="card-body">
                        <p>访问常规拍卖管理页面</p>
                        
                        <a href="mylistings.php" class="btn btn-secondary action-btn">
                            <i class="fas fa-list"></i> 我的拍卖
                        </a>
                        
                        <a href="mybids.php" class="btn btn-secondary action-btn">
                            <i class="fas fa-hand-holding-usd"></i> 我的出价
                        </a>
                        
                        <a href="index.php" class="btn btn-dark action-btn">
                            <i class="fas fa-home"></i> 返回首页
                        </a>
                        
                        <hr>
                        <small class="text-muted">
                            <strong>常规功能入口</strong>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 使用流程 -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5><i class="fas fa-book"></i> 使用流程</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <h6><i class="fas fa-step-forward"></i> 步骤 1: 检查</h6>
                        <p>运行"运行完整测试"查看系统状态，识别需要处理的问题。</p>
                    </div>
                    <div class="col-md-3">
                        <h6><i class="fas fa-step-forward"></i> 步骤 2: 同步</h6>
                        <p>如果发现状态不一致，运行"同步拍卖状态"修复问题。</p>
                    </div>
                    <div class="col-md-3">
                        <h6><i class="fas fa-step-forward"></i> 步骤 3: 自动化</h6>
                        <p>设置定时任务实现自动关闭拍卖。</p>
                    </div>
                    <div class="col-md-3">
                        <h6><i class="fas fa-step-forward"></i> 步骤 4: 监控</h6>
                        <p>使用实时监控面板查看系统运行状态。</p>
                    </div>
                </div>
                
                <hr>
                
                <h6><i class="fas fa-cog"></i> 自动化设置（推荐）</h6>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>方式1: 使用设置脚本（推荐）</strong></p>
                        <pre class="bg-light p-3"><code>cd /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14
chmod +x setup_auto_close_cron.sh
./setup_auto_close_cron.sh</code></pre>
                        <p class="small text-muted">脚本会自动配置定时任务并创建必要的日志目录。</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>方式2: 手动配置 Crontab</strong></p>
                        <pre class="bg-light p-3"><code># 每5分钟关闭过期拍卖
*/5 * * * * /usr/bin/php /path/to/cron_close_auctions.php

# 每小时处理超时决策
0 * * * * /usr/bin/php /path/to/cron_expire_decisions.php</code></pre>
                        <p class="small text-muted">运行 <code>crontab -e</code> 添加以上内容。</p>
                    </div>
                </div>
                
                <hr>
                
                <h6><i class="fas fa-eye"></i> 监控命令</h6>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>查看日志</strong></p>
                        <pre class="bg-light p-3"><code>tail -f logs/cron_close_auctions.log
tail -f logs/cron_expire_decisions.log</code></pre>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Web监控</strong></p>
                        <p><a href="monitor_auto_close.php" class="btn btn-info btn-sm">
                            <i class="fas fa-chart-line"></i> 打开实时监控面板
                        </a></p>
                        <p class="small text-muted">自动刷新，显示待关闭拍卖数量、最近日志等。</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 文档链接 -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5><i class="fas fa-file-alt"></i> 相关文档</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <a href="AUCTION_STATUS_SYNC_GUIDE.md" class="btn btn-outline-primary btn-block" target="_blank">
                            <i class="fas fa-book-open"></i> 完整实现文档
                        </a>
                    </div>
                    <div class="col-md-6">
                        <a href="SELLER_DECISION_GUIDE.md" class="btn btn-outline-primary btn-block" target="_blank">
                            <i class="fas fa-user-tie"></i> 卖家决策指南
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4 text-muted">
            <p><small>拍卖状态同步系统 v1.0 | 2025-12-02</small></p>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
