<?php
/**
 * 拍卖关闭函数
 * 这个文件只包含 closeAuction() 函数，不包含任何 HTML
 * 可以安全地被其他脚本引用而不触发输出
 */

require_once 'db_connection.php';
require_once 'notify.php';

/**
 * 关闭拍卖：更新状态、创建 AuctionOutcome、发送通知
 * 
 * @param PDO $pdo 数据库连接
 * @param array $auctionRow 拍卖数据（从 Auction 表查询的结果）
 * @throws Exception 如果操作失败
 * @return bool 成功返回 true
 */
function closeAuction($pdo, $auctionRow) {
    $auction_id    = (int)$auctionRow['auction_id'];
    $reserve_price = isset($auctionRow['reserve_price']) ? (float)$auctionRow['reserve_price'] : null;
    $seller_id     = (int)$auctionRow['seller_id'];

    // 验证拍卖是否已经关闭
    $check_stmt = $pdo->prepare("SELECT status FROM Auction WHERE auction_id = ?");
    $check_stmt->execute([$auction_id]);
    $current_status = $check_stmt->fetchColumn();
    
    if ($current_status === 'ended') {
        // 拍卖已关闭，检查是否有 outcome
        $outcome_check = $pdo->prepare("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = ?");
        $outcome_check->execute([$auction_id]);
        if ($outcome_check->fetchColumn() > 0) {
            // 已经有 outcome，无需重复处理
            return true;
        }
        // 状态是 ended 但缺少 outcome，继续创建
    }

    // 找中标者（最高出价）
    $stmt = $pdo->prepare("SELECT bid_id, bidder_id, bid_amount 
                           FROM Bid 
                           WHERE auction_id = ? AND is_active = TRUE
                           ORDER BY bid_amount DESC, bid_time ASC 
                           LIMIT 1");
    $stmt->execute([$auction_id]);
    $winning = $stmt->fetch(PDO::FETCH_ASSOC);

    $winner_id   = $winning ? (int)$winning['bidder_id'] : null;
    $final_price = $winning ? (float)$winning['bid_amount'] : null;
    
    // Determine if reserve price is met
    $reserve_met = false;
    if ($winning && $reserve_price !== null && $reserve_price > 0) {
        $reserve_met = ($final_price >= $reserve_price);
    } elseif ($winning && ($reserve_price === null || $reserve_price == 0)) {
        // No reserve price set, any bid meets the requirement
        $reserve_met = true;
    }

    // 更新 Auction 状态为 ended
    $update_stmt = $pdo->prepare("UPDATE Auction SET status = 'ended' WHERE auction_id = ?");
    $update_stmt->execute([$auction_id]);
    
    if ($update_stmt->rowCount() === 0 && $current_status !== 'ended') {
        throw new Exception("Failed to update auction status to 'ended' for auction #$auction_id");
    }

    // 写入 AuctionOutcome (24 hours deadline for seller decision)
    $accept_deadline = (new DateTime('now'))->modify('+24 hours')->format('Y-m-d H:i:s');
    
    // If reserve_met = FALSE, seller needs to manually accept (seller_accepted = FALSE initially)
    // If reserve_met = TRUE, auction is automatically successful (seller_accepted = TRUE)
    $seller_accepted = $reserve_met ? 1 : 0;
    $reserve_met_int = $reserve_met ? 1 : 0;
    
    $outcome_stmt = $pdo->prepare(
        "INSERT INTO AuctionOutcome 
         (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at, seller_notified, winner_notified)
         VALUES (?, ?, ?, ?, ?, ?, NOW(), 0, 0)
         ON DUPLICATE KEY UPDATE 
           winner_id = VALUES(winner_id), 
           final_price = VALUES(final_price), 
           reserve_met = VALUES(reserve_met), 
           seller_accepted = VALUES(seller_accepted),
           acceptance_deadline = VALUES(acceptance_deadline),
           concluded_at = VALUES(concluded_at)"
    );
    $outcome_stmt->execute([$auction_id, $winner_id, $final_price, $reserve_met_int, $seller_accepted, $accept_deadline]);
    
    // 验证 AuctionOutcome 是否成功创建
    $verify_stmt = $pdo->prepare("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = ?");
    $verify_stmt->execute([$auction_id]);
    if ($verify_stmt->fetchColumn() === 0) {
        throw new Exception("Failed to create AuctionOutcome record for auction #$auction_id");
    }

    // === Send notifications based on auction outcome ===
    // 1. Always notify seller that auction ended
    queue_notification($seller_id, $auction_id, $winning ? (int)$winning['bid_id'] : null, 'auction_ended');

    // 2. If there's a winner, notify them
    if ($winner_id) {
        queue_notification($winner_id, $auction_id, (int)$winning['bid_id'], 'auction_ended');
    }

    // 3. If reserve price is NOT met, notify seller they need to accept/reject the bid
    if ($winning && !$reserve_met) {
        queue_notification($seller_id, $auction_id, (int)$winning['bid_id'], 'reserve_not_met');
    }

    // 4. If reserve price IS met, notify winner of confirmed win
    if ($winning && $reserve_met) {
        queue_notification($winner_id, $auction_id, (int)$winning['bid_id'], 'winner_confirmed');
    }
    
    // Log successful closure
    error_log("[closeAuction] Successfully closed auction #$auction_id - Winner: " . 
              ($winner_id ? $winner_id : 'none') . 
              ", Final Price: " . ($final_price ? "£$final_price" : 'none') . 
              ", Reserve Met: " . ($reserve_met ? 'yes' : 'no'));
    
    return true;
}
?>
