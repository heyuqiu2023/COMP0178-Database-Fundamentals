# 协同过滤推荐系统实现文档

## 功能概述

基于协同过滤（Collaborative Filtering）的拍卖推荐系统，为买家推荐他们可能感兴趣的拍卖商品。

**核心理念**："喜欢相似商品的用户，可能也会喜欢彼此出价过的其他商品"

## 算法逻辑

### 协同过滤流程

1. **找到相似用户**
   - 定义：与当前用户出价过相同拍卖的其他买家
   - 相似度：共同出价的拍卖数量越多，相似度越高

2. **发现候选拍卖**
   - 查找相似用户正在出价的活跃拍卖
   - 排除当前用户已经出价的拍卖

3. **计算推荐分数**
   - 分数 = 有多少个相似用户对该拍卖出价
   - 分数越高，推荐优先级越高

4. **排序和限制**
   - 按推荐分数降序排列
   - 相同分数时，按结束时间升序（即将结束的优先）
   - 限制显示前 12 个推荐

### SQL 查询说明

```sql
-- 主查询结构
SELECT 
  a.auction_id,
  a.title,
  ... 其他字段 ...,
  COUNT(DISTINCT similar_bids.bidder_id) AS similarity_score  -- 推荐分数
FROM Auction a

-- 连接相似用户的出价
INNER JOIN Bid similar_bids ON similar_bids.auction_id = a.auction_id

-- 子查询：找到相似用户
INNER JOIN (
  SELECT DISTINCT b1.bidder_id AS similar_user_id
  FROM Bid b1
  WHERE b1.auction_id IN (
    -- 当前用户出价过的拍卖
    SELECT DISTINCT b2.auction_id
    FROM Bid b2
    WHERE b2.bidder_id = ?
  )
  AND b1.bidder_id != ?  -- 排除自己
  GROUP BY b1.bidder_id
  HAVING COUNT(DISTINCT b1.auction_id) >= 1
) similar_users ON similar_bids.bidder_id = similar_users.similar_user_id

WHERE 
  a.status = 'active'  -- 只推荐活跃拍卖
  AND a.end_time > NOW()  -- 未结束
  AND a.auction_id NOT IN (
    -- 排除已出价的拍卖
    SELECT DISTINCT b3.auction_id
    FROM Bid b3
    WHERE b3.bidder_id = ?
  )

ORDER BY similarity_score DESC, a.end_time ASC
LIMIT 12
```

## 降级策略

如果协同过滤没有返回结果（用户是新用户或没有相似用户），系统会：

1. **显示提示信息**
   - "No personalized recommendations yet."
   - "Place some bids to receive recommendations..."

2. **展示热门拍卖**
   - 按出价数量降序排列
   - 显示当前最受欢迎的活跃拍卖
   - 同样排除用户已出价的拍卖

## 使用示例

### 场景 1：有推荐结果

**用户 ZYJ 的情况：**
- 出价历史：拍卖 #28, #26, #21
- 相似用户：zhang（共同出价 3 个拍卖）
- 推荐结果：拍卖 #7, #19, #22, #24（zhang 出价但 ZYJ 未出价）

### 场景 2：无推荐结果

**用户 zhang 的情况：**
- 出价历史：拍卖 #28, #7, #26, #24, #21, #22, #20, #19
- 相似用户：ZYJ（共同出价 3 个拍卖）
- 推荐结果：无（因为 ZYJ 出价的所有拍卖 zhang 都已出价）
- 降级：显示热门拍卖

### 场景 3：新用户

**没有出价历史的用户：**
- 出价历史：无
- 相似用户：无
- 推荐结果：无
- 降级：显示热门拍卖

## 推荐质量指标

### 相似度计算
- **高相似度**：共同出价 5+ 个拍卖
- **中相似度**：共同出价 2-4 个拍卖
- **低相似度**：共同出价 1 个拍卖

### 推荐分数解读
- **分数 5+**：多个相似用户都感兴趣，强推荐
- **分数 2-4**：部分相似用户感兴趣，中等推荐
- **分数 1**：单个相似用户感兴趣，弱推荐

## 算法优势

1. **个性化**：基于用户实际行为，而非简单的类别匹配
2. **动态性**：随用户行为实时更新
3. **发现性**：帮助用户发现可能感兴趣但不知道的商品
4. **社交证明**：相似用户的选择提供了可信的推荐依据

## 改进空间

未来可以考虑的优化方向：

1. **加权相似度**
   - 考虑出价金额
   - 考虑出价频率
   - 考虑出价时间新近度

2. **类别偏好**
   - 分析用户的类别偏好
   - 结合类别相似度

3. **混合推荐**
   - 协同过滤 + 内容过滤
   - 多种算法的加权组合

4. **实时更新**
   - 缓存推荐结果
   - 定期刷新

## 测试验证

运行测试脚本：
```bash
/Applications/XAMPP/xamppfiles/bin/php test_recommendations.php
```

测试脚本会显示：
- 每个买家的出价历史
- 找到的相似用户
- 生成的推荐结果
- 无推荐时的原因分析

## 使用说明

### 访问推荐页面
```
http://localhost/auction_0112_v12/recommendations.php
```

### 权限要求
- 必须登录
- 账户类型必须是 Buyer
- Seller 无法访问推荐页面

### 显示内容
- 推荐的拍卖卡片（包含图片、标题、价格、出价数、剩余时间）
- 如果没有个性化推荐，显示热门拍卖
- 使用用户时区显示结束时间

## 实现状态

✅ **已完成功能：**
- 协同过滤算法核心逻辑
- 相似用户识别
- 推荐分数计算
- 热门拍卖降级策略
- 图片和时区支持
- 测试脚本

✅ **系统集成：**
- 集成到 header 导航菜单
- 使用 utilities.php 的 print_listing_card 函数
- 支持响应式布局

---

**实现日期：** 2025-12-01  
**状态：** ✅ 生产就绪
