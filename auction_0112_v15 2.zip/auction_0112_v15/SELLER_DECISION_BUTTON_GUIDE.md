# 卖家决策按钮显示问题 - 诊断和修复指南

## 问题描述

拍卖已结束，但卖家在网页上看不到"接受报价"或"拒绝报价"的按钮。

## 核心原因

**不需要添加"waiting"状态！** 系统已经有完整的决策机制，问题在于：

1. **拍卖状态未同步**：`Auction.status`仍然是`active`而不是`ended`
2. **缺少结果记录**：没有创建`AuctionOutcome`记录

## 决策按钮显示的6个必要条件

要在`listing.php`显示卖家决策按钮，必须**同时满足**以下所有条件：

```
1. ✓ Auction.status = 'ended'
2. ✓ AuctionOutcome 记录存在
3. ✓ AuctionOutcome.winner_id IS NOT NULL (有中标者)
4. ✓ AuctionOutcome.reserve_met = FALSE (未达保留价)
5. ✓ AuctionOutcome.seller_accepted = FALSE (卖家尚未接受)
6. ✓ NOW() < acceptance_deadline (决策截止时间未到)
```

满足这6个条件后，卖家访问`listing.php?auction_id=X`就会看到：
- **绿色"Accept Bid"按钮** - 接受低于保留价的出价
- **红色"Reject Bid"按钮** - 拒绝出价

## 诊断步骤

### 步骤1：诊断具体拍卖

访问以下URL检查您的拍卖（例如拍卖ID为2）：
```
http://localhost/auction_0112_v14/diagnose_seller_decision_buttons.php?auction_id=2
```

这会显示：
- 拍卖的当前状态
- AuctionOutcome是否存在
- 6个条件是否都满足
- 具体哪里有问题
- 修复建议

### 步骤2：运行同步修复

如果诊断发现问题，访问：
```
http://localhost/auction_0112_v14/sync_auction_outcomes.php
```

这会自动：
1. 将所有已过期的拍卖状态更新为`ended`
2. 为缺少的拍卖创建`AuctionOutcome`记录
3. 根据最高出价与保留价的关系设置初始状态

### 步骤3：验证修复

再次访问诊断页面，确认所有条件都满足：
```
http://localhost/auction_0112_v14/diagnose_seller_decision_buttons.php?auction_id=2
```

### 步骤4：测试决策按钮

以**卖家身份**登录，访问拍卖详情页：
```
http://localhost/auction_0112_v14/listing.php?auction_id=2
```

您应该能看到决策按钮（如果满足所有条件）。

## 系统工作流程

### 场景A：最高出价 ≥ 保留价
```
拍卖结束 
  ↓
自动更新: status='ended'
  ↓
创建 AuctionOutcome:
  - reserve_met = TRUE
  - seller_accepted = TRUE (自动接受)
  ↓
✓ 交易自动完成
  ↓
listing.php 显示: "Auction Successful! The reserve price was met."
  ↓
不显示决策按钮（已自动完成，无需决策）
```

### 场景B：最高出价 < 保留价
```
拍卖结束 
  ↓
自动更新: status='ended'
  ↓
创建 AuctionOutcome:
  - reserve_met = FALSE
  - seller_accepted = FALSE (等待决策)
  - acceptance_deadline = 结束时间 + 24小时
  ↓
⏳ 等待卖家决策
  ↓
listing.php 显示: "Pending Seller Decision"
  ↓
✓ 显示决策按钮（Accept / Reject）
  ↓
卖家点击接受或拒绝
  ↓
更新 AuctionOutcome
status 保持 'ended'
```

## 快速修复命令

### 方式1：使用Web界面（推荐）

访问控制面板：
```
http://localhost/auction_0112_v14/auction_sync_dashboard.php
```

点击"运行完整测试"查看问题，然后点击"同步拍卖状态"修复。

### 方式2：直接SQL修复

如果自动同步失败，可以手动执行SQL：

```sql
-- 检查拍卖状态
SELECT auction_id, title, status, end_time, reserve_price,
       (SELECT MAX(bid_amount) FROM Bid WHERE auction_id = Auction.auction_id) as highest_bid
FROM Auction 
WHERE auction_id = 2;

-- 更新状态为ended（如果需要）
UPDATE Auction SET status = 'ended' WHERE auction_id = 2;

-- 检查是否有AuctionOutcome
SELECT * FROM AuctionOutcome WHERE auction_id = 2;

-- 如果没有，创建（使用最高出价）
INSERT INTO AuctionOutcome 
  (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at)
SELECT 
  2,
  bidder_id,
  bid_amount,
  (bid_amount >= (SELECT reserve_price FROM Auction WHERE auction_id = 2)) as reserve_met,
  (bid_amount >= (SELECT reserve_price FROM Auction WHERE auction_id = 2)) as seller_accepted,
  DATE_ADD(NOW(), INTERVAL 24 HOUR),
  NOW()
FROM Bid
WHERE auction_id = 2 AND is_active = TRUE
ORDER BY bid_amount DESC, bid_time ASC
LIMIT 1;
```

## 为什么不需要"waiting"状态？

1. **已有机制完善**：`AuctionOutcome`表的字段组合已经能表示所有状态
2. **逻辑清晰**：拍卖结束就是`ended`，是否需要决策由`reserve_met`和`seller_accepted`判断
3. **减少复杂度**：不需要维护额外的状态转换逻辑

### 判断是否需要决策的逻辑

```php
// 在 listing.php 中已实现
if ($auction['status'] === 'ended' && 
    $outcome && 
    $outcome['winner_id'] && 
    !$outcome['reserve_met'] && 
    !$outcome['seller_accepted'] && 
    $now < $deadline) {
    // 显示决策按钮
}
```

这个逻辑已经完全覆盖了"等待卖家决策"的状态，无需新增数据库字段。

## 测试场景

### 测试1：已达保留价（自动完成）
- 创建拍卖，保留价 £50
- 出价 £60
- 等待拍卖结束
- 结果：自动完成，不显示决策按钮

### 测试2：未达保留价（需要决策）
- 创建拍卖，保留价 £50
- 出价 £40
- 等待拍卖结束
- 运行同步
- **以卖家身份登录**
- 访问`listing.php?auction_id=X`
- 结果：显示Accept/Reject按钮

### 测试3：决策超时
- 同测试2
- 不做决策
- 等待24小时或手动修改deadline
- 运行`cron_expire_decisions.php`
- 结果：自动拒绝，不再显示按钮

## 常见问题

### Q1: 我是卖家，但看不到按钮？

**检查清单：**
1. 确认以卖家身份登录（不是买家）
2. 运行诊断工具检查6个条件
3. 运行同步脚本修复状态
4. 刷新页面（Ctrl+F5强制刷新）

### Q2: 按钮显示了但点击没反应？

**检查：**
1. 浏览器控制台是否有JavaScript错误
2. `accept_bid.php`文件是否存在
3. 检查PHP错误日志

### Q3: 同步后还是不显示？

**可能原因：**
1. 最高出价已达到保留价（自动完成，无需决策）
2. 决策截止时间已过
3. 已经做过决策
4. 缓存问题（清除浏览器缓存）

## 相关文件

- `listing.php` - 拍卖详情页，包含决策按钮前端代码（第327-347行）
- `accept_bid.php` - 处理接受/拒绝操作
- `auction_functions.php` - `closeAuction()`函数，创建AuctionOutcome
- `sync_auction_outcomes.php` - 同步状态脚本
- `diagnose_seller_decision_buttons.php` - 诊断工具（新增）
- `cron_expire_decisions.php` - 处理超时决策

## 总结

✅ **无需修改数据库结构**
✅ **无需添加新状态**
✅ **前端代码已完整实现**

**只需要：**
1. 运行同步脚本更新状态
2. 确保以正确身份登录
3. 验证所有条件满足

使用诊断工具可以快速定位问题所在！
