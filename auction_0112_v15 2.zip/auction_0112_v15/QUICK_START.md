# 拍卖自动关闭系统 - 快速启动指南

## 🎯 目标

实现**拍卖到达结束时间后自动同步更新status为ended并同步到AuctionOutcome**

## ⚡ 快速启动（3步完成）

### 第1步：运行自动化设置脚本

```bash
cd /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v14
./setup_auto_close_cron.sh
```

脚本会自动：
- ✅ 检查PHP环境和必要文件
- ✅ 创建日志目录
- ✅ 配置定时任务（每5分钟检查一次）
- ✅ 运行测试验证

**跟随提示操作即可！**

### 第2步：访问监控面板

打开浏览器访问：
```
http://localhost/auction_0112_v14/monitor_auto_close.php
```

监控面板会显示：
- 📊 待关闭的拍卖数量
- 📈 活跃拍卖统计
- 📋 最近关闭的拍卖列表
- 📄 实时日志查看
- ✅ 系统健康检查

**页面每30秒自动刷新！**

### 第3步：验证系统工作

方式1：查看监控面板
- 待关闭拍卖数应该为 0 或很快变为 0
- 查看"最近关闭的拍卖"列表
- 查看日志输出

方式2：命令行查看日志
```bash
tail -f logs/cron_close_auctions.log
```

方式3：运行完整测试
```
http://localhost/auction_0112_v14/test_auction_sync.php
```

## 🔧 系统工作原理

### 自动化机制

系统有**3重保障**确保拍卖自动关闭：

#### 1️⃣ 定时任务（主要方式）
```
每5分钟自动执行
  ↓
查找 status='active' 且 end_time<=NOW() 的拍卖
  ↓
调用 closeAuction() 函数
  ↓
更新 status='ended' + 创建 AuctionOutcome
  ↓
记录日志
```

#### 2️⃣ 页面访问触发（备用）
```
用户访问 listing.php
  ↓
检测拍卖是否过期
  ↓
如果过期则自动关闭
  ↓
显示最新状态
```

#### 3️⃣ 手动同步（应急）
```
访问 sync_auction_outcomes.php
  ↓
手动触发同步
  ↓
修复任何不一致
```

### 处理逻辑

```
拍卖到达结束时间
         ↓
┌────────┴────────┐
│ 自动关闭机制触发 │
└────────┬────────┘
         ↓
   closeAuction()
         ↓
┌────────┴────────┐
│ 获取最高出价     │
└────────┬────────┘
         ↓
    判断出价 vs 保留价
         ↓
┌────────┴────────┬────────┐
│                 │        │
出价≥保留价    出价<保留价  无出价
│                 │        │
自动完成       等待决策   无中标者
reserve_met=T  reserve_met=F  winner_id=NULL
seller_        seller_
accepted=T     accepted=F
│                 │        │
└────────┬────────┴────────┘
         ↓
   发送通知给相关方
         ↓
    ✓ 完成同步
```

## 📋 验证清单

完成设置后，请验证以下项目：

### ✅ 定时任务配置
```bash
# 查看crontab
crontab -l

# 应该看到类似：
*/5 * * * * /usr/bin/php /path/to/cron_close_auctions.php >> /path/to/logs/cron_close_auctions.log 2>&1
0 * * * * /usr/bin/php /path/to/cron_expire_decisions.php >> /path/to/logs/cron_expire_decisions.log 2>&1
```

### ✅ 日志文件存在
```bash
ls -la logs/
# 应该看到：
# cron_close_auctions.log
# cron_expire_decisions.log
```

### ✅ 监控面板正常
访问 `monitor_auto_close.php` 应该显示：
- 待关闭拍卖数量
- 系统文件检查通过
- 日志内容可见

### ✅ 手动测试成功
```bash
php cron_close_auctions.php
# 应该看到类似输出：
# [2025-12-02 14:30:01] Cron: Starting automatic auction closure
# [2025-12-02 14:30:01] Cron: Found 0 auction(s) to close
```

## 🎮 管理控制面板

访问主控制面板获取所有功能：
```
http://localhost/auction_0112_v14/auction_sync_dashboard.php
```

功能包括：
- 📊 检查和诊断工具
- 🔄 状态同步工具
- 👨‍💼 卖家决策管理
- 📈 实时监控面板
- 📚 完整文档

## 📊 实时监控

### 监控面板特性

- **自动刷新**：每30秒自动更新数据
- **实时统计**：待关闭、活跃、待决策拍卖数量
- **日志查看**：最后20行日志实时显示
- **历史记录**：最近24小时关闭的拍卖
- **健康检查**：系统文件和日志目录状态

### 关键指标

1. **待关闭拍卖数** 
   - 正常情况应该是 0 或很小
   - 如果持续增长，说明定时任务未运行

2. **活跃拍卖数**
   - 显示当前进行中的拍卖数量

3. **待决策拍卖数**
   - 最高出价低于保留价，等待卖家决策的数量

4. **超时决策数**
   - 应该是 0
   - 如果有值，点击"立即处理"按钮

## 🔍 常见问题

### Q1: 定时任务不执行？

**检查：**
```bash
# 1. 确认crontab配置
crontab -l

# 2. 查看系统日志
tail -f /var/log/syslog  # Linux
tail -f /var/log/system.log  # macOS

# 3. 手动测试
php cron_close_auctions.php
```

### Q2: 拍卖没有自动关闭？

**解决：**
1. 访问监控面板查看待关闭数量
2. 点击"立即执行"按钮手动触发
3. 或访问 `sync_auction_outcomes.php` 同步

### Q3: 日志文件不存在？

**解决：**
```bash
mkdir -p logs
chmod 777 logs
touch logs/cron_close_auctions.log
chmod 666 logs/*.log
```

### Q4: 权限错误？

**解决：**
```bash
# 给脚本执行权限
chmod +x setup_auto_close_cron.sh
chmod 755 cron_close_auctions.php

# 给日志目录写权限
chmod 777 logs/
```

## 📈 监控命令

### 实时查看日志
```bash
# 关闭日志
tail -f logs/cron_close_auctions.log

# 决策日志
tail -f logs/cron_expire_decisions.log

# 查看最近20行
tail -20 logs/cron_close_auctions.log
```

### 手动执行
```bash
# 关闭到期拍卖
php cron_close_auctions.php

# 处理超时决策
php cron_expire_decisions.php

# 同步所有状态
php sync_auction_outcomes.php
```

### 定时任务管理
```bash
# 查看配置
crontab -l

# 编辑配置
crontab -e

# 删除所有任务（谨慎！）
crontab -r
```

## 🎯 测试场景

### 测试1：创建即将到期的拍卖

1. 创建测试拍卖，结束时间设置为1分钟后
2. 等待拍卖到期
3. 观察监控面板：待关闭数量 +1
4. 等待5分钟（定时任务执行）
5. 观察监控面板：待关闭数量 -1
6. 查看"最近关闭的拍卖"列表

### 测试2：手动触发

1. 创建测试拍卖，结束时间设置为过去
2. 访问监控面板，看到待关闭数量 +1
3. 点击"立即执行"按钮
4. 刷新页面，待关闭数量应该变为 0

### 测试3：页面触发

1. 创建测试拍卖，结束时间设置为过去
2. 访问 `listing.php?auction_id=X`
3. 页面应该显示"This auction has ended"
4. 检查数据库，status应该是'ended'

## 📚 相关文档

- **完整实现文档**: `AUTO_CLOSE_IMPLEMENTATION.md`
- **状态同步指南**: `AUCTION_STATUS_SYNC_GUIDE.md`
- **卖家决策按钮**: `SELLER_DECISION_BUTTON_GUIDE.md`

## ✨ 完成！

恭喜！您的拍卖系统现在已经实现了：

✅ **拍卖到达结束时间后自动更新status为ended**
✅ **自动同步创建AuctionOutcome记录**
✅ **根据出价情况自动设置初始状态**
✅ **完整的监控和管理界面**
✅ **多重保障机制**

系统会：
- 每5分钟自动检查并关闭到期拍卖
- 用户访问时即时检查并关闭
- 提供Web监控面板实时查看状态
- 记录详细日志便于排查问题

享受您的全自动拍卖系统吧！🎉
