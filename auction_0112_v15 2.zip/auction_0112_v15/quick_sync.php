<!DOCTYPE html>
<html>
<head>
    <title>一键同步拍卖状态</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { 
            padding: 40px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .main-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            max-width: 800px;
            margin: 0 auto;
        }
        .btn-sync {
            font-size: 20px;
            padding: 20px 40px;
            border-radius: 50px;
            transition: all 0.3s;
        }
        .btn-sync:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .status-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .icon-large {
            font-size: 60px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="main-card">
        <div class="text-center">
            <i class="fas fa-sync-alt icon-large text-primary"></i>
            <h1 class="mb-4">拍卖状态同步</h1>
            <p class="lead text-muted">将已到达结束时间的拍卖自动更新为 ended 状态</p>
        </div>
        
        <hr class="my-4">
        
        <?php
        require_once 'db_connection.php';
        
        // 检查待同步的拍卖
        $stmt = $pdo->query("
            SELECT COUNT(*) as count
            FROM Auction 
            WHERE status = 'active' AND end_time <= NOW()
        ");
        $pending = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if (isset($_GET['action']) && $_GET['action'] === 'sync') {
            // 执行同步
            echo '<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> 正在同步...</div>';
            echo '<script>window.location.href="sync_auction_outcomes.php";</script>';
            exit;
        }
        ?>
        
        <div class="status-box">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4><i class="fas fa-clock text-warning"></i> 待同步拍卖</h4>
                    <p class="mb-0 text-muted">发现 <strong class="text-danger"><?php echo $pending; ?></strong> 个拍卖需要同步状态</p>
                </div>
                <div class="col-md-4 text-center">
                    <div style="font-size: 48px; font-weight: bold; color: <?php echo $pending > 0 ? '#dc3545' : '#28a745'; ?>">
                        <?php echo $pending; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if ($pending > 0): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> 
                <strong>检测到未同步的拍卖！</strong><br>
                这些拍卖已经到达结束时间但状态仍为 active，需要更新为 ended 并创建 AuctionOutcome 记录。
            </div>
            
            <div class="text-center my-4">
                <a href="?action=sync" class="btn btn-primary btn-sync btn-lg">
                    <i class="fas fa-sync-alt"></i> 立即同步
                </a>
            </div>
        <?php else: ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> 
                <strong>所有拍卖状态正常！</strong><br>
                没有需要同步的拍卖。
            </div>
        <?php endif; ?>
        
        <hr class="my-4">
        
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-list"></i> 快速操作</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="test_auction_sync.php" class="btn btn-outline-info btn-sm btn-block">
                            <i class="fas fa-vial"></i> 运行完整测试
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="check_auction_status_sync.php" class="btn btn-outline-secondary btn-sm btn-block">
                            <i class="fas fa-search"></i> 查看详细状态
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="monitor_auto_close.php" class="btn btn-outline-primary btn-sm btn-block">
                            <i class="fas fa-chart-line"></i> 实时监控面板
                        </a>
                    </li>
                </ul>
            </div>
            
            <div class="col-md-6">
                <h5><i class="fas fa-info-circle"></i> 系统信息</h5>
                <?php
                // 显示最近关闭的拍卖
                $stmt = $pdo->query("
                    SELECT a.auction_id, a.title, a.end_time, a.status
                    FROM Auction a
                    WHERE a.status = 'ended'
                    ORDER BY a.end_time DESC
                    LIMIT 3
                ");
                $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
                ?>
                <p class="small text-muted mb-2">最近关闭的拍卖：</p>
                <?php if (count($recent) > 0): ?>
                    <ul class="small">
                        <?php foreach ($recent as $r): ?>
                            <li class="text-success">
                                <i class="fas fa-check"></i> 
                                ID <?php echo $r['auction_id']; ?>: <?php echo htmlspecialchars(substr($r['title'], 0, 20)); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="small text-muted">暂无已关闭的拍卖</p>
                <?php endif; ?>
            </div>
        </div>
        
        <hr class="my-4">
        
        <div class="text-center">
            <a href="auction_sync_dashboard.php" class="btn btn-outline-primary">
                <i class="fas fa-tachometer-alt"></i> 返回控制面板
            </a>
            <a href="index.php" class="btn btn-outline-secondary">
                <i class="fas fa-home"></i> 返回首页
            </a>
        </div>
    </div>
</body>
</html>
