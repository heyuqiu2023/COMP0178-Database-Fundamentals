# 卖家接受/拒绝低于保留价出价功能说明

## 功能概述

当拍卖结束且最高出价低于保留价时，系统会要求卖家在 24 小时内决定是否接受该出价。

## 前端显示位置

### 1. My Listings 页面 (`mylistings.php`)

**显示内容：**
- 页面顶部显示醒目的警告提示框
- "Pending Decisions" 专区列出所有待决策的拍卖
- 每个拍卖显示为独立的卡片，包含：
  - 拍卖标题
  - 过期倒计时（红色徽章）
  - 赢家用户名
  - 最高出价金额（绿色）
  - 保留价格（红色）
  - 决策截止时间
  - 差价说明（保留价 - 最高出价）
  - **两个大按钮：**
    - ✅ "Accept Bid" (绿色) - 接受出价
    - ❌ "Reject Bid" (红色) - 拒绝出价

**按钮功能：**
- 点击任一按钮会弹出确认对话框
- 确认后跳转到 `accept_bid.php` 处理
- 处理完成后返回 My Listings 并显示成功/失败消息

### 2. 拍卖详情页面 (`listing.php`)

**显示内容（仅卖家可见）：**
当卖家访问自己已结束且低于保留价的拍卖时，会看到：

- 黄色警告框："Pending Seller Decision"
- 显示最高出价和保留价对比
- 橙色"Action Required"卡片，包含：
  - 赢家姓名
  - 最终出价金额
  - 保留价格
  - 决策说明文本
  - **两个大按钮：**
    - ✅ "Accept Bid" (绿色)
    - ❌ "Reject Bid" (红色)
  - 截止时间倒计时

**其他用户视角：**
- **赢家看到：** "您的出价是最高的，但低于保留价。卖家将决定是否接受。"
- **其他人看到：** "等待卖家决策"的通用消息

## 按钮交互

### Accept Bid 按钮
**确认对话框内容：**
```
Are you sure you want to ACCEPT this bid of £XX.XX?

By accepting, you agree to sell this item to [Winner Name]. 
The buyer will be notified immediately.
```

**执行操作：**
1. 更新 `AuctionOutcome.seller_accepted = TRUE`
2. 发送通知给买家
3. 标记拍卖为成功
4. 显示成功消息并返回

### Reject Bid 按钮
**确认对话框内容：**
```
Are you sure you want to REJECT this bid?

The auction will be marked as unsuccessful and [Winner Name] 
will be notified that their bid was not accepted.
```

**执行操作：**
1. 更新 `AuctionOutcome.seller_accepted = FALSE`
2. 清空 `winner_id` 和 `final_price`
3. 发送通知给买家
4. 标记拍卖为失败
5. 显示成功消息并返回

## 视觉设计

### 颜色方案
- **警告/待处理：** 黄色/橙色（Bootstrap warning）
- **接受按钮：** 绿色（Bootstrap success）
- **拒绝按钮：** 红色（Bootstrap danger）
- **成功消息：** 绿色（Bootstrap success）
- **错误消息：** 红色（Bootstrap danger）

### 图标使用
- ⚠️ `fa-exclamation-triangle` - 警告
- ⏱️ `fa-stopwatch` - 倒计时
- 👤 `fa-user` - 用户
- 💷 `fa-pound-sign` - 价格
- 🛡️ `fa-shield-alt` - 保留价
- 📅 `fa-calendar-times` - 截止日期
- ✅ `fa-check-circle` - 接受
- ❌ `fa-times-circle` - 拒绝
- ℹ️ `fa-info-circle` - 信息

## 业务规则

1. **24小时决策期**：从拍卖结束时刻开始计算
2. **过期处理**：超过24小时未决策，视为自动拒绝
3. **不可逆操作**：一旦接受或拒绝，不可更改
4. **仅一次决策**：每个拍卖只能决策一次
5. **通知机制**：所有决策都会通知相关方

## 测试场景

### 场景1：卖家接受低于保留价的出价
1. 创建拍卖，设置保留价 £100
2. 买家出价 £80
3. 等待拍卖结束（或运行 cron）
4. 卖家登录，访问 My Listings
5. 看到 "Action Required" 警告
6. 点击 "Accept Bid" 按钮
7. 确认对话框，点击 OK
8. 系统显示 "You have accepted the bid..."
9. 买家收到通知
10. 拍卖详情页显示 "Auction Successful"

### 场景2：卖家拒绝低于保留价的出价
1. 同上创建拍卖和出价
2. 卖家点击 "Reject Bid"
3. 确认拒绝
4. 系统显示 "You have rejected the bid..."
5. 买家收到拒绝通知
6. 拍卖详情页显示 "Auction Unsuccessful"

### 场景3：卖家在详情页直接决策
1. 卖家直接访问拍卖详情页
2. 看到橙色 "Action Required" 卡片
3. 直接在详情页点击接受/拒绝
4. 处理逻辑与 My Listings 相同

## 代码文件

- `mylistings.php` - 显示待决策列表
- `listing.php` - 拍卖详情页的决策按钮
- `accept_bid.php` - 处理接受/拒绝的后端逻辑
- `cron_close_auctions.php` - 自动关闭拍卖并创建待决策项

## 安全性

1. **权限验证**：只有拍卖所有者可以决策
2. **状态检查**：验证拍卖已结束
3. **截止时间检查**：验证未超过决策期限
4. **重复决策保护**：已决策的不能再次决策
5. **事务处理**：使用数据库事务确保数据一致性
