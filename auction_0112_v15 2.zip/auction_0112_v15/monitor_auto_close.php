<?php
/**
 * 自动拍卖关闭系统 - 监控面板
 * 实时显示系统状态和定时任务运行情况
 */
require_once 'db_connection.php';

header('Content-Type: text/html; charset=UTF-8');

// 获取系统状态
$log_dir = __DIR__ . '/logs';
$close_log = $log_dir . '/cron_close_auctions.log';
$expire_log = $log_dir . '/cron_expire_decisions.log';
?>
<!DOCTYPE html>
<html>
<head>
    <title>自动拍卖关闭系统 - 监控面板</title>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="30">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { padding: 20px; background: #f8f9fa; }
        .status-card { margin-bottom: 20px; }
        .log-viewer { 
            background: #1e1e1e; 
            color: #d4d4d4; 
            padding: 15px; 
            border-radius: 5px; 
            font-family: 'Courier New', monospace;
            font-size: 12px;
            max-height: 400px;
            overflow-y: auto;
            white-space: pre-wrap;
        }
        .metric { font-size: 2em; font-weight: bold; }
        .refresh-info { 
            position: fixed; 
            top: 10px; 
            right: 10px; 
            background: rgba(0,0,0,0.7); 
            color: white; 
            padding: 10px; 
            border-radius: 5px;
        }
        .success-text { color: #28a745; }
        .warning-text { color: #ffc107; }
        .error-text { color: #dc3545; }
    </style>
</head>
<body>
    <div class="refresh-info">
        <i class="fas fa-sync-alt"></i> 自动刷新: 30秒
    </div>
    
    <div class="container-fluid">
        <h1><i class="fas fa-chart-line"></i> 自动拍卖关闭系统 - 监控面板</h1>
        <p class="text-muted">当前时间: <?php echo date('Y-m-d H:i:s'); ?></p>
        <hr>
        
        <div class="row">
            <!-- 待关闭的拍卖 -->
            <div class="col-md-3">
                <div class="card status-card border-warning">
                    <div class="card-header bg-warning text-dark">
                        <i class="fas fa-clock"></i> 待关闭的拍卖
                    </div>
                    <div class="card-body text-center">
                        <?php
                        $stmt = $pdo->query("SELECT COUNT(*) FROM Auction WHERE status = 'active' AND end_time <= NOW()");
                        $pending = $stmt->fetchColumn();
                        $class = $pending > 0 ? 'warning-text' : 'success-text';
                        ?>
                        <div class="metric <?php echo $class; ?>"><?php echo $pending; ?></div>
                        <p class="text-muted mb-0">个拍卖需要关闭</p>
                        <?php if ($pending > 0): ?>
                            <a href="cron_close_auctions.php" class="btn btn-warning btn-sm mt-2">
                                <i class="fas fa-play"></i> 立即执行
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- 活跃拍卖 -->
            <div class="col-md-3">
                <div class="card status-card border-primary">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-gavel"></i> 活跃拍卖
                    </div>
                    <div class="card-body text-center">
                        <?php
                        $stmt = $pdo->query("SELECT COUNT(*) FROM Auction WHERE status = 'active' AND end_time > NOW()");
                        $active = $stmt->fetchColumn();
                        ?>
                        <div class="metric text-primary"><?php echo $active; ?></div>
                        <p class="text-muted mb-0">个进行中</p>
                    </div>
                </div>
            </div>
            
            <!-- 待决策的拍卖 -->
            <div class="col-md-3">
                <div class="card status-card border-info">
                    <div class="card-header bg-info text-white">
                        <i class="fas fa-user-clock"></i> 待卖家决策
                    </div>
                    <div class="card-body text-center">
                        <?php
                        $stmt = $pdo->query("
                            SELECT COUNT(*) FROM AuctionOutcome 
                            WHERE reserve_met = FALSE 
                            AND seller_accepted = FALSE 
                            AND winner_id IS NOT NULL
                            AND acceptance_deadline > NOW()
                        ");
                        $pending_decision = $stmt->fetchColumn();
                        ?>
                        <div class="metric text-info"><?php echo $pending_decision; ?></div>
                        <p class="text-muted mb-0">个等待决策</p>
                    </div>
                </div>
            </div>
            
            <!-- 超时决策 -->
            <div class="col-md-3">
                <div class="card status-card border-danger">
                    <div class="card-header bg-danger text-white">
                        <i class="fas fa-exclamation-triangle"></i> 超时决策
                    </div>
                    <div class="card-body text-center">
                        <?php
                        $stmt = $pdo->query("
                            SELECT COUNT(*) FROM AuctionOutcome 
                            WHERE reserve_met = FALSE 
                            AND seller_accepted = FALSE 
                            AND winner_id IS NOT NULL
                            AND acceptance_deadline <= NOW()
                            AND seller_notified = FALSE
                        ");
                        $expired_decision = $stmt->fetchColumn();
                        $class = $expired_decision > 0 ? 'error-text' : 'success-text';
                        ?>
                        <div class="metric <?php echo $class; ?>"><?php echo $expired_decision; ?></div>
                        <p class="text-muted mb-0">个需要处理</p>
                        <?php if ($expired_decision > 0): ?>
                            <a href="cron_expire_decisions.php" class="btn btn-danger btn-sm mt-2">
                                <i class="fas fa-play"></i> 立即处理
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 最近关闭的拍卖 -->
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <i class="fas fa-check-circle"></i> 最近关闭的拍卖 (24小时内)
            </div>
            <div class="card-body">
                <?php
                $stmt = $pdo->query("
                    SELECT a.auction_id, a.title, a.end_time, a.reserve_price,
                           ao.final_price, ao.reserve_met, ao.seller_accepted, ao.concluded_at,
                           u.username as winner_name
                    FROM Auction a
                    LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                    LEFT JOIN User u ON ao.winner_id = u.user_id
                    WHERE a.status = 'ended' 
                    AND a.end_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                    ORDER BY a.end_time DESC
                    LIMIT 10
                ");
                $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($recent) > 0):
                ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>标题</th>
                                    <th>结束时间</th>
                                    <th>保留价</th>
                                    <th>最终价</th>
                                    <th>状态</th>
                                    <th>中标者</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent as $row): 
                                    $status = '无出价';
                                    $status_class = 'text-muted';
                                    if ($row['final_price']) {
                                        if ($row['reserve_met']) {
                                            $status = '✓ 已完成';
                                            $status_class = 'text-success';
                                        } elseif ($row['seller_accepted']) {
                                            $status = '✓ 卖家接受';
                                            $status_class = 'text-success';
                                        } else {
                                            $status = '⏳ 待决策';
                                            $status_class = 'text-warning';
                                        }
                                    }
                                ?>
                                    <tr>
                                        <td><?php echo $row['auction_id']; ?></td>
                                        <td><?php echo htmlspecialchars(substr($row['title'], 0, 30)); ?></td>
                                        <td><?php echo $row['end_time']; ?></td>
                                        <td>£<?php echo number_format($row['reserve_price'], 2); ?></td>
                                        <td><?php echo $row['final_price'] ? '£' . number_format($row['final_price'], 2) : '-'; ?></td>
                                        <td class="<?php echo $status_class; ?>"><?php echo $status; ?></td>
                                        <td><?php echo $row['winner_name'] ? htmlspecialchars($row['winner_name']) : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">最近24小时内没有拍卖结束</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row">
            <!-- 关闭日志 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-file-alt"></i> 拍卖关闭日志 (最后20行)
                    </div>
                    <div class="card-body">
                        <div class="log-viewer">
<?php
if (file_exists($close_log)) {
    $lines = file($close_log);
    $last_lines = array_slice($lines, -20);
    foreach ($last_lines as $line) {
        $line = htmlspecialchars($line);
        // 语法高亮
        if (strpos($line, 'ERROR') !== false || strpos($line, '✗') !== false) {
            echo "<span class='error-text'>$line</span>";
        } elseif (strpos($line, 'Successfully') !== false || strpos($line, '✓') !== false) {
            echo "<span class='success-text'>$line</span>";
        } elseif (strpos($line, '⚠') !== false) {
            echo "<span class='warning-text'>$line</span>";
        } else {
            echo $line;
        }
    }
} else {
    echo "日志文件不存在: $close_log\n";
    echo "定时任务可能尚未运行。";
}
?>
                        </div>
                        <a href="<?php echo basename($close_log); ?>" class="btn btn-sm btn-outline-secondary mt-2" target="_blank">
                            <i class="fas fa-external-link-alt"></i> 查看完整日志
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- 决策超时日志 -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-file-alt"></i> 决策超时日志 (最后20行)
                    </div>
                    <div class="card-body">
                        <div class="log-viewer">
<?php
if (file_exists($expire_log)) {
    $lines = file($expire_log);
    $last_lines = array_slice($lines, -20);
    foreach ($last_lines as $line) {
        $line = htmlspecialchars($line);
        if (strpos($line, 'ERROR') !== false || strpos($line, '✗') !== false) {
            echo "<span class='error-text'>$line</span>";
        } elseif (strpos($line, 'Successfully') !== false || strpos($line, '✓') !== false) {
            echo "<span class='success-text'>$line</span>";
        } elseif (strpos($line, '⚠') !== false) {
            echo "<span class='warning-text'>$line</span>";
        } else {
            echo $line;
        }
    }
} else {
    echo "日志文件不存在: $expire_log\n";
    echo "定时任务可能尚未运行。";
}
?>
                        </div>
                        <a href="<?php echo basename($expire_log); ?>" class="btn btn-sm btn-outline-secondary mt-2" target="_blank">
                            <i class="fas fa-external-link-alt"></i> 查看完整日志
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 系统检查 -->
        <div class="card mt-4">
            <div class="card-header">
                <i class="fas fa-cog"></i> 系统检查
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>必要文件检查</h6>
                        <ul class="list-unstyled">
                            <?php
                            $files = [
                                'cron_close_auctions.php' => '拍卖关闭脚本',
                                'cron_expire_decisions.php' => '决策超时脚本',
                                'auction_functions.php' => '拍卖函数库',
                                'sync_auction_outcomes.php' => '状态同步脚本'
                            ];
                            foreach ($files as $file => $desc):
                                $exists = file_exists(__DIR__ . '/' . $file);
                            ?>
                                <li>
                                    <i class="fas fa-<?php echo $exists ? 'check-circle text-success' : 'times-circle text-danger'; ?>"></i>
                                    <?php echo $desc; ?> (<?php echo $file; ?>)
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h6>日志目录检查</h6>
                        <ul class="list-unstyled">
                            <?php
                            $log_writable = is_dir($log_dir) && is_writable($log_dir);
                            ?>
                            <li>
                                <i class="fas fa-<?php echo $log_writable ? 'check-circle text-success' : 'times-circle text-danger'; ?>"></i>
                                日志目录 <?php echo $log_writable ? '可写' : '不可写'; ?>
                            </li>
                            <li>
                                <i class="fas fa-<?php echo file_exists($close_log) ? 'check-circle text-success' : 'times-circle text-warning'; ?>"></i>
                                关闭日志 <?php echo file_exists($close_log) ? '存在' : '不存在'; ?>
                            </li>
                            <li>
                                <i class="fas fa-<?php echo file_exists($expire_log) ? 'check-circle text-success' : 'times-circle text-warning'; ?>"></i>
                                决策日志 <?php echo file_exists($expire_log) ? '存在' : '不存在'; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="auction_sync_dashboard.php" class="btn btn-primary">
                <i class="fas fa-tachometer-alt"></i> 返回控制面板
            </a>
            <a href="test_auction_sync.php" class="btn btn-info">
                <i class="fas fa-vial"></i> 运行测试
            </a>
            <button onclick="location.reload()" class="btn btn-secondary">
                <i class="fas fa-sync-alt"></i> 手动刷新
            </button>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
