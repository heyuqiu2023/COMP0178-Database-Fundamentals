<?php
/**
 * 完整功能验证脚本
 * 验证卖家决策功能的所有方面
 */

require_once 'db_connection.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Seller Decision Feature Verification</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    <style>
        .pass { color: green; font-weight: bold; }
        .fail { color: red; font-weight: bold; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>
<div class='container mt-4'>
<h1>🔍 Seller Decision Feature Verification</h1>
<hr>";

$all_pass = true;

// Test 1: Check auction_functions.php exists and has closeAuction function
echo "<div class='test-section'>
<h3>Test 1: Core Functions</h3>";

if (file_exists('auction_functions.php')) {
    echo "<p class='pass'>✓ auction_functions.php exists</p>";
    
    require_once 'auction_functions.php';
    if (function_exists('closeAuction')) {
        echo "<p class='pass'>✓ closeAuction() function is defined</p>";
    } else {
        echo "<p class='fail'>✗ closeAuction() function not found</p>";
        $all_pass = false;
    }
} else {
    echo "<p class='fail'>✗ auction_functions.php not found</p>";
    $all_pass = false;
}
echo "</div>";

// Test 2: Check database schema
echo "<div class='test-section'>
<h3>Test 2: Database Schema</h3>";

try {
    // Check AuctionOutcome table
    $stmt = $pdo->query("DESCRIBE AuctionOutcome");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $required_columns = ['outcome_id', 'auction_id', 'winner_id', 'final_price', 'reserve_met', 
                         'seller_accepted', 'acceptance_deadline', 'concluded_at'];
    
    foreach ($required_columns as $col) {
        if (in_array($col, $columns)) {
            echo "<p class='pass'>✓ AuctionOutcome.$col exists</p>";
        } else {
            echo "<p class='fail'>✗ AuctionOutcome.$col missing</p>";
            $all_pass = false;
        }
    }
    
    // Check Bid.is_active column
    $stmt = $pdo->query("DESCRIBE Bid");
    $bid_columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (in_array('is_active', $bid_columns)) {
        echo "<p class='pass'>✓ Bid.is_active exists</p>";
    } else {
        echo "<p class='fail'>✗ Bid.is_active missing</p>";
        $all_pass = false;
    }
    
} catch (Exception $e) {
    echo "<p class='fail'>✗ Database error: " . $e->getMessage() . "</p>";
    $all_pass = false;
}
echo "</div>";

// Test 3: Check ended auctions have outcomes
echo "<div class='test-section'>
<h3>Test 3: Auction Outcomes Consistency</h3>";

try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM Auction WHERE status = 'ended'");
    $ended_count = $stmt->fetch()['count'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as count 
                         FROM Auction a 
                         LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                         WHERE a.status = 'ended' AND ao.outcome_id IS NULL");
    $missing_outcomes = $stmt->fetch()['count'];
    
    echo "<p>Total ended auctions: <strong>$ended_count</strong></p>";
    echo "<p>Ended auctions without outcomes: <strong>$missing_outcomes</strong></p>";
    
    if ($missing_outcomes == 0) {
        echo "<p class='pass'>✓ All ended auctions have outcome records</p>";
    } else {
        echo "<p class='fail'>✗ $missing_outcomes ended auctions missing outcomes</p>";
        $all_pass = false;
    }
    
} catch (Exception $e) {
    echo "<p class='fail'>✗ Error: " . $e->getMessage() . "</p>";
    $all_pass = false;
}
echo "</div>";

// Test 4: Check rejected auctions have inactive bids
echo "<div class='test-section'>
<h3>Test 4: Bid Status Synchronization</h3>";

try {
    // Find rejected auctions (seller_accepted = FALSE and winner_id = NULL)
    $stmt = $pdo->query("SELECT a.auction_id, a.title,
                         COUNT(b.bid_id) as total_bids,
                         SUM(CASE WHEN b.is_active = TRUE THEN 1 ELSE 0 END) as active_bids
                         FROM Auction a
                         JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                         LEFT JOIN Bid b ON a.auction_id = b.auction_id
                         WHERE a.status = 'ended'
                         AND ao.reserve_met = FALSE
                         AND ao.seller_accepted = FALSE
                         AND ao.winner_id IS NULL
                         GROUP BY a.auction_id
                         HAVING COUNT(b.bid_id) > 0");
    
    $rejected_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($rejected_auctions)) {
        echo "<p>No rejected auctions with bids found to test.</p>";
    } else {
        echo "<p>Found " . count($rejected_auctions) . " rejected auction(s) with bids:</p>";
        echo "<table class='table table-sm table-bordered'>";
        echo "<tr><th>Auction ID</th><th>Total Bids</th><th>Active Bids</th><th>Status</th></tr>";
        
        foreach ($rejected_auctions as $auction) {
            $status = ($auction['active_bids'] == 0) ? 'pass' : 'fail';
            $icon = ($auction['active_bids'] == 0) ? '✓' : '✗';
            
            echo "<tr>";
            echo "<td>{$auction['auction_id']}</td>";
            echo "<td>{$auction['total_bids']}</td>";
            echo "<td>{$auction['active_bids']}</td>";
            echo "<td class='$status'>$icon " . ($auction['active_bids'] == 0 ? 'Correct' : 'Error: Should be 0') . "</td>";
            echo "</tr>";
            
            if ($auction['active_bids'] > 0) {
                $all_pass = false;
            }
        }
        echo "</table>";
        
        if ($all_pass) {
            echo "<p class='pass'>✓ All rejected auctions have inactive bids</p>";
        } else {
            echo "<p class='fail'>✗ Some rejected auctions still have active bids</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='fail'>✗ Error: " . $e->getMessage() . "</p>";
    $all_pass = false;
}
echo "</div>";

// Test 5: Check UI files exist
echo "<div class='test-section'>
<h3>Test 5: User Interface Files</h3>";

$ui_files = [
    'listing.php' => 'Auction detail page with decision buttons',
    'mylistings.php' => 'Seller listings with pending decisions',
    'accept_bid.php' => 'Accept/reject bid handler'
];

foreach ($ui_files as $file => $desc) {
    if (file_exists($file)) {
        echo "<p class='pass'>✓ $file exists ($desc)</p>";
    } else {
        echo "<p class='fail'>✗ $file missing</p>";
        $all_pass = false;
    }
}
echo "</div>";

// Test 6: Check cron jobs
echo "<div class='test-section'>
<h3>Test 6: Automated Tasks</h3>";

$cron_files = [
    'cron_close_auctions.php' => 'Auto-close ended auctions',
    'cron_expire_decisions.php' => 'Handle expired decisions'
];

foreach ($cron_files as $file => $desc) {
    if (file_exists($file)) {
        echo "<p class='pass'>✓ $file exists ($desc)</p>";
    } else {
        echo "<p class='fail'>✗ $file missing</p>";
        $all_pass = false;
    }
}
echo "</div>";

// Final Summary
echo "<hr>
<div class='alert alert-" . ($all_pass ? 'success' : 'danger') . "'>
<h2>" . ($all_pass ? '✓ All Tests Passed!' : '✗ Some Tests Failed') . "</h2>
<p>" . ($all_pass 
    ? 'The seller decision feature is fully implemented and working correctly.' 
    : 'Some issues were found. Please review the failed tests above.') . "</p>
</div>";

// Quick Links
echo "<h3>Quick Links for Testing:</h3>
<ul>
<li><a href='seller_decision_dashboard.php'>Seller Decision Dashboard</a></li>
<li><a href='mylistings.php'>My Listings</a></li>
<li><a href='browse.php'>Browse Auctions</a></li>
<li><a href='listing.php?auction_id=28'>View Auction #28</a></li>
</ul>";

echo "</div></body></html>";
?>
