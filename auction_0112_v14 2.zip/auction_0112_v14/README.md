# Auction Site

A full-featured online auction platform built with PHP and MySQL.

## Features

- User registration and authentication
- Create and manage auctions
- Browse and search listings by category
- Place bids on active auctions
- Watchlist functionality
- Real-time auction status tracking
- Multi-image upload support (JPEG, PNG, GIF, WebP, AVIF)
- Automatic auction closing system
- Email notifications

## Quick Start

### 1. Run Setup Script

```bash
chmod +x setup.sh
./setup.sh
```

### 2. Create Database

1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Create database: `auction_db`
3. Import: `CREATE TABLE User.sql`

### 3. Start Using

Open in browser: http://localhost/auction_0112_v12/

## Documentation

For detailed installation instructions, see [INSTALLATION.md](INSTALLATION.md)

## System Requirements

- PHP 7.4+
- MySQL 5.7+
- XAMPP/MAMP/LAMP

## Troubleshooting

If image upload fails:
```bash
chmod 777 img/auctions/
```

For more help, see the Troubleshooting section in [INSTALLATION.md](INSTALLATION.md)

## License

Educational project for database systems course.
