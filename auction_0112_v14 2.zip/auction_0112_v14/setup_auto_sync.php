<?php
/**
 * 创建数据库触发器：确保 Auction 状态变为 ended 时自动创建 AuctionOutcome
 */

require_once 'db_connection.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Auto-Sync Trigger</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
</head>
<body>
<div class='container mt-4'>
<h2>🔧 Setting Up Auto-Sync Mechanism</h2>
<hr>";

try {
    // 注意：MySQL 触发器不能调用存储过程创建 AuctionOutcome
    // 因为需要复杂的逻辑（查找最高出价等）
    // 所以我们采用应用层的解决方案
    
    echo "<div class='alert alert-info'>";
    echo "<h4>📋 Auto-Sync Strategy</h4>";
    echo "<p>由于需要复杂的业务逻辑（查找最高出价、计算保留价等），我们使用应用层自动同步：</p>";
    echo "<ol>";
    echo "<li><strong>closeAuction() 函数</strong>：已优化，确保每次调用都创建 AuctionOutcome</li>";
    echo "<li><strong>listing.php</strong>：访问时自动关闭过期拍卖并创建 outcome</li>";
    echo "<li><strong>cron_close_auctions.php</strong>：定时任务每分钟检查并关闭</li>";
    echo "<li><strong>check_db_consistency.php</strong>：定期检查并修复不一致</li>";
    echo "</ol>";
    echo "</div>";
    
    // 创建一个存储过程来辅助创建 AuctionOutcome
    echo "<h3>Creating Helper Stored Procedure</h3>";
    
    // 删除旧的存储过程（如果存在）
    $pdo->exec("DROP PROCEDURE IF EXISTS ensure_auction_outcome");
    
    // 创建新的存储过程
    $procedure_sql = "
    CREATE PROCEDURE ensure_auction_outcome(IN p_auction_id INT)
    BEGIN
        DECLARE v_outcome_exists INT DEFAULT 0;
        DECLARE v_winner_id INT DEFAULT NULL;
        DECLARE v_final_price DECIMAL(10,2) DEFAULT NULL;
        DECLARE v_reserve_price DECIMAL(10,2) DEFAULT NULL;
        DECLARE v_reserve_met BOOLEAN DEFAULT FALSE;
        DECLARE v_seller_accepted BOOLEAN DEFAULT FALSE;
        DECLARE v_deadline DATETIME;
        
        -- 检查是否已有 outcome
        SELECT COUNT(*) INTO v_outcome_exists 
        FROM AuctionOutcome 
        WHERE auction_id = p_auction_id;
        
        -- 如果没有 outcome，创建一个
        IF v_outcome_exists = 0 THEN
            -- 获取保留价
            SELECT reserve_price INTO v_reserve_price 
            FROM Auction 
            WHERE auction_id = p_auction_id;
            
            -- 获取最高出价
            SELECT bidder_id, bid_amount 
            INTO v_winner_id, v_final_price
            FROM Bid 
            WHERE auction_id = p_auction_id 
            AND is_active = TRUE
            ORDER BY bid_amount DESC, bid_time ASC 
            LIMIT 1;
            
            -- 判断是否达到保留价
            IF v_winner_id IS NOT NULL THEN
                IF v_reserve_price IS NULL OR v_reserve_price = 0 THEN
                    SET v_reserve_met = TRUE;
                ELSEIF v_final_price >= v_reserve_price THEN
                    SET v_reserve_met = TRUE;
                ELSE
                    SET v_reserve_met = FALSE;
                END IF;
                
                -- 如果达到保留价，自动接受
                SET v_seller_accepted = v_reserve_met;
            END IF;
            
            -- 设置决策期限（24小时）
            SET v_deadline = DATE_ADD(NOW(), INTERVAL 24 HOUR);
            
            -- 插入 AuctionOutcome
            INSERT INTO AuctionOutcome 
                (auction_id, winner_id, final_price, reserve_met, seller_accepted, acceptance_deadline, concluded_at, seller_notified, winner_notified)
            VALUES 
                (p_auction_id, v_winner_id, v_final_price, v_reserve_met, v_seller_accepted, v_deadline, NOW(), FALSE, FALSE);
        END IF;
    END";
    
    $pdo->exec($procedure_sql);
    
    echo "<div class='alert alert-success'>";
    echo "✓ Stored procedure <code>ensure_auction_outcome</code> created successfully!";
    echo "</div>";
    
    echo "<h3>Testing the Procedure</h3>";
    
    // 测试存储过程
    $test_stmt = $pdo->query("SELECT a.auction_id 
                              FROM Auction a 
                              LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                              WHERE a.status = 'ended' 
                              AND ao.outcome_id IS NULL 
                              LIMIT 1");
    $test_auction = $test_stmt->fetch();
    
    if ($test_auction) {
        $test_id = $test_auction['auction_id'];
        echo "<p>Found auction #$test_id without outcome. Testing procedure...</p>";
        
        try {
            $pdo->exec("CALL ensure_auction_outcome($test_id)");
            echo "<div class='alert alert-success'>✓ Procedure executed successfully for auction #$test_id</div>";
            
            // 验证
            $verify = $pdo->query("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = $test_id");
            if ($verify->fetchColumn() > 0) {
                echo "<p class='text-success'><strong>✓ Outcome created successfully!</strong></p>";
            }
        } catch (Exception $e) {
            echo "<div class='alert alert-warning'>Test skipped or failed: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<p class='text-muted'>No ended auctions without outcomes found. System is already in sync!</p>";
    }
    
    echo "<hr>";
    echo "<h3>Usage Instructions</h3>";
    echo "<div class='card'>";
    echo "<div class='card-body'>";
    echo "<h5>Manual Usage:</h5>";
    echo "<pre>CALL ensure_auction_outcome(auction_id);</pre>";
    echo "<h5>From PHP:</h5>";
    echo "<pre>\$pdo->exec(\"CALL ensure_auction_outcome(\$auction_id)\");</pre>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>";
    echo "<strong>Error:</strong> " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<h3>Next Steps</h3>";
echo "<ol>";
echo "<li>Run <a href='check_db_consistency.php?fix=1'>Database Consistency Check with Auto-Fix</a></li>";
echo "<li>Verify with <a href='verify_seller_decision_complete.php'>Full Verification Test</a></li>";
echo "<li>Check <a href='check_sync_28.php'>Auction #28 Sync Status</a></li>";
echo "</ol>";

echo "</div></body></html>";
?>
