# 拍卖关闭故障排查指南

## 问题描述

拍卖 #20 ("cloth") 结束时间已过（2025-12-01 13:58:00），但是：
- 拍卖状态仍然是 `active`（应该是 `ended`）
- AuctionOutcome 表中虽然有记录，但 `winner_id` 和 `final_price` 都是 NULL
- 系统没有自动关闭这个拍卖

## 根本原因分析

### 可能的原因

1. **Cron 任务未运行**
   - `cron_close_auctions.php` 需要通过系统 crontab 定期执行
   - 如果 cron 任务没有设置或执行失败，拍卖就不会自动关闭

2. **AuctionOutcome 过早创建**
   - 之前的代码在 `create_auction_result.php` 中创建拍卖时就创建了 AuctionOutcome
   - 这导致 AuctionOutcome 存在但数据为空（因为拍卖还没结束）

3. **没有后备机制**
   - 如果 cron 失败，没有其他方式来触发拍卖关闭
   - 用户访问页面时不会自动检查并关闭过期拍卖

## 解决方案

### 1. 修复拍卖 #20（已完成）

运行 `fix_auction_20.php` 脚本：
- ✅ 更新拍卖状态为 `ended`
- ✅ 填充 AuctionOutcome 的数据（winner_id=2, final_price=2222.00）
- ✅ 设置 reserve_met=1, seller_accepted=1（因为超过保留价）
- ✅ 发送通知给卖家和买家

### 2. 添加页面访问时的自动关闭（已完成）

在 `listing.php` 中添加了检查机制：
```php
// ⚠️ 自动关闭已过期但状态还是 active 的拍卖（防止卡住）
if ($status === 'active' && $now >= $end_time) {
    require_once 'place_bid.php';
    try {
        closeAuction($pdo, $auction);
        // 重新获取拍卖状态
        $stmt = $pdo->prepare("SELECT status FROM Auction WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        $status = $stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("Failed to auto-close auction $auction_id: " . $e->getMessage());
    }
}
```

这样即使 cron 任务失败，用户访问拍卖详情页时也会自动触发关闭。

### 3. 设置 Cron 任务（需要手动操作）

在系统的 crontab 中添加定期任务：

```bash
# 编辑 crontab
crontab -e

# 添加这一行（每分钟检查一次）
* * * * * /Applications/XAMPP/xamppfiles/bin/php /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/cron_close_auctions.php >> /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/logs/cron_output.log 2>&1
```

或者每5分钟检查一次：
```bash
*/5 * * * * /Applications/XAMPP/xamppfiles/bin/php /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/cron_close_auctions.php >> /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/logs/cron_output.log 2>&1
```

### 4. 移除创建拍卖时的 AuctionOutcome 创建（已完成）

之前已经从 `create_auction_result.php` 中移除了创建 AuctionOutcome 的代码。
现在 AuctionOutcome 只在拍卖关闭时创建（在 `closeAuction()` 函数中）。

## 验证修复

### 检查拍卖状态
```bash
/Applications/XAMPP/xamppfiles/bin/php -r "require_once 'db_connection.php'; \$a = \$pdo->query('SELECT auction_id, title, status, end_time FROM Auction WHERE auction_id=20')->fetch(PDO::FETCH_ASSOC); print_r(\$a);"
```

### 检查 AuctionOutcome
```bash
/Applications/XAMPP/xamppfiles/bin/php -r "require_once 'db_connection.php'; \$o = \$pdo->query('SELECT * FROM AuctionOutcome WHERE auction_id=20')->fetch(PDO::FETCH_ASSOC); print_r(\$o);"
```

### 检查 Cron 日志
```bash
tail -f logs/cron_close_auctions.log
```

## 预防措施

1. **双重保障机制**
   - ✅ Cron 任务定期检查（主要方式）
   - ✅ 页面访问时检查（备用方式）

2. **日志记录**
   - ✅ Cron 运行日志：`logs/cron_close_auctions.log`
   - ✅ PHP 错误日志：使用 `error_log()` 记录

3. **数据完整性**
   - ✅ 只在拍卖结束时创建 AuctionOutcome
   - ✅ 使用数据库事务确保数据一致性

## 监控建议

### 定期检查卡住的拍卖
创建一个维护脚本 `maintenance_check_stuck_auctions.php`：

```php
<?php
require_once 'db_connection.php';

// 查找所有状态为 active 但已经过期的拍卖
$stmt = $pdo->query("
    SELECT auction_id, title, status, end_time, 
           TIMESTAMPDIFF(MINUTE, end_time, NOW()) as minutes_overdue
    FROM Auction 
    WHERE status = 'active' AND end_time <= NOW()
    ORDER BY end_time ASC
");

$stuck_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($stuck_auctions) > 0) {
    echo "⚠️ Found " . count($stuck_auctions) . " stuck auction(s):\n\n";
    foreach ($stuck_auctions as $a) {
        echo "Auction #{$a['auction_id']}: {$a['title']}\n";
        echo "  Status: {$a['status']}\n";
        echo "  End time: {$a['end_time']}\n";
        echo "  Overdue by: {$a['minutes_overdue']} minutes\n\n";
    }
} else {
    echo "✅ No stuck auctions found.\n";
}
```

### 每天运行一次检查
```bash
# 添加到 crontab，每天早上 9 点运行
0 9 * * * /Applications/XAMPP/xamppfiles/bin/php /Applications/XAMPP/xamppfiles/htdocs/auction_0112_v12/maintenance_check_stuck_auctions.php
```

## 总结

- ✅ 拍卖 #20 已修复
- ✅ 添加了自动关闭的后备机制
- ⚠️ 需要设置 cron 任务（手动操作）
- ✅ 移除了过早创建 AuctionOutcome 的代码
- 📝 建议定期监控是否有卡住的拍卖

## 相关文件

- `cron_close_auctions.php` - Cron 任务脚本
- `place_bid.php` - 包含 `closeAuction()` 函数
- `listing.php` - 添加了自动关闭检查
- `fix_auction_20.php` - 修复脚本（可作为模板）
- `logs/cron_close_auctions.log` - Cron 运行日志
