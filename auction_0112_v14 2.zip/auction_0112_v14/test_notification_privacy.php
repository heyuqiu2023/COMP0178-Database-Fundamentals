<?php
/**
 * 测试通知隐私：验证用户只能看到自己的通知和邮件
 */

require_once 'db_connection.php';

echo "=== 通知隐私测试 ===\n\n";

// 获取所有用户
$stmt = $pdo->query("SELECT user_id, username, email FROM User ORDER BY user_id");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "系统中的用户：\n";
foreach ($users as $user) {
    echo "  - User ID {$user['user_id']}: {$user['username']} ({$user['email']})\n";
}
echo "\n";

// 获取所有通知的统计
$stmt = $pdo->query("
    SELECT 
        n.user_id,
        u.username,
        COUNT(*) as total_notifications,
        SUM(CASE WHEN n.email_sent = 0 THEN 1 ELSE 0 END) as unsent_emails
    FROM Notification n
    JOIN User u ON u.user_id = n.user_id
    GROUP BY n.user_id, u.username
    ORDER BY n.user_id
");
$stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "每个用户的通知统计：\n";
foreach ($stats as $stat) {
    echo "  - {$stat['username']} (ID {$stat['user_id']}): ";
    echo "{$stat['total_notifications']} 条通知, ";
    echo "{$stat['unsent_emails']} 条未发送邮件\n";
}
echo "\n";

// 测试每个用户的通知查询
echo "验证查询隔离（模拟 notifications.php 的查询）：\n";
foreach ($users as $user) {
    $user_id = $user['user_id'];
    $username = $user['username'];
    
    // 模拟 notifications.php 中的查询
    $stmt = $pdo->prepare("
        SELECT n.notification_id, n.type, n.content, n.is_read, n.created_at,
               a.title AS auction_title
        FROM Notification n
        LEFT JOIN Auction a ON n.auction_id = a.auction_id
        WHERE n.user_id = ?
        ORDER BY n.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "  ✓ {$username} (ID {$user_id}): 查询返回 " . count($notifications) . " 条通知\n";
}
echo "\n";

// 测试邮件队列隔离
echo "验证邮件队列隔离（模拟 process_email_queue）：\n";
foreach ($users as $user) {
    $user_id = $user['user_id'];
    $username = $user['username'];
    
    // 模拟 process_email_queue 中的查询（带 user_id 参数）
    $stmt = $pdo->prepare("
        SELECT n.notification_id, n.type, u.email, a.title
        FROM Notification n
        JOIN User u ON u.user_id = n.user_id
        LEFT JOIN Auction a ON a.auction_id = n.auction_id
        WHERE n.email_sent = 0 AND n.user_id = ?
        ORDER BY n.created_at ASC
    ");
    $stmt->execute([$user_id]);
    $unsent = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "  ✓ {$username} (ID {$user_id}): " . count($unsent) . " 条未发送邮件\n";
}
echo "\n";

echo "=== 测试完成 ===\n";
echo "✅ 如果每个用户的通知数量与统计一致，则隐私隔离正常\n";
?>
