<!DOCTYPE html>
<html>
<head>
    <title>Admin Tools - Auction System</title>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css'>
    <style>
        .tool-card {
            transition: transform 0.2s;
            height: 100%;
        }
        .tool-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .category-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4"><i class="fas fa-tools"></i> Auction System - Admin Tools</h1>
        
        <!-- Verification & Testing -->
        <div class="category-header">
            <h3><i class="fas fa-check-circle"></i> Verification & Testing</h3>
            <p class="mb-0">Run tests and verify system integrity</p>
        </div>
        
        <div class="row mb-5">
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-clipboard-check text-success"></i> Full Verification</h5>
                        <p class="card-text">Run complete system verification including all tests</p>
                        <a href="verify_seller_decision_complete.php" class="btn btn-success btn-block">Run Tests</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-database text-primary"></i> DB Consistency</h5>
                        <p class="card-text">Check and fix database consistency issues</p>
                        <a href="check_db_consistency.php" class="btn btn-primary btn-block">Check DB</a>
                        <a href="check_db_consistency.php?fix=1" class="btn btn-outline-primary btn-block btn-sm mt-2">Auto-Fix</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-wrench text-warning"></i> Fix Missing Outcomes</h5>
                        <p class="card-text">Create missing AuctionOutcome records</p>
                        <a href="fix_missing_outcomes.php" class="btn btn-warning btn-block">Fix Now</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Seller Management -->
        <div class="category-header">
            <h3><i class="fas fa-gavel"></i> Seller Management</h3>
            <p class="mb-0">Manage auctions and seller decisions</p>
        </div>
        
        <div class="row mb-5">
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-tachometer-alt text-info"></i> Seller Dashboard</h5>
                        <p class="card-text">View pending decisions and auction status</p>
                        <a href="seller_decision_dashboard.php" class="btn btn-info btn-block">Open Dashboard</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-list text-secondary"></i> My Listings</h5>
                        <p class="card-text">View all seller listings with pending actions</p>
                        <a href="mylistings.php" class="btn btn-secondary btn-block">View Listings</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-lock text-danger"></i> Close Expired</h5>
                        <p class="card-text">Manually close expired auctions</p>
                        <a href="close_expired_auctions.php" class="btn btn-danger btn-block">Close Auctions</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Specific Auction Tools -->
        <div class="category-header">
            <h3><i class="fas fa-cog"></i> Specific Auction Management</h3>
            <p class="mb-0">Manage individual auctions</p>
        </div>
        
        <div class="row mb-5">
            <div class="col-md-6 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-eye text-primary"></i> View Auction</h5>
                        <p class="card-text">View specific auction details</p>
                        <form method="GET" action="listing.php" class="form-inline">
                            <input type="number" name="auction_id" class="form-control mr-2" placeholder="Auction ID" required>
                            <button type="submit" class="btn btn-primary">View</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-edit text-warning"></i> Manage Auction</h5>
                        <p class="card-text">Manage specific auction (close, check status)</p>
                        <form method="GET" action="manage_auction_28.php" class="form-inline">
                            <input type="number" name="id" class="form-control mr-2" placeholder="Auction ID" value="28">
                            <button type="submit" class="btn btn-warning">Manage</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Documentation -->
        <div class="category-header">
            <h3><i class="fas fa-book"></i> Documentation</h3>
            <p class="mb-0">View implementation guides and reports</p>
        </div>
        
        <div class="row mb-5">
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-file-alt"></i> Implementation Guide</h5>
                        <p class="card-text">Seller Decision Feature Implementation</p>
                        <a href="SELLER_DECISION_IMPLEMENTATION.md" class="btn btn-outline-primary btn-block" target="_blank">View Doc</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-chart-line"></i> Optimization Report</h5>
                        <p class="card-text">Auction Consistency Optimization</p>
                        <a href="AUCTION_CONSISTENCY_OPTIMIZATION.md" class="btn btn-outline-primary btn-block" target="_blank">View Report</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card tool-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-question-circle"></i> Seller Guide</h5>
                        <p class="card-text">Guide for sellers on decision making</p>
                        <a href="SELLER_DECISION_GUIDE.md" class="btn btn-outline-primary btn-block" target="_blank">View Guide</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="card mb-5">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="fas fa-bolt"></i> Quick Actions</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <a href="index.php" class="btn btn-outline-dark btn-block mb-2">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="browse.php" class="btn btn-outline-dark btn-block mb-2">
                            <i class="fas fa-search"></i> Browse Auctions
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="create_auction.php" class="btn btn-outline-dark btn-block mb-2">
                            <i class="fas fa-plus"></i> Create Auction
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="notifications.php" class="btn btn-outline-dark btn-block mb-2">
                            <i class="fas fa-bell"></i> Notifications
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- System Status -->
        <?php
        require_once 'db_connection.php';
        
        // Quick stats
        $active_stmt = $pdo->query("SELECT COUNT(*) FROM Auction WHERE status = 'active'");
        $active_count = $active_stmt->fetchColumn();
        
        $ended_stmt = $pdo->query("SELECT COUNT(*) FROM Auction WHERE status = 'ended'");
        $ended_count = $ended_stmt->fetchColumn();
        
        $pending_stmt = $pdo->query("SELECT COUNT(*) FROM AuctionOutcome ao 
                                     WHERE ao.reserve_met = FALSE 
                                     AND ao.seller_accepted = FALSE 
                                     AND ao.winner_id IS NOT NULL 
                                     AND ao.acceptance_deadline > NOW()");
        $pending_count = $pending_stmt->fetchColumn();
        ?>
        
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle"></i> System Status</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-4">
                        <h3 class="text-success"><?php echo $active_count; ?></h3>
                        <p class="text-muted">Active Auctions</p>
                    </div>
                    <div class="col-md-4">
                        <h3 class="text-secondary"><?php echo $ended_count; ?></h3>
                        <p class="text-muted">Ended Auctions</p>
                    </div>
                    <div class="col-md-4">
                        <h3 class="text-warning"><?php echo $pending_count; ?></h3>
                        <p class="text-muted">Pending Decisions</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-4 mb-5">
            <p class="text-muted">
                <i class="fas fa-shield-alt"></i> All tools require appropriate permissions
            </p>
        </div>
    </div>
</body>
</html>
