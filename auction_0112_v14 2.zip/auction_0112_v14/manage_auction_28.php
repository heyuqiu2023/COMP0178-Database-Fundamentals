<?php
session_start();
require_once 'db_connection.php';
require_once 'auction_functions.php';

$auction_id = 28;

// Handle form submission to close auction
if (isset($_POST['close_auction'])) {
    try {
        $pdo->beginTransaction();
        
        // Get full auction data
        $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
        $stmt->execute([$auction_id]);
        $auction_data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($auction_data && $auction_data['status'] === 'active') {
            closeAuction($pdo, $auction_data);
            $pdo->commit();
            $success_msg = "✓ Auction #$auction_id closed successfully!";
        } else {
            $pdo->rollBack();
            $error_msg = "Auction is already closed or not found.";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error_msg = "Error: " . $e->getMessage();
    }
}

// Get current auction status
$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.reserve_price, a.seller_id, a.end_time,
                     ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline,
                     u.username AS winner_name
                     FROM Auction a 
                     LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                     LEFT JOIN User u ON ao.winner_id = u.user_id
                     WHERE a.auction_id = $auction_id");
$auction = $stmt->fetch(PDO::FETCH_ASSOC);

// Get bids
$bid_stmt = $pdo->prepare("SELECT b.bid_id, b.bidder_id, b.bid_amount, b.bid_time, b.is_active, u.username 
                           FROM Bid b 
                           JOIN User u ON b.bidder_id = u.user_id 
                           WHERE b.auction_id = ? 
                           ORDER BY b.bid_amount DESC, b.bid_time ASC");
$bid_stmt->execute([$auction_id]);
$bids = $bid_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Auction #<?php echo $auction_id; ?> Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<div class="container mt-4">
    <h2>Auction #<?php echo $auction_id; ?> Management</h2>
    
    <?php if (isset($success_msg)): ?>
        <div class="alert alert-success"><?php echo $success_msg; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_msg)): ?>
        <div class="alert alert-danger"><?php echo $error_msg; ?></div>
    <?php endif; ?>
    
    <?php if ($auction): ?>
        <div class="card mb-3">
            <div class="card-header">
                <strong>Auction Details</strong>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr><th>Title</th><td><?php echo htmlspecialchars($auction['title']); ?></td></tr>
                    <tr><th>Status</th><td><span class="badge badge-<?php echo $auction['status'] === 'active' ? 'success' : 'secondary'; ?>"><?php echo strtoupper($auction['status']); ?></span></td></tr>
                    <tr><th>Seller ID</th><td><?php echo $auction['seller_id']; ?></td></tr>
                    <tr><th>Reserve Price</th><td>£<?php echo number_format($auction['reserve_price'], 2); ?></td></tr>
                    <tr><th>End Time</th><td><?php echo $auction['end_time']; ?></td></tr>
                    <tr><th>Winner</th><td><?php echo $auction['winner_name'] ?? 'N/A'; ?> (ID: <?php echo $auction['winner_id'] ?? 'N/A'; ?>)</td></tr>
                    <tr><th>Final Price</th><td>£<?php echo number_format($auction['final_price'] ?? 0, 2); ?></td></tr>
                    <tr><th>Reserve Met</th><td><?php echo $auction['reserve_met'] ? '✓ Yes' : '✗ No'; ?></td></tr>
                    <tr><th>Seller Accepted</th><td><?php echo $auction['seller_accepted'] ? '✓ Yes' : '✗ No'; ?></td></tr>
                    <tr><th>Acceptance Deadline</th><td><?php echo $auction['acceptance_deadline'] ?? 'N/A'; ?></td></tr>
                </table>
                
                <?php 
                $end_time = new DateTime($auction['end_time']);
                $now = new DateTime();
                ?>
                
                <?php if ($auction['status'] === 'active' && $now >= $end_time): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> <strong>Action Required:</strong> This auction has ended but is still marked as active.
                    </div>
                    <form method="POST">
                        <button type="submit" name="close_auction" class="btn btn-warning btn-lg">
                            <i class="fas fa-lock"></i> Close Auction Now
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header">
                <strong>Bid History (<?php echo count($bids); ?> bids)</strong>
            </div>
            <div class="card-body">
                <?php if ($bids): ?>
                    <table class="table table-bordered table-sm">
                        <thead>
                            <tr>
                                <th>Bid ID</th>
                                <th>Bidder</th>
                                <th>Amount</th>
                                <th>Time</th>
                                <th>Is Active</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bids as $bid): ?>
                                <tr>
                                    <td><?php echo $bid['bid_id']; ?></td>
                                    <td><?php echo htmlspecialchars($bid['username']); ?> (ID: <?php echo $bid['bidder_id']; ?>)</td>
                                    <td>£<?php echo number_format($bid['bid_amount'], 2); ?></td>
                                    <td><?php echo $bid['bid_time']; ?></td>
                                    <td>
                                        <?php if ($bid['is_active']): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-muted">No bids placed on this auction.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="mb-3">
            <a href="listing.php?auction_id=<?php echo $auction_id; ?>" class="btn btn-primary">
                <i class="fas fa-eye"></i> View Listing Page
            </a>
            <a href="mylistings.php" class="btn btn-secondary">
                <i class="fas fa-list"></i> My Listings
            </a>
        </div>
        
    <?php else: ?>
        <div class="alert alert-danger">Auction #<?php echo $auction_id; ?> not found!</div>
    <?php endif; ?>
</div>
</body>
</html>
