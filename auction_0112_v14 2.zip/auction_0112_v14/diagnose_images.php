<!DOCTYPE html>
<html>
<head>
    <title>路径诊断</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: monospace; padding: 20px; background: #f5f5f5; }
        .info { background: white; padding: 15px; margin: 10px 0; border-left: 4px solid #007bff; }
        .success { border-left-color: #28a745; }
        .error { border-left-color: #dc3545; }
        code { background: #e9ecef; padding: 2px 6px; border-radius: 3px; }
    </style>
</head>
<body>
    <h1>🔍 图片路径诊断工具</h1>
    
    <div class="info">
        <h3>当前页面信息</h3>
        <p><strong>完整URL:</strong> <code><?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?></code></p>
        <p><strong>服务器名:</strong> <code><?php echo htmlspecialchars($_SERVER['SERVER_NAME']); ?></code></p>
        <p><strong>文档根目录:</strong> <code><?php echo htmlspecialchars($_SERVER['DOCUMENT_ROOT']); ?></code></p>
        <p><strong>当前脚本路径:</strong> <code><?php echo htmlspecialchars(__FILE__); ?></code></p>
        <p><strong>当前目录:</strong> <code><?php echo htmlspecialchars(__DIR__); ?></code></p>
    </div>
    
    <div class="info">
        <h3>图片目录检查</h3>
        <?php
        $img_dir = __DIR__ . '/img';
        $auctions_dir = $img_dir . '/auctions';
        $placeholder = $img_dir . '/placeholder.png';
        
        echo '<p><strong>img目录:</strong> ';
        if (is_dir($img_dir)) {
            echo '<span style="color:green">✓ 存在</span> <code>' . $img_dir . '</code>';
        } else {
            echo '<span style="color:red">✗ 不存在</span>';
        }
        echo '</p>';
        
        echo '<p><strong>img/auctions目录:</strong> ';
        if (is_dir($auctions_dir)) {
            echo '<span style="color:green">✓ 存在</span> <code>' . $auctions_dir . '</code>';
            $files = glob($auctions_dir . '/*');
            echo '<br>　文件数量: ' . count($files);
        } else {
            echo '<span style="color:red">✗ 不存在</span>';
        }
        echo '</p>';
        
        echo '<p><strong>占位符图片:</strong> ';
        if (file_exists($placeholder)) {
            echo '<span style="color:green">✓ 存在</span> ' . round(filesize($placeholder)/1024/1024, 2) . ' MB';
        } else {
            echo '<span style="color:red">✗ 不存在</span>';
        }
        echo '</p>';
        ?>
    </div>
    
    <div class="info">
        <h3>测试图片URL</h3>
        <?php
        $test_urls = [
            'img/placeholder.png',
            'img/auctions/70970d37cdb2f2ff_1764616408.jpg',
            '/auction_0112_v12/img/placeholder.png',
            '/auction_0112_v12/img/auctions/70970d37cdb2f2ff_1764616408.jpg'
        ];
        
        foreach ($test_urls as $url) {
            $full_path = __DIR__ . '/' . ltrim($url, '/auction_0112_v12/');
            $exists = file_exists($full_path);
            
            echo '<p>';
            echo '<strong>' . htmlspecialchars($url) . '</strong><br>';
            echo '　文件: ' . ($exists ? '<span style="color:green">✓ 存在</span>' : '<span style="color:red">✗ 不存在</span>');
            echo '<br>　<a href="' . htmlspecialchars($url) . '" target="_blank">点击测试访问</a>';
            echo '</p>';
        }
        ?>
    </div>
    
    <div class="info">
        <h3>数据库拍卖图片</h3>
        <?php
        require_once 'db_connection.php';
        $stmt = $pdo->query("SELECT auction_id, title, img_url FROM Auction WHERE img_url IS NOT NULL ORDER BY auction_id DESC LIMIT 5");
        
        while ($row = $stmt->fetch()) {
            echo '<p>';
            echo '<strong>拍卖 #' . $row['auction_id'] . ':</strong> ' . htmlspecialchars($row['title']) . '<br>';
            echo '　数据库路径: <code>' . htmlspecialchars($row['img_url']) . '</code><br>';
            
            $file_path = __DIR__ . '/' . $row['img_url'];
            if (file_exists($file_path)) {
                echo '　<span style="color:green">✓ 文件存在</span><br>';
                echo '　<a href="' . htmlspecialchars($row['img_url']) . '" target="_blank">点击查看</a>';
            } else {
                echo '　<span style="color:red">✗ 文件不存在: ' . $file_path . '</span>';
            }
            echo '</p>';
        }
        ?>
    </div>
    
    <div class="info">
        <h3>实际图片显示测试</h3>
        <p>占位符图片:</p>
        <img src="img/placeholder.png" style="max-width:200px; border:2px solid #ccc;" alt="占位符" 
             onload="this.style.borderColor='green'" 
             onerror="this.style.borderColor='red'; this.alt='加载失败'">
        
        <p>bike00 图片:</p>
        <img src="img/auctions/70970d37cdb2f2ff_1764616408.jpg" style="max-width:200px; border:2px solid #ccc;" alt="bike00"
             onload="this.style.borderColor='green'" 
             onerror="this.style.borderColor='red'; this.alt='加载失败'">
    </div>
    
    <div class="info">
        <h3>浏览器控制台日志</h3>
        <p>打开浏览器开发者工具（F12），查看 Console 标签中的日志输出。</p>
    </div>
    
    <script>
        console.log('=== 图片路径诊断 ===');
        console.log('当前URL:', window.location.href);
        console.log('Base URL:', window.location.origin);
        console.log('Pathname:', window.location.pathname);
        
        // 测试图片加载
        const testImages = [
            'img/placeholder.png',
            'img/auctions/70970d37cdb2f2ff_1764616408.jpg'
        ];
        
        testImages.forEach(src => {
            const img = new Image();
            img.onload = () => console.log('✓ 图片加载成功:', src);
            img.onerror = () => console.error('✗ 图片加载失败:', src);
            img.src = src;
        });
    </script>
</body>
</html>
