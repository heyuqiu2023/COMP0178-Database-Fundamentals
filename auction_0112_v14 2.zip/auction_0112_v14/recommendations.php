<?php include_once('header.php'); ?>
<?php require_once('db_connection.php'); ?>
<?php require_once('utilities.php'); ?>

<div class="container">
  <h2 class="my-4 text-center">Recommended for You</h2>

<?php
// 本页面根据买家的投标历史，提供个性化的拍卖品推荐（协同过滤算法）
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['account_type'] !== 'buyer') {
  echo '<div class="alert alert-warning">You must be logged in as a buyer to view recommendations.</div>';
} else {
  $user_id = $_SESSION['user_id'] ?? null;
  if (!$user_id) {
    echo '<div class="alert alert-warning">User not identified.</div>';
  } else {
    // 协同过滤推荐算法实现
    // 步骤1: 找到与当前用户有相似出价行为的其他用户（相似用户）
    // 步骤2: 找到这些相似用户当前正在出价的拍卖
    // 步骤3: 排除当前用户已经出价的拍卖
    // 步骤4: 按推荐分数排序
    
    $stmt = $pdo->prepare("
      SELECT 
        a.auction_id,
        a.title,
        a.description,
        a.img_url,
        a.category_id,
        a.end_time,
        COALESCE(MAX(b.bid_amount), a.starting_price) AS current_price,
        COUNT(DISTINCT b.bid_id) AS num_bids,
        COUNT(DISTINCT similar_bids.bidder_id) AS similarity_score
      FROM Auction a
      
      -- 找到相似用户正在出价的拍卖
      INNER JOIN Bid similar_bids ON similar_bids.auction_id = a.auction_id
      
      -- 相似用户是那些与当前用户出价过相同拍卖的用户
      INNER JOIN (
        SELECT DISTINCT b1.bidder_id AS similar_user_id
        FROM Bid b1
        WHERE b1.auction_id IN (
          -- 当前用户出价过的拍卖
          SELECT DISTINCT b2.auction_id
          FROM Bid b2
          WHERE b2.bidder_id = ?
        )
        AND b1.bidder_id != ?  -- 排除当前用户自己
        GROUP BY b1.bidder_id
        HAVING COUNT(DISTINCT b1.auction_id) >= 1  -- 至少有1个共同出价的拍卖
      ) similar_users ON similar_bids.bidder_id = similar_users.similar_user_id
      
      -- 左连接所有出价以获取当前价格和出价数
      LEFT JOIN Bid b ON b.auction_id = a.auction_id
      
      WHERE 
        -- 拍卖必须是活跃状态
        a.status = 'active'
        AND a.end_time > NOW()
        
        -- 排除当前用户已经出价的拍卖
        AND a.auction_id NOT IN (
          SELECT DISTINCT b3.auction_id
          FROM Bid b3
          WHERE b3.bidder_id = ?
        )
      
      GROUP BY 
        a.auction_id, a.title, a.description, a.img_url, 
        a.category_id, a.end_time, a.starting_price
      
      -- 按相似度分数（有多少相似用户出价）和结束时间排序
      ORDER BY similarity_score DESC, a.end_time ASC
      
      LIMIT 12
    ");
    
    $stmt->execute([$user_id, $user_id, $user_id]);
    $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($recommendations)) {
      // 如果没有基于协同过滤的推荐，显示一些热门拍卖
      echo '<div class="alert alert-info">';
      echo '<strong>No personalized recommendations yet.</strong><br>';
      echo 'Place some bids to receive recommendations based on similar buyers\' interests. Meanwhile, here are some popular auctions:';
      echo '</div>';
      
      // 显示热门拍卖（出价最多的活跃拍卖）
      $stmt = $pdo->prepare("
        SELECT 
          a.auction_id,
          a.title,
          a.description,
          a.img_url,
          a.category_id,
          a.end_time,
          COALESCE(MAX(b.bid_amount), a.starting_price) AS current_price,
          COUNT(DISTINCT b.bid_id) AS num_bids
        FROM Auction a
        LEFT JOIN Bid b ON b.auction_id = a.auction_id
        WHERE a.status = 'active'
          AND a.end_time > NOW()
          AND a.auction_id NOT IN (
            SELECT DISTINCT b2.auction_id
            FROM Bid b2
            WHERE b2.bidder_id = ?
          )
        GROUP BY a.auction_id, a.title, a.description, a.img_url, 
                 a.category_id, a.end_time, a.starting_price
        ORDER BY num_bids DESC, a.end_time ASC
        LIMIT 12
      ");
      $stmt->execute([$user_id]);
      $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if (empty($recommendations)) {
      echo '<p class="text-center">No active auctions available at this time.</p>';
    } else {
      // 获取用户时区
      $user_timezone = $_SESSION['timezone'] ?? 'Europe/London';
      $user_tz = new DateTimeZone($user_timezone);
      
      echo '<div class="row">';
      foreach ($recommendations as $item) {
        $end_time = new DateTime($item['end_time'], $user_tz);
        print_listing_card(
          (int)$item['auction_id'],
          $item['title'],
          $item['description'] ?? '',
          (float)$item['current_price'],
          (int)$item['num_bids'],
          $end_time,
          $item['img_url'],
          null,
          $item['category_id']
        );
      }
      echo '</div>';
    }
  }
}
?>
</div>

<?php include_once('footer.php'); ?>
