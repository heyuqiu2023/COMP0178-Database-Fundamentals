<?php
require_once 'db_connection.php';
require_once 'notify.php';

echo "=== Fixing Auction #20 (cloth) ===\n\n";

try {
    $pdo->beginTransaction();
    
    // Get auction data
    $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = 20 FOR UPDATE");
    $stmt->execute();
    $auction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auction) {
        throw new Exception("Auction not found");
    }
    
    echo "Found auction: {$auction['title']}\n";
    echo "Current status: {$auction['status']}\n";
    
    // Get highest bid
    $bid_stmt = $pdo->prepare("SELECT bid_id, bidder_id, bid_amount FROM Bid WHERE auction_id = ? AND is_active = TRUE ORDER BY bid_amount DESC, bid_time ASC LIMIT 1 FOR UPDATE");
    $bid_stmt->execute([20]);
    $winning_bid = $bid_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($winning_bid) {
        echo "Highest bid: £{$winning_bid['bid_amount']} by user #{$winning_bid['bidder_id']}\n";
        
        $winner_id = $winning_bid['bidder_id'];
        $final_price = $winning_bid['bid_amount'];
        $reserve_price = $auction['reserve_price'];
        
        // Check if reserve is met
        $reserve_met = ($final_price >= $reserve_price) ? 1 : 0;
        $seller_accepted = $reserve_met ? 1 : 0;
        
        echo "Reserve price: £{$reserve_price}\n";
        echo "Reserve met: " . ($reserve_met ? 'Yes' : 'No') . "\n";
        echo "Auto-accepted: " . ($seller_accepted ? 'Yes' : 'No') . "\n";
        
        // Update auction status
        $pdo->prepare("UPDATE Auction SET status = 'ended' WHERE auction_id = 20")->execute();
        echo "Updated auction status to 'ended'\n";
        
        // Update AuctionOutcome
        $accept_deadline = date('Y-m-d H:i:s', strtotime('+24 hours'));
        $update_stmt = $pdo->prepare(
            "UPDATE AuctionOutcome 
            SET winner_id = ?, 
                final_price = ?, 
                reserve_met = ?, 
                seller_accepted = ?,
                acceptance_deadline = ?,
                concluded_at = NOW(),
                seller_notified = 0,
                winner_notified = 0
            WHERE auction_id = 20"
        );
        $update_stmt->execute([
            $winner_id,
            $final_price,
            $reserve_met,
            $seller_accepted,
            $accept_deadline
        ]);
        
        echo "Updated AuctionOutcome successfully!\n";
        
        // Send notifications
        $seller_id = $auction['seller_id'];
        
        queue_notification($seller_id, 20, $winning_bid['bid_id'], 'auction_ended');
        queue_notification($winner_id, 20, $winning_bid['bid_id'], 'auction_ended');
        
        if ($reserve_met) {
            queue_notification($winner_id, 20, $winning_bid['bid_id'], 'winner_confirmed');
            echo "Sent 'winner confirmed' notification to winner\n";
        } else {
            queue_notification($seller_id, 20, $winning_bid['bid_id'], 'reserve_not_met');
            echo "Sent 'reserve not met' notification to seller\n";
        }
        
    } else {
        echo "No bids found for this auction\n";
    }
    
    $pdo->commit();
    echo "\n=== Successfully Fixed! ===\n";
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo "\nERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
}
?>
