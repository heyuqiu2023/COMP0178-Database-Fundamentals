<?php
/**
 * 创建测试通知数据，验证邮件队列隔离
 */

require_once 'db_connection.php';
require_once 'notify.php';

echo "=== 创建测试通知并验证隔离 ===\n\n";

// 为不同用户创建测试通知（使用实际存在的拍卖ID）
$test_data = [
    ['user_id' => 1, 'type' => 'new_bid', 'auction_id' => 22],
    ['user_id' => 2, 'type' => 'outbid', 'auction_id' => 22],
    ['user_id' => 3, 'type' => 'auction_ended', 'auction_id' => 21],
];

echo "1. 创建测试通知...\n";
foreach ($test_data as $data) {
    queue_notification(
        $data['user_id'],
        $data['auction_id'],
        null,
        $data['type'],
        null
    );
    echo "  ✓ 为用户 {$data['user_id']} 创建了 {$data['type']} 通知\n";
}
echo "\n";

echo "2. 验证每个用户的未发送邮件数量：\n";
$stmt = $pdo->query("
    SELECT 
        n.user_id,
        u.username,
        COUNT(*) as unsent_count
    FROM Notification n
    JOIN User u ON u.user_id = n.user_id
    WHERE n.email_sent = 0
    GROUP BY n.user_id, u.username
    ORDER BY n.user_id
");
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($results as $row) {
    echo "  - {$row['username']} (ID {$row['user_id']}): {$row['unsent_count']} 条未发送邮件\n";
}
echo "\n";

echo "3. 测试 process_email_queue 函数的隔离性：\n\n";

// 测试用户 1
echo "--- 处理用户 1 (Yuanjia) 的邮件队列 ---\n";
process_email_queue(1);
echo "\n";

// 验证用户 1 的邮件已标记为已发送
$stmt = $pdo->prepare("
    SELECT COUNT(*) as unsent 
    FROM Notification 
    WHERE user_id = 1 AND email_sent = 0
");
$stmt->execute();
$count = $stmt->fetch(PDO::FETCH_ASSOC)['unsent'];
echo "验证：用户 1 还有 {$count} 条未发送邮件\n\n";

// 测试用户 2
echo "--- 处理用户 2 (zhang) 的邮件队列 ---\n";
process_email_queue(2);
echo "\n";

// 验证用户 2 的邮件已标记为已发送
$stmt = $pdo->prepare("
    SELECT COUNT(*) as unsent 
    FROM Notification 
    WHERE user_id = 2 AND email_sent = 0
");
$stmt->execute();
$count = $stmt->fetch(PDO::FETCH_ASSOC)['unsent'];
echo "验证：用户 2 还有 {$count} 条未发送邮件\n\n";

// 验证用户 3 的邮件仍未发送
$stmt = $pdo->prepare("
    SELECT COUNT(*) as unsent 
    FROM Notification 
    WHERE user_id = 3 AND email_sent = 0
");
$stmt->execute();
$count = $stmt->fetch(PDO::FETCH_ASSOC)['unsent'];
echo "验证：用户 3 (ZYJ) 还有 {$count} 条未发送邮件（应该 > 0，因为没有处理）\n\n";

echo "=== 测试完成 ===\n";
echo "✅ 如果用户 3 的未发送邮件数 > 0，说明隔离成功！\n";
?>
