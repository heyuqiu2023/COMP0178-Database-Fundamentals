<?php
session_start();
require_once 'db_connection.php';

echo "<h2>Debug Session & Auction Info</h2>";

echo "<h3>Session Info:</h3>";
echo "<pre>";
echo "Logged in: " . (isset($_SESSION['logged_in']) ? 'Yes' : 'No') . "\n";
echo "User ID: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'N/A') . "\n";
echo "Username: " . (isset($_SESSION['username']) ? $_SESSION['username'] : 'N/A') . "\n";
echo "Account Type: " . (isset($_SESSION['account_type']) ? $_SESSION['account_type'] : 'N/A') . "\n";
echo "Is Seller: " . (isset($_SESSION['is_seller']) ? $_SESSION['is_seller'] : 'N/A') . "\n";
echo "</pre>";

$auction_id = 20;

// Get auction details
$stmt = $pdo->prepare("SELECT a.*, ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline
                       FROM Auction a
                       LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                       WHERE a.auction_id = ?");
$stmt->execute([$auction_id]);
$auction = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<h3>Auction #$auction_id Details:</h3>";
echo "<pre>";
print_r($auction);
echo "</pre>";

if ($auction) {
    $is_seller = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $auction['seller_id']);
    echo "<h3>Decision Logic:</h3>";
    echo "<ul>";
    echo "<li>Current user ID: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'N/A') . "</li>";
    echo "<li>Auction seller ID: " . $auction['seller_id'] . "</li>";
    echo "<li>Is current user the seller? " . ($is_seller ? 'YES' : 'NO') . "</li>";
    echo "<li>Auction status: " . $auction['status'] . "</li>";
    echo "<li>Reserve met: " . ($auction['reserve_met'] ? 'YES' : 'NO') . "</li>";
    echo "<li>Seller accepted: " . ($auction['seller_accepted'] ? 'YES' : 'NO') . "</li>";
    echo "<li>Winner ID: " . ($auction['winner_id'] ?? 'NULL') . "</li>";
    
    if ($auction['acceptance_deadline']) {
        $deadline = new DateTime($auction['acceptance_deadline']);
        $now = new DateTime();
        $deadline_passed = $now > $deadline;
        echo "<li>Acceptance deadline: " . $deadline->format('Y-m-d H:i:s') . "</li>";
        echo "<li>Current time: " . $now->format('Y-m-d H:i:s') . "</li>";
        echo "<li>Deadline passed: " . ($deadline_passed ? 'YES' : 'NO') . "</li>";
    }
    
    echo "</ul>";
    
    // Check if buttons should be shown
    $should_show_buttons = (
        $is_seller &&
        $auction['status'] === 'ended' &&
        !$auction['reserve_met'] &&
        !$auction['seller_accepted'] &&
        $auction['winner_id'] &&
        !$deadline_passed
    );
    
    echo "<h3>Should show decision buttons? " . ($should_show_buttons ? '<span style="color:green;">YES</span>' : '<span style="color:red;">NO</span>') . "</h3>";
}

echo "<p><a href='listing.php?auction_id=$auction_id'>Go to listing page</a></p>";
?>
