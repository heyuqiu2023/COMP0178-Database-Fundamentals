# Auction Outcome Implementation

## Overview
This document describes the implementation of the AuctionOutcome system that handles auction results, including cases where the highest bid is below the reserve price.

## Database Schema

### AuctionOutcome Table
```sql
CREATE TABLE `AuctionOutcome` (
    `outcome_id` INT AUTO_INCREMENT PRIMARY KEY,
    `auction_id` INT NOT NULL UNIQUE,
    `winner_id` INT NULL,
    `final_price` DECIMAL(10, 2) NULL,
    `reserve_met` BOOLEAN DEFAULT FALSE,
    `seller_accepted` BOOLEAN DEFAULT FALSE,
    `acceptance_deadline` DATETIME NOT NULL,
    `concluded_at` DATETIME NOT NULL,
    `seller_notified` BOOLEAN DEFAULT FALSE,
    `winner_notified` BOOLEAN DEFAULT FALSE
)
```

## Implementation Details

### 1. Auction Creation (`create_auction_result.php`)

When a new auction is created:
- Only the `Auction` record is created
- **No `AuctionOutcome` is created at this time**
- `AuctionOutcome` will be created automatically when the auction ends

### 2. Auction Closing (Only by Time)

**IMPORTANT:** Auctions only close when their `end_time` is reached, NOT when reserve price is met.

Closing triggers:
- **`cron_close_auctions.php`**: Scheduled task that closes auctions past their end_time
- **`place_bid.php`**: After a bid is placed, checks if end_time has passed and closes auction if needed

When an auction closes:
1. **Create `AuctionOutcome` record** with auction results
2. Find the highest bid for the auction
3. Compare with reserve price:
   - **Reserve Met** (`final_price >= reserve_price` or no reserve set):
     - Set `reserve_met = TRUE`
     - Set `seller_accepted = TRUE` (automatic acceptance)
     - Notify both seller and winner of successful auction
   - **Reserve Not Met** (`final_price < reserve_price`):
     - Set `reserve_met = FALSE`
     - Set `seller_accepted = FALSE` (requires manual decision)
     - Notify seller that reserve was not met and decision is required
     - Set 24-hour deadline for seller decision
4. Set `acceptance_deadline` to 24 hours from auction close
5. Set `concluded_at` to current timestamp

### 3. Seller Decision (`accept_bid.php`)

For auctions where reserve price was not met:

#### Seller Accepts Bid:
- Update `seller_accepted = TRUE`
- Notify winner that their bid was accepted
- Auction is considered successful

#### Seller Rejects Bid:
- Update `seller_accepted = FALSE`
- Set `winner_id = NULL` and `final_price = NULL`
- Notify bidder that their bid was rejected
- Auction is considered unsuccessful

### 4. Display Results (`listing.php`)

The auction detail page shows different messages based on outcome:

#### Case 1: Reserve Met
```
✓ Auction Successful!
The reserve price was met.
```

#### Case 2: Below Reserve - Seller Accepted
```
✓ Auction Successful!
The seller has accepted the final bid (below reserve price).
```

#### Case 3: Below Reserve - Pending Decision
```
⚠ Pending Seller Decision
The highest bid is below the reserve price.
The seller has until [deadline] to accept or reject this bid.
```

#### Case 4: Below Reserve - Rejected or Expired
```
✗ Auction Unsuccessful
The seller declined the final bid.
```

## User Workflows

### Buyer Workflow (Bid Below Reserve)
1. Place bid on auction
2. Auction ends, bid is highest but below reserve
3. See "Pending Seller Decision" message
4. Wait for seller to accept or reject
5. Receive notification of seller's decision

### Seller Workflow (Bid Below Reserve)
1. Auction ends with highest bid below reserve
2. See "Action Required" alert in My Listings
3. Review bid details:
   - Highest Bid: £X
   - Reserve Price: £Y
   - Time remaining to decide
4. Choose to Accept or Reject
5. System sends notifications to winner
6. Auction marked as successful or unsuccessful

## Files Modified/Created

### Modified Files:
1. `create_auction_result.php` - Added AuctionOutcome creation on auction creation
2. `cron_close_auctions.php` - Enhanced logic for reserve price handling
3. `mylistings.php` - Added pending decisions section
4. `listing.php` - Added detailed outcome display

### New Files:
1. `accept_bid.php` - Handles seller's accept/reject decision

## Business Rules

1. **Reserve Met**: Auction automatically successful, no seller action needed
2. **Reserve Not Met**: Seller has 48 hours to decide
3. **Acceptance Deadline**: If seller doesn't respond within 48 hours, bid is automatically rejected
4. **No Bids**: Auction marked as unsuccessful, no outcome processing needed
5. **Multiple Bids**: Only highest bid is considered for outcome

## Notifications

The system sends notifications for:
- `auction_ended` - To seller and highest bidder
- `reserve_not_met` - To seller when decision required
- `auction_successful` - When reserve is met
- `auction_won` - To winner when reserve is met
- `bid_accepted` - To winner when seller accepts below-reserve bid
- `bid_rejected` - To bidder when seller rejects bid

## Testing Scenarios

### Scenario 1: Reserve Price Met
1. Create auction with reserve price £100
2. Bid £120
3. Wait for auction to end (or run cron)
4. Verify: `reserve_met = TRUE`, `seller_accepted = TRUE`
5. Check listing page shows "Auction Successful"

### Scenario 2: Below Reserve - Seller Accepts
1. Create auction with reserve price £100
2. Bid £80
3. Wait for auction to end
4. Verify seller sees pending decision in My Listings
5. Seller clicks "Accept Bid"
6. Verify: `reserve_met = FALSE`, `seller_accepted = TRUE`
7. Check listing page shows "Auction Successful"

### Scenario 3: Below Reserve - Seller Rejects
1. Create auction with reserve price £100
2. Bid £80
3. Wait for auction to end
4. Seller clicks "Reject Bid"
5. Verify: `winner_id = NULL`, `final_price = NULL`
6. Check listing page shows "Auction Unsuccessful"

## Future Enhancements

1. Email notifications for all outcome events
2. Automatic rejection after deadline passes
3. Counter-offer functionality for sellers
4. Buyer confirmation of purchase intent
5. Payment integration
6. Dispute resolution system
