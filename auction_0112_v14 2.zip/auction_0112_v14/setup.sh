#!/bin/bash

# Auction Site Setup Script
# This script sets up the necessary directory permissions for the auction site

echo "=========================================="
echo "Auction Site Setup Script"
echo "=========================================="
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "Working directory: $SCRIPT_DIR"
echo ""

# Check if img directory exists
if [ ! -d "img" ]; then
    echo "❌ Error: img/ directory not found!"
    echo "   Please ensure you're running this script from the auction site root directory."
    exit 1
fi

echo "Setting up directory permissions..."
echo ""

# Create auctions directory if it doesn't exist
if [ ! -d "img/auctions" ]; then
    echo "📁 Creating img/auctions/ directory..."
    mkdir -p img/auctions
    if [ $? -eq 0 ]; then
        echo "✅ Directory created successfully"
    else
        echo "❌ Failed to create directory"
        exit 1
    fi
else
    echo "✅ img/auctions/ directory already exists"
fi

# Set permissions for img directory
echo ""
echo "🔧 Setting permissions for img/ directory..."
chmod 755 img/
if [ $? -eq 0 ]; then
    echo "✅ img/ permissions set to 755"
else
    echo "❌ Failed to set img/ permissions"
fi

# Set permissions for auctions directory
echo ""
echo "🔧 Setting permissions for img/auctions/ directory..."
chmod 777 img/auctions/
if [ $? -eq 0 ]; then
    echo "✅ img/auctions/ permissions set to 777 (writable for uploads)"
else
    echo "❌ Failed to set img/auctions/ permissions"
    echo "   You may need to run this script with sudo:"
    echo "   sudo ./setup.sh"
    exit 1
fi

# Verify permissions
echo ""
echo "📋 Verifying permissions..."
ls -ld img/ img/auctions/

echo ""
echo "=========================================="
echo "✅ Setup completed successfully!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Start XAMPP and ensure MySQL is running"
echo "2. Create database 'auction_db' in phpMyAdmin"
echo "3. Import 'CREATE TABLE User.sql' file"
echo "4. Open http://localhost/auction_0112_v12/ in your browser"
echo ""
echo "For detailed instructions, see INSTALLATION.md"
echo ""
