<?php include_once('header.php'); ?>
<?php require('utilities.php'); ?>

<style>
  .gap-3 > * {
    margin-right: 1rem;
  }
  .gap-3 > *:last-child {
    margin-right: 0;
  }
</style>

<div class="container">
  <h2 class="my-4 text-center">My Listings</h2>

<?php
// Display success/error messages
if (isset($_SESSION['success_message'])) {
  echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success_message']) . '</div>';
  unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
  echo '<div class="alert alert-danger">' . htmlspecialchars($_SESSION['error_message']) . '</div>';
  unset($_SESSION['error_message']);
}

// This page is for showing a user the auction listings they have created.  It
// will be similar to browse.php but without a search bar.  Once database
// integration is complete, replace the placeholder data with results
// retrieved from the auctions table where the seller_id matches the
// current user.

if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['account_type'] !== 'seller') {
  echo '<div class="alert alert-warning">You must be logged in as a seller to view your listings.</div>';
} else {
  $seller_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
  if (!$seller_id) {
    echo '<div class="alert alert-info">No listings to show for demo user. Log in as a seller to view your listings.</div>';
  } else {
    $db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'auction_system';
    $items = [];
    $pending_decisions = [];
    $mysqli = @new mysqli($db_host, $db_user, $db_pass, $db_name);
    if (!$mysqli->connect_errno) {
      // First, get auctions that need seller's decision (ended, below reserve, not yet accepted/rejected)
      $pending_sql = "SELECT a.auction_id, a.title, a.reserve_price, a.end_time, 
                      ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline, ao.winner_id,
                      u.username AS winner_name
                      FROM Auction a 
                      JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
                      LEFT JOIN `User` u ON ao.winner_id = u.user_id
                      WHERE a.seller_id = " . intval($seller_id) . " 
                      AND a.status = 'ended'
                      AND ao.reserve_met = FALSE
                      AND ao.seller_accepted = FALSE
                      AND ao.winner_id IS NOT NULL
                      AND ao.acceptance_deadline > NOW()
                      ORDER BY ao.acceptance_deadline ASC";
      $pending_res = $mysqli->query($pending_sql);
      if ($pending_res) {
        while ($r = $pending_res->fetch_assoc()) {
          $pending_decisions[] = $r;
        }
        $pending_res->free();
      }
      
      // Then get all listings
      $sql = "SELECT a.auction_id, a.title, a.description, a.end_time, a.img_url, a.category_id, u.username AS seller_name, " .
             "(SELECT COUNT(*) FROM Bid b WHERE b.auction_id = a.auction_id) AS bids, " .
             "(SELECT COALESCE(MAX(b.bid_amount), a.starting_price) FROM Bid b WHERE b.auction_id = a.auction_id) AS current_price " .
             "FROM Auction a JOIN `User` u ON a.seller_id = u.user_id WHERE a.seller_id = " . intval($seller_id) . " ORDER BY a.created_at DESC";
      $res = $mysqli->query($sql);
      if ($res) {
        while ($r = $res->fetch_assoc()) {
          $items[] = [
            'id' => $r['auction_id'],
            'title' => $r['title'],
            'desc' => $r['description'],
            'price' => $r['current_price'],
            'bids' => $r['bids'],
            'end_time' => new DateTime($r['end_time']),
            'img_url' => $r['img_url'],
            'seller_name' => $r['seller_name'],
            'category_id' => $r['category_id']
          ];
        }
        $res->free();
      }
      $mysqli->close();
    }
    
    // Display pending decisions first
    if (!empty($pending_decisions)) {
      echo '<div class="alert alert-warning border-warning" role="alert">';
      echo '<h4 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Action Required!</h4>';
      echo '<p class="mb-0">You have <strong>' . count($pending_decisions) . '</strong> auction(s) with bids below reserve price awaiting your decision.</p>';
      echo '</div>';
      
      echo '<h3 class="my-3"><i class="fas fa-gavel"></i> Pending Decisions</h3>';
      echo '<div class="mb-4">';
      foreach ($pending_decisions as $pd) {
        $deadline = new DateTime($pd['acceptance_deadline']);
        $now = new DateTime();
        $time_left = $now->diff($deadline);
        $hours_left = ($time_left->days * 24) + $time_left->h;
        
        echo '<div class="card border-warning mb-3">';
        echo '<div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">';
        echo '<h5 class="mb-0"><i class="fas fa-stopwatch"></i> ' . htmlspecialchars($pd['title']) . '</h5>';
        echo '<span class="badge badge-danger badge-pill">Expires in ' . $hours_left . ' hours</span>';
        echo '</div>';
        echo '<div class="card-body">';
        
        echo '<div class="row mb-3">';
        echo '<div class="col-md-6">';
        echo '<p class="mb-1"><strong><i class="fas fa-user"></i> Winner:</strong> ' . htmlspecialchars($pd['winner_name']) . '</p>';
        echo '<p class="mb-1"><strong><i class="fas fa-pound-sign"></i> Highest Bid:</strong> <span class="text-success">£' . number_format($pd['final_price'], 2) . '</span></p>';
        echo '</div>';
        echo '<div class="col-md-6">';
        echo '<p class="mb-1"><strong><i class="fas fa-shield-alt"></i> Reserve Price:</strong> <span class="text-danger">£' . number_format($pd['reserve_price'], 2) . '</span></p>';
        echo '<p class="mb-1"><strong><i class="fas fa-calendar-times"></i> Deadline:</strong> ' . $deadline->format('j M Y H:i') . '</p>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="alert alert-light border-warning mb-3">';
        echo '<i class="fas fa-info-circle"></i> The highest bid is <strong>£' . number_format($pd['reserve_price'] - $pd['final_price'], 2) . '</strong> below your reserve price. ';
        echo 'You can accept this bid and complete the sale, or reject it and mark the auction as unsuccessful.';
        echo '</div>';
        
        echo '<div class="d-flex justify-content-center gap-3">';
        echo '<a href="accept_bid.php?auction_id=' . $pd['auction_id'] . '&action=accept" ';
        echo 'class="btn btn-success btn-lg mr-3" ';
        echo 'onclick="return confirm(\'Accept bid of £' . number_format($pd['final_price'], 2) . '?\\n\\nBy accepting, you agree to sell this item to ' . htmlspecialchars($pd['winner_name']) . '. The buyer will be notified immediately.\');">';
        echo '<i class="fas fa-check-circle"></i> Accept Bid (£' . number_format($pd['final_price'], 2) . ')';
        echo '</a>';
        
        echo '<a href="accept_bid.php?auction_id=' . $pd['auction_id'] . '&action=reject" ';
        echo 'class="btn btn-danger btn-lg" ';
        echo 'onclick="return confirm(\'Reject this bid?\\n\\nThe auction will be marked as unsuccessful and ' . htmlspecialchars($pd['winner_name']) . ' will be notified that their bid was not accepted.\');">';
        echo '<i class="fas fa-times-circle"></i> Reject Bid';
        echo '</a>';
        echo '</div>';
        
        echo '</div>'; // card-body
        echo '</div>'; // card
      }
      echo '</div>';
    }

    if (empty($items)) {
      echo '<p>You have not created any listings yet.</p>';
    } else {
      echo '<div class="row">';
      foreach ($items as $item) {
        print_listing_card($item['id'], $item['title'], $item['desc'], $item['price'], $item['bids'], $item['end_time'], isset($item['img_url']) ? $item['img_url'] : null, isset($item['seller_name']) ? $item['seller_name'] : null, isset($item['category_id']) ? $item['category_id'] : null);
      }
      echo '</div>';
    }
  }
}
?>

</div>

<?php include_once('footer.php'); ?>