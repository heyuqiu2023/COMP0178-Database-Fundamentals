<?php
/**
 * Cron job: 处理超过决策期限的 AuctionOutcome
 * 当卖家在24小时内没有对低于保留价的出价做出决定时，自动拒绝该出价
 * 
 * 运行频率：建议每小时运行一次
 * Crontab: 0 * * * * /path/to/php /path/to/cron_expire_decisions.php
 */

require_once 'db_connection.php';
require_once 'notify.php';

// Log start time
$log_message = "[" . date('Y-m-d H:i:s') . "] Cron: Starting decision expiration check\n";

try {
    $pdo->beginTransaction();
    
    // Find all outcomes where:
    // 1. reserve_met = FALSE (below reserve price)
    // 2. seller_accepted = FALSE (not yet accepted)
    // 3. winner_id IS NOT NULL (there is a bidder)
    // 4. acceptance_deadline <= NOW() (deadline has passed)
    // 5. seller_notified = FALSE (haven't processed this expiration yet)
    
    $stmt = $pdo->query("
        SELECT ao.*, a.title, a.seller_id 
        FROM AuctionOutcome ao
        JOIN Auction a ON a.auction_id = ao.auction_id
        WHERE ao.reserve_met = FALSE
          AND ao.seller_accepted = FALSE
          AND ao.winner_id IS NOT NULL
          AND ao.acceptance_deadline <= NOW()
          AND ao.seller_notified = FALSE
        FOR UPDATE
    ");
    
    $expired_outcomes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count = count($expired_outcomes);
    
    $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Found $count expired decision(s)\n";
    
    foreach ($expired_outcomes as $outcome) {
        try {
            $auction_id = $outcome['auction_id'];
            $winner_id = $outcome['winner_id'];
            $seller_id = $outcome['seller_id'];
            $title = $outcome['title'];
            
            $log_message .= "[" . date('Y-m-d H:i:s') . "] Processing auction #$auction_id: $title\n";
            
            // Update AuctionOutcome: 
            // - Set seller_accepted = FALSE (explicit rejection due to timeout)
            // - Set winner_id = NULL (no winner because seller didn't accept)
            // - Set final_price = NULL (no sale)
            // - Set seller_notified = TRUE (mark as processed)
            $update_stmt = $pdo->prepare("
                UPDATE AuctionOutcome 
                SET seller_accepted = FALSE,
                    winner_id = NULL,
                    final_price = NULL,
                    seller_notified = TRUE
                WHERE auction_id = ?
            ");
            $update_stmt->execute([$auction_id]);
            
            // Update all bids for this auction to is_active = FALSE (auction failed due to timeout)
            $bid_update_stmt = $pdo->prepare("UPDATE Bid SET is_active = FALSE WHERE auction_id = ?");
            $bid_update_stmt->execute([$auction_id]);
            
            // Notify seller that the decision deadline expired
            queue_notification(
                $seller_id, 
                $auction_id, 
                null, 
                'decision_expired',
                "Your decision deadline for auction '$title' has expired. The auction has been cancelled."
            );
            
            // Notify the bidder that their bid was not accepted due to timeout
            queue_notification(
                $winner_id, 
                $auction_id, 
                null, 
                'bid_rejected',
                "The seller did not accept your bid for '$title' within the deadline. The auction has been cancelled."
            );
            
            $log_message .= "[" . date('Y-m-d H:i:s') . "] ✓ Expired auction #$auction_id: Seller didn't respond, bid rejected\n";
            
        } catch (Exception $e) {
            $log_message .= "[" . date('Y-m-d H:i:s') . "] ✗ Error processing auction #$auction_id: {$e->getMessage()}\n";
            throw $e; // Re-throw to rollback entire transaction
        }
    }
    
    $pdo->commit();
    $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Transaction committed successfully\n";
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: ERROR - {$e->getMessage()}\n";
    $log_message .= "[" . date('Y-m-d H:i:s') . "] Cron: Stack trace:\n{$e->getTraceAsString()}\n";
}

// Write log to file
$log_file = __DIR__ . '/logs/cron_expire_decisions.log';
$log_dir = dirname($log_file);
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0777, true);
}
file_put_contents($log_file, $log_message, FILE_APPEND);

// Also output to console for manual runs
echo $log_message;
?>
