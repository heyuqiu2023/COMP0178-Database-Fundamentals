<?php
/**
 * 维护脚本：检查并修复卡住的拍卖
 * 查找所有状态为 active 但已经过期的拍卖，并尝试关闭它们
 */

require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "=== Stuck Auction Maintenance Check ===\n";
echo "Time: " . date('Y-m-d H:i:s') . "\n\n";

try {
    // 查找所有状态为 active 但已经过期的拍卖
    $stmt = $pdo->query("
        SELECT a.*, 
               TIMESTAMPDIFF(MINUTE, a.end_time, NOW()) as minutes_overdue,
               (SELECT COUNT(*) FROM Bid WHERE auction_id = a.auction_id) as bid_count,
               (SELECT MAX(bid_amount) FROM Bid WHERE auction_id = a.auction_id) as highest_bid
        FROM Auction a
        WHERE a.status = 'active' AND a.end_time <= NOW()
        ORDER BY a.end_time ASC
    ");
    
    $stuck_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($stuck_auctions) === 0) {
        echo "✅ No stuck auctions found. All good!\n";
        exit(0);
    }
    
    echo "⚠️ Found " . count($stuck_auctions) . " stuck auction(s):\n\n";
    
    $fixed_count = 0;
    $error_count = 0;
    
    foreach ($stuck_auctions as $auction) {
        echo "----------------------------------------\n";
        echo "Auction #{$auction['auction_id']}: {$auction['title']}\n";
        echo "  Status: {$auction['status']}\n";
        echo "  End time: {$auction['end_time']}\n";
        echo "  Overdue by: {$auction['minutes_overdue']} minutes\n";
        echo "  Bids: {$auction['bid_count']}\n";
        echo "  Highest bid: £" . ($auction['highest_bid'] ?? '0.00') . "\n";
        
        // 尝试关闭这个拍卖
        try {
            $pdo->beginTransaction();
            
            closeAuction($pdo, $auction);
            
            $pdo->commit();
            
            echo "  ✅ Successfully closed\n";
            $fixed_count++;
            
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            echo "  ❌ Error: " . $e->getMessage() . "\n";
            $error_count++;
        }
        
        echo "\n";
    }
    
    echo "========================================\n";
    echo "Summary:\n";
    echo "  Total stuck: " . count($stuck_auctions) . "\n";
    echo "  Fixed: $fixed_count\n";
    echo "  Errors: $error_count\n";
    
    if ($fixed_count > 0) {
        echo "\n✅ Maintenance completed successfully!\n";
    } else if ($error_count > 0) {
        echo "\n⚠️ Some auctions could not be closed. Check errors above.\n";
    }
    
} catch (Exception $e) {
    echo "\n❌ Fatal error: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
?>
