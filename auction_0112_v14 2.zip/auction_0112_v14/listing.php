<?php
/**
 * 拍卖详情页面 (供买家查看并出价，卖家查看拍品情况)
 * - 使用 PDO 预编译查询拍卖详情和出价。
 * - 显示拍卖信息、卖家信息、当前价格及剩余时间。
 * - 登录用户可加入关注列表；只有买家才能出价。
 */

include_once('header.php');
require('utilities.php');
require_once 'db_connection.php';

// ⚠️ header.php 里已经 session_start() 了，这里就不要再调一次
// 如果你不确定，可以写成下面这样防止重复启动：
// if (session_status() === PHP_SESSION_NONE) {
//     session_start();
// }

// 获取拍卖ID
$auction_id = isset($_GET['auction_id']) ? intval($_GET['auction_id']) : 0;
if ($auction_id <= 0) {
    echo '<div class="container"><div class="alert alert-warning mt-5">Invalid auction ID.</div></div>';
    include_once('footer.php');
    exit;
}

// 查询拍卖信息及卖家、类别信息
$stmt = $pdo->prepare(
    "SELECT a.*, u.username AS seller_name, u.email AS seller_email, c.category_name
     FROM Auction a
       JOIN User u ON u.user_id = a.seller_id
       LEFT JOIN Category c ON c.category_id = a.category_id
     WHERE a.auction_id = ?"
);
$stmt->execute([$auction_id]);
$auction = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$auction) {
    echo '<div class="container"><div class="alert alert-warning mt-5">Auction not found.</div></div>';
    include_once('footer.php');
    exit;
}

// 读取拍卖字段
$title         = $auction['title'] ?? '';
$description   = $auction['description'] ?? '';
$start_price   = (float)($auction['starting_price'] ?? 0);
$reserve_price = (float)($auction['reserve_price'] ?? 0);
$picture       = $auction['img_url'] ?? '';
$seller_name   = $auction['seller_name'] ?? '';
$seller_email  = $auction['seller_email'] ?? '';
$status        = $auction['status'] ?? 'active'; // 'active', 'ended', 'cancelled'

// 结束时间与当前时间比较判断是否还在进行
// 获取用户时区（默认伦敦时区）
$user_timezone = $_SESSION['timezone'] ?? 'Europe/London';
$user_tz = new DateTimeZone($user_timezone);

$end_time = new DateTime($auction['end_time'], $user_tz);
$now      = new DateTime('now', $user_tz);

// ⚠️ 自动关闭已过期但状态还是 active 的拍卖（防止卡住）
if ($status === 'active' && $now >= $end_time) {
    require_once 'auction_functions.php';
    try {
        $pdo->beginTransaction();
        $close_success = closeAuction($pdo, $auction);
        $pdo->commit();
        
        if ($close_success) {
            // 重新获取拍卖状态和信息
            $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
            $stmt->execute([$auction_id]);
            $auction = $stmt->fetch(PDO::FETCH_ASSOC);
            $status = $auction['status'] ?? 'ended';
            
            // 验证 AuctionOutcome 已创建
            $verify = $pdo->prepare("SELECT COUNT(*) FROM AuctionOutcome WHERE auction_id = ?");
            $verify->execute([$auction_id]);
            if ($verify->fetchColumn() === 0) {
                error_log("WARNING: Auction $auction_id closed but AuctionOutcome not found!");
            }
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // 如果关闭失败，记录错误但不影响页面显示
        error_log("Failed to auto-close auction $auction_id: " . $e->getMessage());
    }
}

// ⚠️ 额外检查：如果拍卖状态是 ended 但缺少 AuctionOutcome，自动创建
if ($status === 'ended') {
    require_once 'sync_outcomes.php';
    ensureAuctionOutcome($pdo, $auction_id);
}

$is_active = ($status === 'active') && ($now < $end_time);

// 查询最高出价与出价总数
$stmt = $pdo->prepare("SELECT bid_amount FROM Bid WHERE auction_id = ? ORDER BY bid_amount DESC, bid_time ASC LIMIT 1");
$stmt->execute([$auction_id]);
$highest_bid = $stmt->fetch(PDO::FETCH_ASSOC);
$current_price = $highest_bid ? (float)$highest_bid['bid_amount'] : $start_price;

$stmt = $pdo->prepare("SELECT COUNT(*) FROM Bid WHERE auction_id = ?");
$stmt->execute([$auction_id]);
$num_bids = (int)$stmt->fetchColumn();

// 计算剩余时间
$time_remaining = '';
if ($is_active) {
    $interval = date_diff($now, $end_time);
    $time_remaining = display_time_remaining($interval);
}

// 判断当前用户是否在关注此拍品
$has_session = isset($_SESSION['user_id']);
$watching    = false;
if ($has_session) {
    $watch_stmt = $pdo->prepare("SELECT 1 FROM Watchlist WHERE user_id = ? AND auction_id = ?");
    $watch_stmt->execute([$_SESSION['user_id'], $auction_id]);
    $watching = (bool)$watch_stmt->fetchColumn();
}

// Note: Auction closing and outcome determination is handled by cron_close_auctions.php
// when the auction end_time is reached, not by individual page views

?>
<div class="container mt-5">
  <div class="row">
    <!-- 左侧：标题、卖家、描述及图片 -->
    <div class="col-md-8">
      <h2 class="mb-3"><?php echo htmlspecialchars($title); ?></h2>
      <p class="text-muted">
        Sold by <?php echo htmlspecialchars($seller_email ?: $seller_name); ?>
      </p>
      <div class="mb-3">
        <?php echo nl2br(htmlspecialchars($description)); ?>
      </div>
      
      <?php 
      // 处理图片显示：支持单图和多图轮播
      if (!empty($picture)) {
          // 将图片URL按逗号分隔（支持多图）
          $image_urls = array_filter(array_map('trim', explode(',', $picture)));
          
          if (count($image_urls) > 1) {
              // 多图：使用轮播
              $carousel_id = 'listing_carousel_' . $auction_id;
              echo '<div id="' . $carousel_id . '" class="carousel slide mb-3" data-ride="carousel">';
              echo '<div class="carousel-inner">';
              
              $first = true;
              foreach ($image_urls as $img_url) {
                  $img_url = trim($img_url);
                  echo '<div class="carousel-item' . ($first ? ' active' : '') . '">';
                  echo '<img class="d-block w-100 img-fluid" src="' . htmlspecialchars($img_url) . '" ';
                  echo 'alt="' . htmlspecialchars($title) . '" ';
                  echo 'onerror="this.src=\'img/placeholder.png\';">';
                  echo '</div>';
                  $first = false;
              }
              
              echo '</div>';
              
              // 轮播控制按钮
              if (count($image_urls) > 1) {
                  echo '<a class="carousel-control-prev" href="#' . $carousel_id . '" role="button" data-slide="prev">';
                  echo '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
                  echo '<span class="sr-only">Previous</span>';
                  echo '</a>';
                  echo '<a class="carousel-control-next" href="#' . $carousel_id . '" role="button" data-slide="next">';
                  echo '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
                  echo '<span class="sr-only">Next</span>';
                  echo '</a>';
              }
              
              echo '</div>';
          } else {
              // 单图：直接显示
              $img_url = trim($image_urls[0]);
              echo '<img class="img-fluid mb-3" src="' . htmlspecialchars($img_url) . '" ';
              echo 'alt="' . htmlspecialchars($title) . '" ';
              echo 'onerror="this.src=\'img/placeholder.png\';">';
          }
      } else {
          // 没有图片：显示占位符
          echo '<img class="img-fluid mb-3" src="img/placeholder.png" ';
          echo 'alt="' . htmlspecialchars($title) . '">';
      }
      ?>
    </div>

    <!-- 右侧：关注列表、价格、剩余时间、出价 -->
    <div class="col-md-4">
      <?php if ($is_active): ?>
        <!-- 关注列表按钮：仅登录用户可见 -->
        <?php if ($has_session): ?>
          <div id="watch_nowatch" <?php if ($watching) echo 'style="display:none"'; ?>>
            <button type="button" class="btn btn-outline-secondary btn-sm mb-3"
                    onclick="addToWatchlist()">+ Add to watchlist</button>
          </div>
          <div id="watch_watching" <?php if (!$watching) echo 'style="display:none"'; ?>>
            <button type="button" class="btn btn-success btn-sm mb-1" disabled>Watching</button>
            <button type="button" class="btn btn-danger btn-sm mb-3"
                    onclick="removeFromWatchlist()">Remove watch</button>
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <p>Auction ends:
        <?php echo htmlspecialchars($end_time->format('j M Y H:i')); ?>
        <small class="text-muted">(<?php echo htmlspecialchars($user_timezone); ?>)</small>
        <?php if ($is_active): ?>
          (<?php echo htmlspecialchars($time_remaining); ?> left)
        <?php endif; ?>
      </p>
      <p class="lead">Current bid: £<?php echo number_format($current_price, 2); ?></p>
      <p>Number of bids: <?php echo $num_bids; ?></p>

      <?php if ($is_active): ?>
        <?php
        // 只有登录且角色为买家 (is_seller == 0) 才能出价
        $can_bid = false;
        if ($has_session && isset($_SESSION['is_seller'])) {
            $can_bid = ($_SESSION['is_seller'] == 0);
        }
        ?>
        <?php if ($can_bid): ?>
          <!-- 出价表单 -->
          <form method="POST" action="place_bid.php">
            <!-- 隐藏字段传递拍卖ID -->
            <input type="hidden" name="auction_id" value="<?php echo htmlspecialchars($auction_id); ?>">
            <div class="input-group mb-2">
              <div class="input-group-prepend"><span class="input-group-text">£</span></div>
              <!-- 出价金额的最小值是当前出价 -->
              <input type="number" step="0.01"
                     min="<?php echo htmlspecialchars($current_price); ?>"
                     name="bid" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Place bid</button>
          </form>
        <?php else: ?>
          <p class="text-muted">Only buyers can place bids. Please log in as a buyer to bid.</p>
        <?php endif; ?>
      <?php else: ?>
        <div class="alert alert-secondary">
          <strong>This auction has ended.</strong>
        </div>
        <?php
        // Get auction outcome information
        $outcome_stmt = $pdo->prepare("SELECT ao.*, u.username AS winner_name 
                                        FROM AuctionOutcome ao 
                                        LEFT JOIN User u ON ao.winner_id = u.user_id 
                                        WHERE ao.auction_id = ?");
        $outcome_stmt->execute([$auction_id]);
        $outcome = $outcome_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($outcome):
          $is_seller = ($has_session && isset($_SESSION['user_id']) && $_SESSION['user_id'] == $auction['seller_id']);
          $is_winner = ($has_session && isset($_SESSION['user_id']) && $outcome['winner_id'] && $_SESSION['user_id'] == $outcome['winner_id']);
        ?>
          
          <?php if ($outcome['winner_id']): ?>
            <!-- There was a winner -->
            <div class="card mb-3">
              <div class="card-header">
                <strong>Auction Result</strong>
              </div>
              <div class="card-body">
                <p><strong>Final Price:</strong> £<?php echo number_format($outcome['final_price'], 2); ?></p>
                <p><strong>Number of Bids:</strong> <?php echo $num_bids; ?></p>
                
                <?php if ($outcome['reserve_met']): ?>
                  <!-- Reserve price was met - automatic success -->
                  <div class="alert alert-success mb-2">
                    <i class="fas fa-check-circle"></i> <strong>Auction Successful!</strong><br>
                    The reserve price was met.
                  </div>
                  <?php if ($is_seller): ?>
                    <p class="text-muted">Winner: <?php echo htmlspecialchars($outcome['winner_name']); ?></p>
                    <p class="small text-muted">The winning bidder will be notified to arrange payment and collection.</p>
                  <?php elseif ($is_winner): ?>
                    <p class="text-success"><strong>Congratulations! You won this auction.</strong></p>
                    <p class="small text-muted">Please contact the seller to arrange payment and collection.</p>
                  <?php endif; ?>
                  
                <?php else: ?>
                  <!-- Reserve price NOT met - seller decision pending or made -->
                  <?php if ($outcome['seller_accepted']): ?>
                    <!-- Seller accepted the bid below reserve -->
                    <div class="alert alert-success mb-2">
                      <i class="fas fa-check-circle"></i> <strong>Auction Successful!</strong><br>
                      The seller has accepted the final bid (below reserve price).
                    </div>
                    <?php if ($is_seller): ?>
                      <p class="text-muted">Winner: <?php echo htmlspecialchars($outcome['winner_name']); ?></p>
                      <p class="small text-muted">You accepted this bid. Please contact the buyer to arrange payment and collection.</p>
                    <?php elseif ($is_winner): ?>
                      <p class="text-success"><strong>Congratulations! The seller accepted your bid.</strong></p>
                      <p class="small text-muted">Please contact the seller to arrange payment and collection.</p>
                    <?php endif; ?>
                    
                  <?php else: ?>
                    <!-- Seller has not accepted yet or rejected -->
                    <?php 
                    $deadline = new DateTime($outcome['acceptance_deadline']);
                    $deadline_passed = (new DateTime()) > $deadline;
                    ?>
                    
                    <?php if (!$deadline_passed && $outcome['winner_id']): ?>
                      <!-- Still waiting for seller decision -->
                      <div class="alert alert-warning mb-2">
                        <i class="fas fa-exclamation-triangle"></i> <strong>Pending Seller Decision</strong><br>
                        The highest bid (£<?php echo number_format($outcome['final_price'], 2); ?>) is below the reserve price 
                        (£<?php echo number_format($reserve_price, 2); ?>).<br>
                        The seller has until <?php echo $deadline->format('j M Y H:i'); ?> to accept or reject this bid.
                      </div>
                      <?php if ($is_seller): ?>
                        <!-- Seller action buttons -->
                        <div class="card border-warning mb-3">
                          <div class="card-header bg-warning text-dark">
                            <strong><i class="fas fa-hand-pointer"></i> Action Required</strong>
                          </div>
                          <div class="card-body">
                            <p class="mb-2"><strong>Winner:</strong> <?php echo htmlspecialchars($outcome['winner_name']); ?></p>
                            <p class="mb-2"><strong>Final Bid:</strong> £<?php echo number_format($outcome['final_price'], 2); ?></p>
                            <p class="mb-3"><strong>Your Reserve Price:</strong> £<?php echo number_format($reserve_price, 2); ?></p>
                            <p class="text-muted small mb-3">
                              The highest bid is below your reserve price. You can choose to accept this bid or reject it.
                              If you reject it, the auction will be marked as unsuccessful.
                            </p>
                            <div class="text-center mb-3">
                              <a href="accept_bid.php?auction_id=<?php echo $auction_id; ?>&action=accept" 
                                 class="btn btn-success btn-lg" 
                                 style="margin-right: 10px;"
                                 onclick="return confirm('Are you sure you want to ACCEPT this bid of £<?php echo number_format($outcome['final_price'], 2); ?>?\n\nThe buyer will be notified and you will be expected to complete the sale.');">
                                <i class="fas fa-check"></i> Accept Bid
                              </a>
                              <a href="accept_bid.php?auction_id=<?php echo $auction_id; ?>&action=reject" 
                                 class="btn btn-danger btn-lg" 
                                 onclick="return confirm('Are you sure you want to REJECT this bid?\n\nThe auction will be marked as unsuccessful and the bidder will be notified.');">
                                <i class="fas fa-times"></i> Reject Bid
                              </a>
                            </div>
                            <p class="text-muted small mt-3 mb-0">
                              <i class="fas fa-clock"></i> Decision deadline: <?php echo $deadline->format('j M Y H:i'); ?>
                            </p>
                          </div>
                        </div>
                      <?php elseif ($is_winner): ?>
                        <p class="small text-muted">Your bid is the highest, but it's below the reserve price. The seller will decide whether to accept it.</p>
                      <?php endif; ?>
                      
                    <?php else: ?>
                      <!-- Deadline passed or seller rejected -->
                      <div class="alert alert-danger mb-2">
                        <i class="fas fa-times-circle"></i> <strong>Auction Unsuccessful</strong><br>
                        <?php if ($deadline_passed): ?>
                          The seller did not accept the final bid before the deadline.
                        <?php else: ?>
                          The seller declined the final bid.
                        <?php endif; ?>
                      </div>
                    <?php endif; ?>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
            
          <?php else: ?>
            <!-- No bids received -->
            <div class="alert alert-warning">
              <i class="fas fa-info-circle"></i> No bids were received for this auction.
            </div>
          <?php endif; ?>
          
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- 关注列表的 AJAX 调用 -->
<script>
function addToWatchlist() {
  $.ajax('watchlist_funcs.php', {
    type: 'POST',
    data: {
      functionname: 'add_to_watchlist',
      // ✅ 按照课程模板的写法，参数放在 arguments 数组里
      arguments: [<?php echo (int)$auction_id; ?>]
    },
    success: function(res) {
      if (res.trim() === 'success') {
        $('#watch_nowatch').hide();
        $('#watch_watching').show();
      }
    }
  });
}
function removeFromWatchlist() {
  $.ajax('watchlist_funcs.php', {
    type: 'POST',
    data: {
      functionname: 'remove_from_watchlist',
      arguments: [<?php echo (int)$auction_id; ?>]
    },
    success: function(res) {
      if (res.trim() === 'success') {
        $('#watch_watching').hide();
        $('#watch_nowatch').show();
      }
    }
  });
}
</script>

<?php include_once('footer.php'); ?>
