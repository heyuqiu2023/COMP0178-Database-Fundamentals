<!DOCTYPE html>
<html>
<head>
    <title>Listing 图片显示测试</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .test-card { margin: 20px 0; padding: 15px; border: 1px solid #ddd; }
        .test-image { max-width: 400px; margin: 10px 0; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container my-4">
        <h1>Listing.php 图片显示测试</h1>
        
        <?php
        require_once 'db_connection.php';
        
        // 测试几个不同的拍卖
        $test_auctions = [25, 26, 27, 28]; // bike, bike00, bike007, bike100
        
        foreach ($test_auctions as $auction_id) {
            $stmt = $pdo->prepare("SELECT * FROM Auction WHERE auction_id = ?");
            $stmt->execute([$auction_id]);
            $auction = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$auction) continue;
            
            echo '<div class="test-card">';
            echo '<h3>拍卖 #' . $auction_id . ': ' . htmlspecialchars($auction['title']) . '</h3>';
            
            $picture = $auction['img_url'] ?? '';
            
            if (empty($picture)) {
                echo '<p class="error">❌ 数据库中没有图片URL</p>';
                echo '<p>应该显示占位符：<code>img/placeholder.png</code></p>';
                $img_src = 'img/placeholder.png';
            } else {
                echo '<p class="success">✓ 图片URL: ' . htmlspecialchars($picture) . '</p>';
                
                $file_path = __DIR__ . '/' . $picture;
                if (file_exists($file_path)) {
                    echo '<p class="success">✓ 文件存在: ' . round(filesize($file_path) / 1024, 2) . ' KB</p>';
                } else {
                    echo '<p class="error">❌ 文件不存在: ' . $file_path . '</p>';
                }
                
                $img_src = htmlspecialchars($picture);
            }
            
            // 显示图片
            echo '<div class="test-image">';
            echo '<img src="' . $img_src . '" class="img-fluid border" ';
            echo 'alt="' . htmlspecialchars($auction['title']) . '" ';
            echo 'onerror="this.src=\'img/placeholder.png\'; this.style.border=\'2px solid red\';">';
            echo '</div>';
            
            // 提供链接到实际页面
            echo '<p><a href="listing.php?auction_id=' . $auction_id . '" class="btn btn-sm btn-primary" target="_blank">查看实际页面</a></p>';
            
            echo '</div>';
        }
        ?>
        
        <hr>
        <h2>浏览器控制台检查</h2>
        <p>如果图片仍然不显示，请：</p>
        <ol>
            <li>打开浏览器开发者工具（F12）</li>
            <li>切换到 "Network" 标签</li>
            <li>刷新页面</li>
            <li>查找图片请求，检查返回的 HTTP 状态码：
                <ul>
                    <li><strong>200</strong> = 成功加载</li>
                    <li><strong>404</strong> = 文件未找到</li>
                    <li><strong>403</strong> = 权限拒绝</li>
                </ul>
            </li>
        </ol>
        
        <hr>
        <h2>直接访问测试</h2>
        <p>尝试直接在浏览器中访问这些URL：</p>
        <ul>
            <li><a href="img/placeholder.png" target="_blank">img/placeholder.png</a></li>
            <li><a href="img/auctions/70970d37cdb2f2ff_1764616408.jpg" target="_blank">img/auctions/70970d37cdb2f2ff_1764616408.jpg</a> (bike00)</li>
            <li><a href="img/auctions/8207ad161237b41e_1764618800.jpg" target="_blank">img/auctions/8207ad161237b41e_1764618800.jpg</a> (bike007)</li>
        </ul>
    </div>
</body>
</html>
