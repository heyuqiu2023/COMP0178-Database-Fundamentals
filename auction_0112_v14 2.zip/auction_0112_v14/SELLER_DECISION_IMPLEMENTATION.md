# 卖家决策功能实现总结

## 功能概述

当拍卖结束时，如果最高出价低于保留价，系统会给卖家 24 小时的时间来决定是否接受该出价。

## 实现的功能

### 1. 自动关闭拍卖
- **位置**: `auction_functions.php` - `closeAuction()` 函数
- **触发**: 
  - `cron_close_auctions.php` (定时任务)
  - `listing.php` 页面访问时自动检查
- **行为**:
  - 更新 Auction 状态为 `ended`
  - 创建 AuctionOutcome 记录
  - 如果有出价但低于保留价：`reserve_met = FALSE`, `seller_accepted = FALSE`
  - 设置 24 小时的决策期限 `acceptance_deadline`

### 2. 卖家决策界面

#### 在 `listing.php` 页面
- 卖家访问拍卖详情页时，如果需要决策，会显示：
  - 黄色警告卡片 "Action Required"
  - 显示中标者、最终出价、保留价
  - 两个按钮：
    - **Accept Bid** (绿色) - 接受出价
    - **Reject Bid** (红色) - 拒绝出价
  - 决策截止时间倒计时

#### 在 `mylistings.php` 页面
- 顶部显示 "Pending Decisions" 区域
- 列出所有需要决策的拍卖
- 每个拍卖显示相同的决策按钮

### 3. 接受出价 (`accept_bid.php?action=accept`)
- 更新 `AuctionOutcome.seller_accepted = TRUE`
- 保留 `winner_id` 和 `final_price`
- 发送通知给买家：出价被接受
- 拍卖标记为成功

### 4. 拒绝出价 (`accept_bid.php?action=reject`)
- 更新 `AuctionOutcome`:
  - `seller_accepted = FALSE`
  - `winner_id = NULL`
  - `final_price = NULL`
- **关键优化**: 更新所有该拍卖的出价：`UPDATE Bid SET is_active = FALSE`
- 发送通知给买家：出价被拒绝
- 拍卖标记为不成功

### 5. 决策超时处理 (`cron_expire_decisions.php`)
- 定时检查超过 24 小时未决策的拍卖
- 自动拒绝超时的出价
- 行为与手动拒绝相同：
  - 清除中标者信息
  - **设置所有出价为 `is_active = FALSE`**
  - 发送通知给卖家和买家

## 数据库字段同步

### Bid 表的 `is_active` 字段更新时机：

1. ✅ **拍卖结束时** - 由 `closeAuction()` 保持为 TRUE（等待决策）
2. ✅ **卖家接受出价** - 保持中标出价为 TRUE，其他为 FALSE
3. ✅ **卖家拒绝出价** - 所有出价设为 FALSE
4. ✅ **决策超时** - 所有出价设为 FALSE

## 相关文件

| 文件 | 功能 |
|------|------|
| `auction_functions.php` | 关闭拍卖核心逻辑 |
| `listing.php` | 显示拍卖详情和决策按钮 |
| `mylistings.php` | 显示卖家的所有拍卖和待决策列表 |
| `accept_bid.php` | 处理接受/拒绝出价 |
| `cron_expire_decisions.php` | 处理决策超时 |
| `cron_close_auctions.php` | 定时关闭到期拍卖 |

## 测试工具

| 页面 | 用途 |
|------|------|
| `seller_decision_dashboard.php` | 卖家决策综合仪表板 |
| `close_auction_28.php` | 手动关闭特定拍卖 |
| `manage_auction_28.php` | 管理特定拍卖 |
| `debug_seller_decision.php` | 调试决策显示逻辑 |

## 使用流程

1. **拍卖创建**: 卖家创建拍卖并设置保留价
2. **买家出价**: 买家出价，但未达到保留价
3. **拍卖结束**: 
   - 自动或手动触发 `closeAuction()`
   - 创建 AuctionOutcome，reserve_met = FALSE
4. **卖家决策**:
   - 卖家访问 `listing.php` 或 `mylistings.php`
   - 看到决策按钮
   - 点击 Accept 或 Reject
5. **结果处理**:
   - Accept: 拍卖成功，买家获得商品
   - Reject: 拍卖失败，所有出价失效 (is_active = FALSE)
   - Timeout: 24小时后自动拒绝

## 关键优化点

✅ **已优化**: 
- Bid.is_active 在拒绝和超时时正确更新为 FALSE
- 决策按钮在 listing.php 和 mylistings.php 都正确显示
- 通知系统完整集成
- 支持自动关闭过期拍卖

## 测试验证

访问 `seller_decision_dashboard.php` 可以看到：
1. 需要关闭的过期拍卖
2. 待决策的拍卖列表
3. 已完成的拍卖状态
4. Bid is_active 字段验证
