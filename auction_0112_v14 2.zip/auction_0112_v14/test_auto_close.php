<?php
/**
 * 测试脚本：验证拍卖结束后状态是否自动同步更新为 ended
 */

require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "=== 拍卖自动关闭功能测试 ===\n\n";

// 1. 检查是否有过期但未关闭的拍卖
echo "1. 检查当前系统中的过期拍卖...\n";
$stmt = $pdo->query("
    SELECT auction_id, title, status, end_time,
           TIMESTAMPDIFF(MINUTE, end_time, NOW()) as minutes_past
    FROM Auction 
    WHERE end_time <= NOW()
    ORDER BY end_time DESC
    LIMIT 10
");
$expired_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($expired_auctions) > 0) {
    echo "找到 " . count($expired_auctions) . " 个已过期的拍卖：\n";
    foreach ($expired_auctions as $auction) {
        $status_icon = $auction['status'] === 'ended' ? '✅' : '❌';
        echo sprintf(
            "  %s 拍卖 #%d: %s | 状态: %s | 结束时间: %s (已过 %d 分钟)\n",
            $status_icon,
            $auction['auction_id'],
            $auction['title'],
            $auction['status'],
            $auction['end_time'],
            $auction['minutes_past']
        );
    }
} else {
    echo "✅ 没有找到已过期的拍卖\n";
}

// 2. 检查是否有卡住的拍卖（status='active' 但已过期）
echo "\n2. 检查卡住的拍卖 (status='active' 但已过期)...\n";
$stmt = $pdo->query("
    SELECT auction_id, title, status, end_time,
           TIMESTAMPDIFF(MINUTE, end_time, NOW()) as minutes_past
    FROM Auction 
    WHERE status = 'active' AND end_time <= NOW()
");
$stuck_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($stuck_auctions) > 0) {
    echo "❌ 发现 " . count($stuck_auctions) . " 个卡住的拍卖：\n";
    foreach ($stuck_auctions as $auction) {
        echo sprintf(
            "  拍卖 #%d: %s | 结束时间: %s (已过 %d 分钟)\n",
            $auction['auction_id'],
            $auction['title'],
            $auction['end_time'],
            $auction['minutes_past']
        );
    }
    echo "\n建议：运行 cron_close_auctions.php 或 maintenance_check_stuck_auctions.php\n";
} else {
    echo "✅ 没有发现卡住的拍卖\n";
}

// 3. 验证自动关闭机制
echo "\n3. 验证自动关闭机制...\n";

// 3.1 检查 closeAuction() 函数是否存在
if (function_exists('closeAuction')) {
    echo "✅ closeAuction() 函数已定义 (在 auction_functions.php)\n";
} else {
    echo "❌ closeAuction() 函数未找到\n";
}

// 3.2 检查 cron 脚本
if (file_exists('cron_close_auctions.php')) {
    echo "✅ cron_close_auctions.php 文件存在\n";
    
    // 检查 cron 脚本是否包含正确的查询
    $cron_content = file_get_contents('cron_close_auctions.php');
    if (strpos($cron_content, "status = 'active' AND end_time <= NOW()") !== false) {
        echo "✅ Cron 脚本包含正确的查询逻辑\n";
    } else {
        echo "❌ Cron 脚本查询逻辑可能有误\n";
    }
    
    if (strpos($cron_content, 'closeAuction($pdo, $auction)') !== false) {
        echo "✅ Cron 脚本调用 closeAuction() 函数\n";
    } else {
        echo "❌ Cron 脚本未调用 closeAuction() 函数\n";
    }
} else {
    echo "❌ cron_close_auctions.php 文件不存在\n";
}

// 3.3 检查 listing.php 的后备机制
if (file_exists('listing.php')) {
    $listing_content = file_get_contents('listing.php');
    if (strpos($listing_content, "if (\$status === 'active' && \$now >= \$end_time)") !== false) {
        echo "✅ listing.php 包含自动关闭的后备机制\n";
    } else {
        echo "⚠️  listing.php 没有自动关闭的后备机制\n";
    }
}

// 3.4 检查 cron 日志
echo "\n4. 检查 Cron 日志...\n";
$log_file = __DIR__ . '/logs/cron_close_auctions.log';
if (file_exists($log_file)) {
    echo "✅ Cron 日志文件存在: $log_file\n";
    
    // 读取最后5行
    $log_lines = file($log_file);
    $recent_lines = array_slice($log_lines, -5);
    
    echo "最近的日志记录：\n";
    foreach ($recent_lines as $line) {
        echo "  " . trim($line) . "\n";
    }
    
    // 检查最后一次运行时间
    if (count($log_lines) > 0) {
        $last_line = end($log_lines);
        if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]/', $last_line, $matches)) {
            $last_run = $matches[1];
            $last_run_time = new DateTime($last_run);
            $now = new DateTime();
            $diff = $now->diff($last_run_time);
            
            echo "\n最后运行时间: $last_run (";
            if ($diff->days > 0) {
                echo $diff->days . " 天前";
            } elseif ($diff->h > 0) {
                echo $diff->h . " 小时前";
            } elseif ($diff->i > 0) {
                echo $diff->i . " 分钟前";
            } else {
                echo "刚刚";
            }
            echo ")\n";
            
            if ($diff->h > 1) {
                echo "⚠️  Cron 任务可能没有正确设置（超过1小时未运行）\n";
            }
        }
    }
} else {
    echo "⚠️  Cron 日志文件不存在（可能 cron 从未运行过）\n";
}

// 5. 检查 AuctionOutcome 同步
echo "\n5. 检查 AuctionOutcome 同步状态...\n";
$stmt = $pdo->query("
    SELECT a.auction_id, a.title, a.status, 
           ao.outcome_id, ao.winner_id, ao.final_price, ao.reserve_met
    FROM Auction a
    LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id
    WHERE a.status = 'ended'
    ORDER BY a.end_time DESC
    LIMIT 5
");
$ended_auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($ended_auctions) > 0) {
    echo "最近结束的 " . count($ended_auctions) . " 个拍卖：\n";
    foreach ($ended_auctions as $auction) {
        $sync_status = $auction['outcome_id'] ? '✅' : '❌';
        $winner_info = $auction['winner_id'] ? "Winner: #{$auction['winner_id']}, Price: £{$auction['final_price']}" : "无出价";
        echo sprintf(
            "  %s 拍卖 #%d: %s | %s | AuctionOutcome: %s\n",
            $sync_status,
            $auction['auction_id'],
            $auction['title'],
            $winner_info,
            $auction['outcome_id'] ? "已同步 (ID: {$auction['outcome_id']})" : "未同步"
        );
    }
} else {
    echo "没有找到已结束的拍卖\n";
}

// 6. 总结
echo "\n" . str_repeat("=", 50) . "\n";
echo "测试总结\n";
echo str_repeat("=", 50) . "\n";

$issues = [];

if (count($stuck_auctions) > 0) {
    $issues[] = "发现 " . count($stuck_auctions) . " 个卡住的拍卖";
}

if (!function_exists('closeAuction')) {
    $issues[] = "closeAuction() 函数未找到";
}

if (!file_exists('cron_close_auctions.php')) {
    $issues[] = "cron_close_auctions.php 文件不存在";
}

if (!file_exists($log_file)) {
    $issues[] = "Cron 日志文件不存在（可能 cron 未设置）";
}

if (count($issues) === 0) {
    echo "✅ 所有检查通过！拍卖自动关闭功能运行正常。\n";
} else {
    echo "⚠️  发现以下问题：\n";
    foreach ($issues as $issue) {
        echo "  - $issue\n";
    }
    echo "\n建议解决方案：\n";
    echo "  1. 设置 cron 任务定期运行 cron_close_auctions.php\n";
    echo "  2. 运行 maintenance_check_stuck_auctions.php 修复卡住的拍卖\n";
    echo "  3. 访问拍卖详情页面会自动触发关闭（后备机制）\n";
}

echo "\n" . str_repeat("=", 50) . "\n";
?>
