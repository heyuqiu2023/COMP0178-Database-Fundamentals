<?php
/**
 * 清理数据库中不存在的图片URL
 */

require_once 'db_connection.php';

echo "=== 图片URL清理工具 ===\n\n";

// 获取所有有图片的拍卖
$stmt = $pdo->query("SELECT auction_id, title, img_url FROM Auction WHERE img_url IS NOT NULL AND img_url != ''");
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "找到 " . count($auctions) . " 个有图片的拍卖\n\n";

$cleaned_count = 0;
$total_removed = 0;

foreach ($auctions as $auction) {
    $auction_id = $auction['auction_id'];
    $title = $auction['title'];
    $img_url = $auction['img_url'];
    
    // 分割图片URL
    $urls = array_filter(array_map('trim', explode(',', $img_url)));
    
    echo "拍卖 #{$auction_id} ({$title}):\n";
    echo "  原始图片URL: {$img_url}\n";
    echo "  图片数量: " . count($urls) . "\n";
    
    // 检查每个图片文件是否存在
    $valid_urls = [];
    $invalid_urls = [];
    
    foreach ($urls as $url) {
        $file_path = __DIR__ . '/' . trim($url);
        if (file_exists($file_path)) {
            $valid_urls[] = trim($url);
            echo "    ✓ {$url}\n";
        } else {
            $invalid_urls[] = trim($url);
            echo "    ✗ {$url} (不存在)\n";
        }
    }
    
    // 如果有无效的URL，更新数据库
    if (!empty($invalid_urls)) {
        $new_img_url = !empty($valid_urls) ? implode(',', $valid_urls) : null;
        
        $stmt = $pdo->prepare("UPDATE Auction SET img_url = ? WHERE auction_id = ?");
        $stmt->execute([$new_img_url, $auction_id]);
        
        echo "  → 已清理 " . count($invalid_urls) . " 个无效URL\n";
        echo "  → 新的img_url: " . ($new_img_url ?? '(NULL)') . "\n";
        
        $cleaned_count++;
        $total_removed += count($invalid_urls);
    } else {
        echo "  → 所有图片都有效\n";
    }
    
    echo "\n";
}

echo "=== 清理完成 ===\n";
echo "处理的拍卖数: " . count($auctions) . "\n";
echo "清理的拍卖数: {$cleaned_count}\n";
echo "删除的无效URL: {$total_removed}\n";
?>
