<?php
require_once 'db_connection.php';
require_once 'auction_functions.php';

echo "<h2>Manually Closing Expired Auctions</h2>";

// Find auctions that are active but past end_time
$stmt = $pdo->query("SELECT * FROM Auction 
                     WHERE status = 'active' 
                     AND end_time <= NOW()
                     ORDER BY auction_id");

$closed_count = 0;
while ($auction = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<p>Closing auction #" . $auction['auction_id'] . " - " . htmlspecialchars($auction['title']) . "...</p>";
    
    try {
        $pdo->beginTransaction();
        closeAuction($pdo, $auction);
        $pdo->commit();
        echo "<p style='color:green;'>✓ Successfully closed auction #" . $auction['auction_id'] . "</p>";
        $closed_count++;
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "<p style='color:red;'>✗ Failed to close auction #" . $auction['auction_id'] . ": " . $e->getMessage() . "</p>";
    }
}

echo "<hr>";
echo "<p><strong>Total closed: $closed_count</strong></p>";

// Show updated status
echo "<h3>Updated Auction Status:</h3>";
$stmt = $pdo->query("SELECT a.auction_id, a.title, a.status, a.reserve_price, 
                     ao.winner_id, ao.final_price, ao.reserve_met, ao.seller_accepted, ao.acceptance_deadline 
                     FROM Auction a 
                     LEFT JOIN AuctionOutcome ao ON a.auction_id = ao.auction_id 
                     WHERE a.title LIKE '%bike%' 
                     ORDER BY a.auction_id DESC 
                     LIMIT 5");

echo "<table border='1' cellpadding='5'>";
echo "<tr><th>ID</th><th>Title</th><th>Status</th><th>Reserve</th><th>Winner ID</th><th>Final Price</th><th>Reserve Met</th><th>Seller Accepted</th><th>Deadline</th></tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $row['auction_id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['title']) . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>£" . number_format($row['reserve_price'], 2) . "</td>";
    echo "<td>" . ($row['winner_id'] ?? 'NULL') . "</td>";
    echo "<td>£" . number_format($row['final_price'] ?? 0, 2) . "</td>";
    echo "<td>" . ($row['reserve_met'] ?? 'NULL') . "</td>";
    echo "<td>" . ($row['seller_accepted'] ?? 'NULL') . "</td>";
    echo "<td>" . ($row['acceptance_deadline'] ?? 'NULL') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<p><a href='listing.php?auction_id=20'>View Auction #20 Listing Page</a></p>";
?>
