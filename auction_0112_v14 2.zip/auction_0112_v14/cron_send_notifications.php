<?php
require_once 'db_connection.php';
require_once 'notify.php';

// 处理所有用户的未发送邮件通知
// 注意：不传入 user_id 参数，处理所有用户的通知
echo "Processing email queue for all users...\n";
process_email_queue();
echo "Email queue processed successfully.\n";